# 安装与本地导入

1. 从仓库根按 [README](../README.md#本机运行) 构建前端并启动 Python 服务。
2. 打开 `/maintenance/`，点击「重新扫描技能文件」。默认索引 `~/.codex/skills` 与 `~/.codex/plugins/cache`，生成本地 `data/inventory.json`。浏览器只向本机服务请求。
3. 回到 Agent 首页，选目标，进入「发现 → 我的技能」。也可以选公开候选，先核对完整文件、目标路径和版本，再决定采用。
4. 源文件留在原目录。系统与插件只读，缓存记录单列，目标目录与会话是否加载分别显示。

`--project` 用于指定应用根。要索引另一套个人技能目录，请在启动时通过 `SkillStore(project, personal_root=...)` 配置实际目录。Codex 采用的文件目标为共享的 `~/.agents/skills`，与默认个人索引根不同。

对话入口在 `skills/skill-engine/`。安装时保留目录结构并核对宿主实际发现目录。
