# Agent 工作台前端

Node.js 22.12+。运行 `npm ci` 和 `npm run build`，构建输出写到 `web/flow-lab/`。启动与导入见 [项目 README](../../README.md)。
