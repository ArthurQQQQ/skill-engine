import React, {useCallback, useEffect, useRef, useState} from 'react';
import Library from './Library.jsx';
import CuratedCatalog from './CuratedCatalog.jsx';
import AgentWorkspace from './AgentWorkspace.jsx';
import LocalSkillPicker from './LocalSkillPicker.jsx';
import {catalogTargetPath,catalogTargetPayload} from './agentCatalogTarget.mjs';
import {deploymentAllowsInstall,deploymentLabel,deploymentNextAction,licenseLabel,mergePreflight,taskDirectoryFilters} from './curatedCatalogModel.mjs';
import './engine.css';
import './agent-workspace.css';

const STATUS={draft:'待准备',ready:'方案已准备',needs_skills:'待补齐能力',needs_clarification:'需要补充信息',queued:'已排队',running:'运行中',completed:'已返回结果',failed:'执行失败',cancelled:'已取消'};
const STEP_STATUS={pending:'待开始',ready:'待开始',queued:'已排队',running:'运行中',completed:'已完成',failed:'失败',cancelled:'已取消',blocked:'待准备',skipped:'已跳过'};
const ACTIVE=new Set(['queued','running']);
const EXAMPLES=['给研究项目做一个深色、简约、清楚的网页。','审阅这篇论文的贡献与实验，整理最需要补齐的证据。','把零散的项目笔记整理成一份清楚的实施方案。'];
const list=value=>Array.isArray(value)?value:[];
const words=value=>typeof value==='string'?value:value==null?'':JSON.stringify(value,null,2);
const taskFrom=value=>value?.task || value;
const stamp=value=>{if(!value)return '';const date=new Date(value);return Number.isNaN(date.valueOf())?String(value):date.toLocaleString('zh-CN',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});};
const shortSha=value=>value?String(value).slice(0,12):'未提供';
const AVAILABILITY={exposed:'当前宿主可见',unknown:'当前可用性待核对',cache_only:'仅有缓存文件'};
const SOURCE={personal:'个人技能',system:'系统技能',plugin:'插件技能',plugin_cache:'插件缓存',cache:'缓存文件'};
const warningText=value=>value && typeof value==='object' && value.message?`${value.message}${value.transactionId?`（事务 ${value.transactionId}）`:''}`:words(value);

function catalogOutcome(result) {
  const action=result.operation==='update'?'更新':result.operation==='rollback'?'恢复':'安装';
  const summary=result.installed?`技能文件已${action}；宿主发现尚未验证。`:(result.message || '采用结果已返回，请核对状态。');
  const issues=[...list(result.warnings),...list(result.journalWarnings),...list(result.recoveryWarnings)].map(warningText);
  if(result.sync?.ok===false)issues.push(`技能文件已写入，但本地索引同步未完整完成。${result.sync.message || '请重试同步并核对目录。'}`);
  issues.push(...list(result.sync?.warnings).map(warningText));
  if(result.taskRefresh?.ok===false)issues.push(`关联任务未能重新规划：${warningText(result.taskRefresh.error || result.taskRefresh.message || '请重新读取任务后再规划。')}`);
  if(result.transaction?.journalSynced===false)issues.push('文件提交已记录，事务日志收尾尚未完成，请查看目录事务提示。');
  if(result.installed)issues.push(deploymentNextAction({status:'installed_unverified'}));
  return {summary,issues:[...new Set(issues.filter(Boolean))],complete:Boolean(result.installed) && !issues.length};
}

function Icon({name,className=''}) {
  const paths={agent:<><rect x="4" y="6" width="16" height="13" rx="4"/><path d="M12 3v3M8 11h.01M16 11h.01M9 15h6"/></>,library:<><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,plus:<path d="M12 5v14M5 12h14"/>,arrow:<path d="M5 12h14m-6-6 6 6-6 6"/>,back:<path d="M19 12H5m6-6-6 6 6 6"/>,search:<><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></>,check:<path d="m5 12 4 4L19 6"/>,close:<path d="m6 6 12 12M18 6 6 18"/>,more:<><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,copy:<><rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V3H3v13h5"/></>,play:<path d="m8 4 12 8-12 8Z"/>,stop:<rect x="6" y="6" width="12" height="12" rx="1"/>,refresh:<><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6 6a8 8 0 0 1 13 3M18 18a8 8 0 0 1-13-3"/></>,external:<><path d="M14 3h7v7m0-7L10 14"/><path d="M10 3H3v18h18v-7"/></>,clock:<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,chevron:<path d="m9 5 7 7-7 7"/>,file:<><path d="M14 3H5v18h14V8ZM14 3v5h5"/><path d="M8 12h8m-8 4h6"/></>};
  return <svg className={`se-icon ${className}`} width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] || paths.file}</svg>;
}

async function api(path,{body,signal}={}) {
  const response=await fetch(path,{method:body===undefined?'GET':'POST',headers:body===undefined?undefined:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal,cache:'no-store'});
  let data;try {data=await response.json();} catch {throw new Error('服务未返回可读取的数据，请检查本地服务后重试。');}
  if(!response.ok || data.error) {const error=new Error(typeof data.error==='string'?data.error:(data.error?.message || data.message || `请求失败（${response.status}）`));error.status=response.status;throw error;}
  return data;
}

function Message({children,onRetry,tone='error'}) {return <div className={`se-message ${tone}`} role={tone==='error'?'alert':'status'}><p style={{whiteSpace:'pre-wrap'}}>{children}</p>{onRetry && <button className="se-button quiet" onClick={onRetry}>重试</button>}</div>;}
function SourceLink({url,children}) {return /^https:\/\/(github\.com|skills\.sh|www\.skills\.sh)\//.test(url || '')?<a className="se-source-link" href={url} target="_blank" rel="noreferrer">{children}<Icon name="external"/></a>:<span>{children}</span>;}

function AppMenu({config,error,onRefresh,onSync,syncing}) {
  const menu=useRef(null);
  useEffect(()=>{
    const outside=event=>{if(menu.current && !menu.current.contains(event.target))menu.current.open=false;};
    const escape=event=>{if(event.key==='Escape' && menu.current?.open){menu.current.open=false;menu.current.querySelector('summary')?.focus();}};
    document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);
    return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape);};
  },[]);
  return <details className="se-app-menu" ref={menu}><summary aria-label="设置与帮助"><Icon name="more"/></summary><div className="se-menu-panel"><h2>连接与设置</h2>
    <dl className="se-connection-list"><div><dt>任务分析</dt><dd>{!config?'未检查':config.plannerConfigured || config.planner?.configured?'OpenRouter 已配置':'本地候选推荐'}</dd></div><div><dt>执行器</dt><dd className={config?.executor?.configured?'se-good':''}>{!config?'未检查':config.executor?.configured?'已配置':'未配置'}</dd></div></dl>
    {config?.executor?.reason && <p>{words(config.executor.reason)}</p>}{error && <p className="se-error-text">{error}</p>}
    <button className="se-menu-action" onClick={onRefresh}><Icon name="refresh"/>检查配置</button><button className="se-menu-action" disabled={syncing} onClick={onSync}><Icon name="refresh"/>{syncing?'正在刷新本机索引…':'刷新本机索引'}</button><a className="se-menu-action" href="/maintenance">打开高级维护<Icon name="external"/></a>
    <details className="se-help"><summary>使用说明与边界</summary><p>描述任务后，先查看推荐组合与准备情况，再开始执行。只有真实执行事件会更新运行状态。</p><p>技能文件存在、出现在会话目录和已被执行器加载，是不同状态。推荐组合不代表效果已经验证。</p><p>“复制交接”只生成可复制内容，需要你在执行 Agent 中粘贴。公开搜索仅发送可见检索词。</p></details>
  </div></details>;
}

function TaskHistory({tasks,selected,loading,error,onSelect,onNew,onRetry}) {
  return <aside className="se-history" aria-label="任务记录"><button className="se-new-task" onClick={onNew}><Icon name="plus"/>新任务</button><div className="se-history-heading"><h2>最近任务</h2>{loading && <span role="status">读取中</span>}</div>
    {error?<Message onRetry={onRetry}>{error}</Message>:!loading && !tasks.length?<p className="se-history-empty">暂无任务</p>:<ol className="se-history-list">{tasks.map(item=><li key={item.id}><button className={selected===item.id?'selected':''} onClick={()=>onSelect(item.id)} aria-current={selected===item.id?'page':undefined}><span className="se-history-title">{item.title || item.request || '未命名任务'}</span><span className="se-history-meta"><span className={`se-status-dot ${item.status}`}/>{STATUS[item.status] || item.status}<time>{stamp(item.updatedAt || item.createdAt)}</time></span></button></li>)}</ol>}
  </aside>;
}

function Composer({value,onChange,onSubmit,busy,config,error,inputRef}) {
  const semantic=Boolean(config?.plannerConfigured || config?.planner?.configured),[mode,setMode]=useState('local');
  return <section className="se-composer-area"><div className="se-composer-intro"><h1>你想完成什么？</h1></div><form className="se-composer" onSubmit={event=>{event.preventDefault();onSubmit(mode);}}>
    <label className="se-sr-only" htmlFor="task-request">任务目标、已有材料与约束</label><textarea id="task-request" ref={inputRef} disabled={busy} value={value} onChange={event=>onChange(event.target.value)} maxLength={12000} rows={5} placeholder="描述你的目标、已有材料和约束…" onKeyDown={event=>{if(event.key==='Enter' && (event.metaKey || event.ctrlKey)){event.preventDefault();if(value.trim() && !busy)onSubmit(mode);}}}/>
    <div className="se-composer-bottom"><label className="se-mode-select"><span className="se-sr-only">方案生成方式</span><select aria-label="方案生成方式" disabled={busy} value={mode} onChange={event=>setMode(event.target.value)}><option value="local">本地候选推荐</option><option value="semantic" disabled={!semantic}>OpenRouter 分析{!semantic?'（未配置）':''}</option></select></label><button className="se-button primary" type="submit" disabled={!value.trim() || busy}>{busy?'正在准备方案…':'生成方案'}{!busy && <Icon name="arrow"/>}</button></div>
  </form>{error && <Message>{error}</Message>}{mode==='semantic' && <p className="se-composer-foot">任务与候选原文将发送至 OpenRouter。</p>}<div className="se-examples">{EXAMPLES.map(example=><button key={example} disabled={busy} onClick={()=>{onChange(example);inputRef.current?.focus();}}>{example}<Icon name="chevron"/></button>)}</div></section>;
}

function Combo({plan}) {
  const combo=list(plan?.combo),unprepared=list(plan?.gaps).length>0 || list(plan?.clarifications).length>0,semantic=['semantic','openrouter_semantic'].includes(plan?.method);
  return <section className="se-plan-section"><div className="se-section-heading"><h2>推荐组合</h2><span>{combo.length?`${combo.length} 项`:unprepared?'待准备':'直接执行'}</span></div>{semantic && plan?.summary && <p className="se-plan-summary">{words(plan.summary)}</p>}
    {!combo.length?<div className="se-direct-plan"><Icon name={unprepared?'file':'check'}/><div><h3>{unprepared?'待准备':'本次未选专用 Skill'}</h3></div></div>:<ol className="se-combo-list">{combo.map((skill,index)=><li key={skill.id || index}><div className="se-combo-heading"><h3>{words(skill.role) || skill.name}</h3><span className="se-skill-name">{skill.name || skill.id}</span></div><details><summary>依据与来源</summary><div className="se-skill-evidence">{skill.reason && <p>{words(skill.reason)}</p>}{skill.description && <p>{words(skill.description)}</p>}<dl><div><dt>来源</dt><dd>{SOURCE[skill.source] || words(skill.source) || '未知'}</dd></div><div><dt>可用证据</dt><dd>{AVAILABILITY[skill.availability] || words(skill.availability) || '待核对'}</dd></div>{skill.sha && <div><dt>版本</dt><dd><code>{shortSha(skill.sha)}</code></dd></div>}</dl>{skill.availabilityEvidence && <p className="se-availability-evidence">{words(skill.availabilityEvidence)}</p>}{skill.path && <code className="se-path">{skill.path}</code>}</div></details></li>)}</ol>}
    {plan?.method && <p className="se-method">{semantic?'OpenRouter 建议':'本地推荐'} · 待实测</p>}
  </section>;
}

function TaskRoute({task}) {
  const steps=list(task.plan?.steps),combo=list(task.plan?.combo),names=new Map(combo.map(item=>[item.id,item.name])),terminal=['completed','failed','cancelled'].includes(task.status),prepared=!list(task.plan?.gaps).length && !list(task.plan?.clarifications).length;
  return <section className="se-route-section"><div className="se-section-heading"><h2>任务路线</h2><span>{steps.length?`${steps.length} 个步骤`:'等待方案'}</span></div><div className="se-route-stage"><span className={`se-stage-marker ${prepared?'prepared':''}`}><Icon name={prepared?'check':'file'}/></span><div><h3>准备</h3><p>{task.status==='needs_skills'?'有能力需要补齐':task.status==='needs_clarification'?'需要补充任务信息':ACTIVE.has(task.status)?'准备完成，已交给执行器':terminal?'准备方案已记录':'方案已生成，等待执行'}</p></div></div>
    <ol className="se-route-steps">{steps.length?steps.map((step,index)=><li key={step.id || index} className={`se-route-step ${step.status || 'pending'}`}><span className="se-step-marker">{step.status==='completed'?<Icon name="check"/>:index+1}</span><div className="se-step-content"><div><h3>{step.title || '未命名步骤'}</h3><span className="se-step-status">{STEP_STATUS[step.status] || step.status || '待开始'}</span></div>{step.description && <p>{words(step.description)}</p>}<p className="se-step-skills">{list(step.skillIds).length?step.skillIds.map(id=>names.get(id)||id).join(' / '):'执行 Agent'}</p></div></li>):<li className="se-no-steps">方案未提供具体步骤。</li>}</ol><div className={`se-route-stage result ${task.status==='completed'?'completed':''}`}><span className="se-stage-marker">{task.status==='completed'?<Icon name="check"/>:<Icon name="file"/>}</span><div><h3>结果</h3><p>{task.status==='completed'?'待验收':terminal?STATUS[task.status]:'等待真实执行结果'}</p></div></div></section>;
}

function TaskResults({task,onError}) {
  const [artifact,setArtifact]=useState(null),[loading,setLoading]=useState(''),revision=useRef(0),controller=useRef(null);
  useEffect(()=>{revision.current++;controller.current?.abort();setArtifact(null);setLoading('');return()=>controller.current?.abort();},[task.id]);
  const artifacts=list(task.run?.artifacts || task.artifacts);
  async function readArtifact(item) {controller.current?.abort();const next=new AbortController();controller.current=next;const rev=++revision.current,name=typeof item==='string'?item:item.name || item.path;setLoading(name);try{const value=await api(`/api/task/artifact?id=${encodeURIComponent(task.id)}&name=${encodeURIComponent(name)}`,{signal:next.signal});if(rev===revision.current)setArtifact({name,value});}catch(error){if(error.name!=='AbortError')onError(error.message);}finally{if(rev===revision.current)setLoading('');}}
  function downloadArtifact() {
    if(!artifact)return;
    try {
      const value=artifact.value,content=value.encoding==='base64'?Uint8Array.from(atob(value.content),character=>character.charCodeAt(0)):words(value.content ?? value);
      const blob=new Blob([content],{type:value.kind || 'application/octet-stream'}),url=URL.createObjectURL(blob),anchor=document.createElement('a');
      anchor.href=url;anchor.download=artifact.name.split('/').at(-1) || 'artifact';document.body.appendChild(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
    } catch {onError('产物无法准备下载，请重新读取后重试。');}
  }
  const summary=task.run?.summary || task.run?.result || task.result;
  if(!summary && !artifacts.length && !['completed','failed','cancelled'].includes(task.status))return null;
  return <section className="se-results"><h2>执行结果</h2>{task.run?.outcomeEvidence==='agent_reported' && <p className="se-result-evidence">Agent 回传，待验收。</p>}{summary && <pre className="se-result-summary">{words(summary)}</pre>}{task.run?.error && <Message>{words(task.run.error)}</Message>}{artifacts.length>0 && <ul className="se-artifact-list">{artifacts.map((item,index)=><li key={typeof item==='string'?item:item.name || index}><button onClick={()=>readArtifact(item)} disabled={Boolean(loading)}><Icon name="file"/>{typeof item==='string'?item:item.name || item.path}{loading===(typeof item==='string'?item:item.name || item.path)?' · 读取中':''}</button></li>)}</ul>}{artifact && <details className="se-artifact-content" open><summary>{artifact.name}</summary><button className="se-button secondary" onClick={downloadArtifact}>下载产物<Icon name="file"/></button>{artifact.value?.encoding==='base64'?<p className="se-secondary">二进制文件，可下载后查看。</p>:<pre>{words(artifact.value?.content ?? artifact.value)}</pre>}</details>}{task.status==='completed' && !summary && !artifacts.length && <p className="se-secondary">执行器已报告完成，尚未提供可展示的产物。</p>}</section>;
}

function TaskPanel({task,events,config,busy,error,onAction,onDiscover,onError,onRefine}) {
  const plan=task.plan || {},gaps=list(plan.gaps),warnings=list(plan.warnings),requirements=list(plan.requirements),clarifications=list(plan.clarifications),latestFeedback=list(task.feedback).at(-1);
  const [feedbackNote,setFeedbackNote]=useState(''),[handoff,setHandoff]=useState(''),[copyState,setCopyState]=useState(''),revision=useRef(0),copyRef=useRef(null);
  useEffect(()=>{revision.current++;setHandoff('');setCopyState('');setFeedbackNote('');return()=>{revision.current++;};},[task.id]);
  async function copyHandoff() {const rev=revision.current,id=task.id,value=await onAction('handoff',{taskId:id,baselineSha:task.sha});if(!value || rev!==revision.current)return;const prompt=value.prompt || '';setHandoff(prompt);try{await navigator.clipboard.writeText(prompt);if(rev===revision.current)setCopyState('已复制交接内容；请粘贴到执行 Agent。');}catch{if(rev===revision.current){setCopyState('请手动复制下方交接内容。');requestAnimationFrame(()=>{copyRef.current?.focus();copyRef.current?.select();});}}}
  const available=Boolean(config?.executor?.configured),active=ACTIVE.has(task.status),canRun=task.status==='ready' && available && !task.run;
  return <article className="se-task-panel"><header className="se-task-heading"><div><span className={`se-task-status ${task.status}`}><span className={`se-status-dot ${task.status}`}/>{STATUS[task.status] || task.status}</span><h1>{task.title || '任务方案'}</h1>{task.request!==task.title && <p>{task.request}</p>}</div><details className="se-task-facts"><summary aria-label="任务信息"><Icon name="more"/></summary><div><p>创建于 {stamp(task.createdAt)}</p><code>{task.id}</code><code>版本 {shortSha(task.sha)}</code></div></details></header>
    {error && <Message>{error}{error.includes('过期') || error.includes('stale')?' 请重新读取任务后再操作。':''}</Message>}
    <div className="se-task-grid"><div className="se-plan-column"><Combo plan={plan}/>{clarifications.length>0 && <section className="se-clarifications"><h2>需要补充的信息</h2><ul>{clarifications.map((question,index)=><li key={index}>{words(question)}</li>)}</ul><button className="se-button secondary" disabled={Boolean(busy)} onClick={()=>onRefine(task.request)}>补充信息，创建新方案<Icon name="arrow"/></button></section>}{(gaps.length>0 || warnings.length>0 || requirements.length>0) && <section className="se-preparation"><div className="se-section-heading"><h2>准备情况</h2><span>{gaps.length?`${gaps.length} 项待补齐`:'查看依据'}</span></div>{requirements.length>0 && <details className="se-requirements"><summary>任务要求</summary><ul>{requirements.map((item,index)=><li key={item.id || index}>{typeof item==='string'?item:item.label || item.description || words(item)}</li>)}</ul></details>}{gaps.map((gap,index)=><div className="se-gap" key={gap.id || index}><h3>{gap.label || gap.query}</h3><p>{gap.reason}</p><button className="se-button secondary" onClick={()=>onDiscover(gap.query || gap.label)}>查找相关技能<Icon name="search"/></button></div>)}{warnings.length>0 && <details className="se-plan-warnings"><summary>方案说明与限制</summary>{warnings.map((item,index)=><p className="se-warning" key={index}>{words(item)}</p>)}</details>}</section>}
      <TaskResults task={task} onError={onError}/>{events.length>0 && <details className="se-events" open={active || undefined}><summary>执行记录<span>{events.length}</span></summary><ol>{events.map((event,index)=><li key={event.sequence ?? index}><time>{stamp(event.at)}</time><p>{event.message || event.type}</p></li>)}</ol></details>}{['completed','failed','cancelled'].includes(task.status) && <section className="se-feedback"><h2>这次方案有帮助吗？</h2>{latestFeedback && <p className="se-secondary">已记录：{latestFeedback.outcome==='helpful'?'有帮助':'需要改进'}{latestFeedback.note && ` · ${latestFeedback.note}`}</p>}<label><span className="se-sr-only">反馈说明</span><textarea value={feedbackNote} onChange={event=>setFeedbackNote(event.target.value)} placeholder="可选：哪些能力有用，哪里需要调整？" maxLength={4000} rows={2}/></label><div className="se-inline-actions"><button className="se-button secondary" disabled={Boolean(busy)} onClick={()=>onAction('feedback',{taskId:task.id,baselineSha:task.sha,outcome:'helpful',note:feedbackNote})}>有帮助</button><button className="se-button quiet" disabled={Boolean(busy)} onClick={()=>onAction('feedback',{taskId:task.id,baselineSha:task.sha,outcome:'not_helpful',note:feedbackNote})}>需要改进</button></div></section>}</div><div className="se-route-column"><TaskRoute task={task}/></div></div>
    <footer className="se-task-actions"><div className="se-executor-status"><span className={`se-status-dot ${available?'completed':''}`}/><div><strong>{available?'执行器已连接':'执行器未连接'}</strong><p>{available?(canRun?'准备完成，可以开始任务。':active?'状态来自执行器的实际事件。':task.run?'本次结果已保留。调整需求时新建方案。':'确认准备情况后再执行。'):(config?.executor?.reason || '连接执行器后可在这里运行；也可以复制交接。')}</p></div></div><div className="se-action-buttons">{active?<button className="se-button danger" disabled={Boolean(busy)} onClick={()=>onAction('cancel',{taskId:task.id})}><Icon name="stop"/>{busy==='cancel'?'正在取消…':'取消任务'}</button>:<><button className="se-button quiet" disabled={Boolean(busy)} onClick={()=>task.run?onRefine(task.request):onAction('plan',{taskId:task.id,baselineSha:task.sha,mode:['semantic','openrouter_semantic'].includes(plan.method)?'semantic':'local'})}>{task.run?'新建方案':busy==='plan'?'正在重新规划…':'重新规划'}</button><button className="se-button secondary" disabled={Boolean(busy)} onClick={copyHandoff}><Icon name="copy"/>{busy==='handoff'?'正在准备…':'复制交接'}</button><button className="se-button primary" disabled={!canRun || Boolean(busy)} onClick={()=>onAction('run',{taskId:task.id,baselineSha:task.sha})}><Icon name="play"/>{busy==='run'?'正在启动…':'开始任务'}</button></>}</div></footer>{handoff && <details className="se-handoff" open={copyState.startsWith('请') || undefined}><summary>{copyState || '交接内容（仅复制）'}</summary><textarea ref={copyRef} readOnly value={handoff} aria-label="任务交接内容，仅复制" rows={10}/></details>}
  </article>;
}

function DeploymentStatus({preview,busy,rechecking,onRecheck}) {
  const deployment=preview.deployment,checks=list(deployment?.checks),rollback=preview.operation==='rollback',attention=rollback?[]:checks.filter(item=>item.required!==false && item.status!=='present');
  const checkLabel={present:'已具备',missing:'缺少',unknown:'待核对',blocked:'阻止安装'};
  return <section className="se-deployment" aria-label={rollback?'恢复检查':'环境检查'}><div className="se-deployment-heading"><div><h3>{rollback?'恢复检查':'环境检查'}</h3><span className={`se-readiness ${rollback?'unknown':deployment?.status || 'unknown'}`}>{rollback?'运行状态待验证':deploymentLabel(deployment)}</span></div><button className="se-button secondary" disabled={busy || !preview.candidateId || !preview.previewSha} onClick={onRecheck}><Icon name="refresh"/>{rechecking?'正在检查…':'重新检查环境'}</button></div>
    {attention.length>0 && <ul className="se-deployment-attention">{attention.map((item,index)=><li key={item.id || index}><strong>{item.label}</strong><span className={item.status}>{checkLabel[item.status] || '待核对'}</span></li>)}</ul>}
    <p className="se-deployment-next">{rollback?'仅恢复备份文件；运行状态仍待验证。':deploymentNextAction(deployment)}</p>
    <p className="se-deployment-truth">宿主发现未验证 · 任务效果未测试</p>
    {(checks.length>0 || list(deployment?.blockers).length>0 || deployment?.nextAction) && <details className="se-deployment-checks"><summary>检查依据（{checks.length} 项{list(deployment?.blockers).length?` · ${deployment.blockers.length} 项阻止`:''}）</summary>{list(deployment?.blockers).length>0 && <ul className="se-deployment-blockers">{deployment.blockers.map((item,index)=><li key={index}>{typeof item==='string'?item:item.detail || item.label || words(item)}</li>)}</ul>}<dl>{checks.map((item,index)=><div key={item.id || index}><dt>{item.label}{item.required===false?'（可选）':''}</dt><dd><span className={`se-check-status ${item.status}`}>{checkLabel[item.status] || '待核对'}</span>{item.detail && <p>{item.detail}</p>}</dd></div>)}</dl>{deployment?.nextAction && <p className="se-deployment-raw-action">{deployment.nextAction}</p>}</details>}
  </section>;
}

function SourceWarnings({warnings}) {
  const items=list(warnings);
  return items.length?<details className="se-preview-evidence"><summary>来源检查提示（{items.length}）</summary>{items.map((item,index)=><p className="se-warning" key={index}>{words(item)}</p>)}</details>:null;
}

function Preview({preview,busy,rechecking,onInstall,onRecheck,onChoosePath,onClose}) {
  const [pane,setPane]=useState('content');useEffect(()=>setPane('content'),[preview?.candidateId]);if(!preview)return null;
  if(preview.status==='selection_required')return <section className="se-preview"><div className="se-section-heading"><h2>选择仓库中的技能</h2><button className="se-icon-button" aria-label="关闭来源预览" onClick={onClose}><Icon name="close"/></button></div><p className="se-secondary">仓库包含多个技能。选择一个完整目录进行预览。</p><ul className="se-path-choices">{list(preview.paths).map(path=><li key={path}><button onClick={()=>onChoosePath(path)} disabled={busy}><code>{path}</code><Icon name="chevron"/></button></li>)}</ul><SourceWarnings warnings={preview.warnings}/></section>;
  const source=preview.source || {},rollback=preview.operation==='rollback',deployment=preview.deployment;
  const blocked=(!rollback && !deploymentAllowsInstall(deployment)) || preview.targetStatus==='name_conflict';
  const licenseEvidence=source.licenseEvidence,evidenceRecord=licenseEvidence?.evidence || {},licenseUrl=evidenceRecord.url || evidenceRecord.evidence_url;
  const installLabel=rollback?'恢复此版本':preview.operation==='update'?(deployment?.status==='ready_for_install'?'采用此更新':'仅更新文件'):deployment?.status==='ready_for_install'?'安装此技能':'仅安装文件';
  return <section className="se-preview"><header className="se-preview-heading"><div><h2>{preview.name || source.path || source.repo}{rollback?' · 恢复预览':preview.operation==='update'?' · 更新预览':' · 安装预览'}</h2></div><button className="se-icon-button" aria-label="关闭来源预览" onClick={onClose}><Icon name="close"/></button></header>{preview.description && <p className="se-secondary">{preview.description}</p>}
    <DeploymentStatus preview={preview} busy={busy} rechecking={rechecking} onRecheck={onRecheck}/>
    {preview.targetStatus==='locally_modified' && <p className="se-warning">本地修改将被此完整版本替换；当前目录会先完整备份，请核对差异。</p>}
    {preview.diffTruncated && <p className="se-warning">文本差异已截断；采用前请核对文件清单、哈希与完整文件。</p>}
    <details className="se-preview-evidence"><summary>来源、许可与依赖</summary><dl className="se-preview-facts"><div><dt>来源</dt><dd><SourceLink url={source.url}>{source.kind==='local'?(source.label || '个人技能库'):(source.repo || 'GitHub')}</SourceLink></dd></div><div><dt>目录</dt><dd><code>{source.path || '仓库根目录'}</code></dd></div><div><dt>锁定版本</dt><dd><code title={source.revision || source.commit}>{shortSha(source.revision || source.commit)}</code></dd></div><div><dt>预览校验</dt><dd><code>{preview.previewSha}</code></dd></div><div><dt>适用许可</dt><dd>{licenseLabel(source.license)}{!licenseEvidence && <p>{source.kind==='local'?'个人库存在不代表再分发许可已核实；本次仅在本机采用。':'仅仓库元数据，适用范围待核对。'}</p>}</dd></div>{licenseEvidence && <div><dt>许可依据</dt><dd><SourceLink url={licenseUrl}>{evidenceRecord.license_path || licenseLabel(evidenceRecord)}</SourceLink><p><code>{licenseEvidence.entryPath} · {shortSha(licenseEvidence.commit)}</code></p></dd></div>}{source.repositoryLicense && <div><dt>仓库声明</dt><dd>{licenseLabel(source.repositoryLicense)}</dd></div>}<div><dt>本地目标</dt><dd><code>{preview.targetPath || preview.targetStatus || '待检查'}</code></dd></div></dl>{list(preview.requirements).length>0 && <div className="se-preview-requirements"><h3>依赖与要求</h3><ul>{preview.requirements.map((item,index)=><li key={index}>{words(item)}</li>)}</ul></div>}</details><SourceWarnings warnings={preview.warnings}/>
    <details className="se-preview-content"><summary>文件与变更证据</summary><div className="se-preview-tabs" role="tablist" aria-label="来源内容">{[['content','SKILL.md'],['files',`文件（${list(preview.files).length}）`],['diff','变更差异']].map(([id,label])=><button role="tab" tabIndex={pane===id?0:-1} onKeyDown={event=>{const keys=['content','files','diff'];let next;if(event.key==='ArrowRight')next=keys[(keys.indexOf(id)+1)%keys.length];if(event.key==='ArrowLeft')next=keys[(keys.indexOf(id)+keys.length-1)%keys.length];if(event.key==='Home')next=keys[0];if(event.key==='End')next=keys.at(-1);if(next){event.preventDefault();setPane(next);requestAnimationFrame(()=>document.getElementById(`preview-tab-${next}`)?.focus());}}} aria-selected={pane===id} aria-controls={`preview-${id}`} id={`preview-tab-${id}`} key={id} onClick={()=>setPane(id)}>{label}</button>)}</div><div className="se-preview-body" id={`preview-${pane}`} role="tabpanel" aria-labelledby={`preview-tab-${pane}`} tabIndex={0}>{pane==='files'?<ul className="se-file-list">{list(preview.files).map((file,index)=><li key={file.path || index}><div><code>{file.path}</code><code className="se-file-sha">SHA256 {file.sha256}</code></div><span>{file.bytes} B</span></li>)}</ul>:<pre>{pane==='content'?(preview.content || '来源未提供正文。'):(typeof preview.diff==='string'?preview.diff:words(preview.diff)) || '没有可展示的文本差异。'}</pre>}</div></details><div className="se-preview-apply"><p>{preview.targetStatus==='name_conflict'?'本地已有同名技能。请先在技能库核对，当前安装不会覆盖。':rollback?'仅恢复备份文件；运行状态仍待验证。':blocked?'请先完成环境检查或处理阻止项。':'只采用这份锁定预览；安装后仍需验证宿主发现与实际任务。'}</p><button className="se-button primary" disabled={busy || !preview.candidateId || !preview.previewSha || blocked} onClick={()=>onInstall(preview)}>{busy&&!rechecking?'正在应用…':installLabel}<Icon name="check"/></button></div>
  </section>;
}

function Discover({seed,taskId,onLibrary,onInstalled,catalogConfig,targetAgent='',onTargetAgent}) {
  const [query,setQuery]=useState(()=>taskDirectoryFilters(seed).query),[source,setSource]=useState('github'),[sort,setSort]=useState('stars');
  const [mode,setMode]=useState(targetAgent?'local':'curated'),[selectedCuratedId,setSelectedCuratedId]=useState(null),[curatedDeployments,setCuratedDeployments]=useState({});
  const [results,setResults]=useState(null),[local,setLocal]=useState([]),[preview,setPreview]=useState(null),[updates,setUpdates]=useState(null);
  const [busy,setBusy]=useState(''),[error,setError]=useState('');
  const [url,setUrl]=useState(''),[path,setPath]=useState(''),[ref,setRef]=useState(''),[showSource,setShowSource]=useState(false);
  const revision=useRef(0),controller=useRef(null),inspectPayload=useRef(null),previewRef=useRef(null);
  const [agentData,setAgentData]=useState(null),[agentLoading,setAgentLoading]=useState(true),[agentError,setAgentError]=useState('');
  const agentController=useRef(null);
  const refreshTargets=useCallback(async()=>{
    agentController.current?.abort();const next=new AbortController();agentController.current=next;
    setAgentLoading(true);setAgentError('');setAgentData(null);
    const timer=setTimeout(()=>next.abort('timeout'),15000);
    try {const data=await api('/api/agents',{signal:next.signal});if(!next.signal.aborted)setAgentData(data);}
    catch(err){if(agentController.current===next && (!next.signal.aborted || next.signal.reason==='timeout'))setAgentError(next.signal.reason==='timeout'?'目标目录检查超时，请重试。':err.message);}
    finally{clearTimeout(timer);if(agentController.current===next && (!next.signal.aborted || next.signal.reason==='timeout'))setAgentLoading(false);}
  },[]);
  useEffect(()=>{refreshTargets();return()=>{agentController.current?.abort();};},[refreshTargets]);
  useEffect(()=>{revision.current++;controller.current?.abort();setBusy('');setError('');setPreview(null);setUpdates(null);setSelectedCuratedId(null);setCuratedDeployments({});},[targetAgent]);
  const targetInfo=list(agentData?.agents).find(item=>item.id===targetAgent);
  const targetReady=!targetAgent || (!agentLoading && !agentError && targetInfo?.installation?.available===true);
  function changeTarget(id){revision.current++;controller.current?.abort();setBusy('');setPreview(null);setUpdates(null);setError('');setSelectedCuratedId(null);setCuratedDeployments({});onTargetAgent?.(id);}
  const loadCurated=useCallback(signal=>api('/api/catalog/curated',{signal}),[]);
  useEffect(()=>()=>{revision.current++;controller.current?.abort();},[]);
  function begin(kind) {controller.current?.abort();controller.current=new AbortController();const rev=++revision.current;setBusy(kind);setError('');return {rev,signal:controller.current.signal};}
  async function search(event,explicit) {event?.preventDefault();const text=(explicit ?? query).trim();if(!text)return;const {rev,signal}=begin('search');setResults(null);setPreview(null);try {const values=await Promise.allSettled([api(`/api/catalog?q=${encodeURIComponent(text)}&source=${source}&sort=${sort}`,{signal}),api('/api/inventory',{signal})]);if(rev!==revision.current)return;const external=values[0],inventory=values[1];if(inventory.status==='fulfilled'){const skills=list(inventory.value.librarySkills || inventory.value.skills),terms=text.toLowerCase().split(/\s+/);setLocal(skills.filter(item=>terms.some(term=>`${item.name} ${item.description}`.toLowerCase().includes(term))).slice(0,8));}else setLocal([]);if(external.status==='rejected')throw external.reason;setResults(external.value);}catch(err){if(err.name!=='AbortError' && rev===revision.current)setError(err.message);}finally{if(rev===revision.current)setBusy('');}}
  useEffect(()=>{setQuery(taskDirectoryFilters(seed).query);setMode(targetAgent?'local':'curated');},[seed]);
  async function inspect(payload) {if(!targetReady){setError('目标目录尚未通过检查，请刷新目标状态后再试。');return;}const {rev,signal}=begin('inspect');setPreview(null);setSelectedCuratedId(payload.curatedId || null);inspectPayload.current=payload;try{const value=await api(payload.skillId?'/api/catalog/local/inspect':'/api/catalog/inspect',{body:catalogTargetPayload(payload,targetAgent),signal});if(rev!==revision.current)return;setPreview(value);if(payload.curatedId && value.source?.curatedId===payload.curatedId && value.candidateId && value.previewSha && value.deployment)setCuratedDeployments(current=>({...current,[payload.curatedId]:value.deployment}));requestAnimationFrame(()=>previewRef.current?.scrollIntoView({behavior:'auto',block:'start'}));}catch(err){if(err.name!=='AbortError' && rev===revision.current)setError(err.message);}finally{if(rev===revision.current)setBusy('');}}
  async function recheck() {
    if(!preview?.candidateId || !preview?.previewSha || busy)return;
    const identity={candidateId:preview.candidateId,previewSha:preview.previewSha},{rev,signal}=begin('preflight');
    try {const value=await api('/api/catalog/preflight',{body:catalogTargetPayload(identity,targetAgent),signal});if(rev!==revision.current)return;const next=mergePreflight(preview,value,identity);setPreview(current=>current?.candidateId===identity.candidateId && current?.previewSha===identity.previewSha?{...current,deployment:next.deployment}:current);if(selectedCuratedId && preview.source?.curatedId===selectedCuratedId)setCuratedDeployments(current=>({...current,[selectedCuratedId]:next.deployment}));}catch(err){if(err.name!=='AbortError' && rev===revision.current)setError(`${err.message}${err.status===409?' 请重新预览当前版本。':''}`);}finally{if(rev===revision.current)setBusy('');}
  }
  async function install(value) {
    if(busy || !targetReady || (value.operation!=='rollback' && !deploymentAllowsInstall(value.deployment)) || !value.candidateId || !value.previewSha || value.targetStatus==='name_conflict')return;
    const {rev,signal}=begin('install'),linkedTaskId=targetAgent?undefined:taskId;
    try {
      const payload={candidateId:value.candidateId,previewSha:value.previewSha,...(value.baselineSha?{baselineSha:value.baselineSha}:{}),...(linkedTaskId?{taskId:linkedTaskId}:{}),...(value.operation==='rollback'?{managedId:value.managedId,versionId:value.versionId}:{})};
      const result=await api(value.operation==='rollback'?'/api/catalog/rollback':'/api/catalog/install',{body:catalogTargetPayload(payload,targetAgent),signal});
      if(rev!==revision.current)return;
      if(selectedCuratedId && value.source?.curatedId===selectedCuratedId && result.source?.curatedId===selectedCuratedId && result.installed)setCuratedDeployments(current=>({...current,[selectedCuratedId]:result.deployment || {status:'installed_unverified',installAllowed:false}}));setPreview(null);setSelectedCuratedId(null);setUpdates(null);onInstalled(result,linkedTaskId);
    } catch(err) {if(err.name!=='AbortError' && rev===revision.current)setError(`${err.message}${err.status===409?' 请重新预览当前版本。':''}`);}
    finally {if(rev===revision.current)setBusy('');}
  }
  async function checkUpdates() {const {rev,signal}=begin('updates');try{const value=await api(catalogTargetPath('/api/catalog/updates',targetAgent),{signal});if(rev===revision.current)setUpdates(value);}catch(err){if(err.name!=='AbortError' && rev===revision.current)setError(err.message);}finally{if(rev===revision.current)setBusy('');}}
  return <main className="se-discover"><header className="se-page-heading"><div><h1>{targetAgent?'添加 Skills':'发现'}</h1></div><button className="se-button secondary" disabled={Boolean(busy)} onClick={checkUpdates}><Icon name="refresh"/>{busy==='updates'?'正在检查…':'检查已安装更新'}</button></header>
    <div className="se-agent-target"><label htmlFor="catalog-agent-target">安装到<select id="catalog-agent-target" aria-label="安装到" value={targetAgent} disabled={Boolean(busy) || agentLoading} onChange={event=>changeTarget(event.target.value)}><option value="">编辑器个人库</option>{targetAgent && !targetInfo && <option value={targetAgent}>{targetAgent}{agentLoading?'（读取中）':'（待检查）'}</option>}{list(agentData?.agents).map(item=><option key={item.id} value={item.id} disabled={item.installation?.available!==true}>{item.name}{item.installation?.available!==true?'（目录不可用）':''}</option>)}</select></label><div className="se-agent-target-directory"><code>{targetAgent?(targetInfo?.installation?.targetPath || '正在核对所选 Agent 目录…'):(catalogConfig?.installRoot || '当前配置的个人技能目录')}</code>{targetInfo?.installation?.shared && <p>共享目录，其他兼容 Agent 也可能读取。</p>}{targetAgent && targetInfo && !targetInfo.installation?.available && <p role="alert">{targetInfo.installation?.reason || '目标目录不可用。'}</p>}{agentError && <p role="alert">{agentError} <button className="se-button quiet" disabled={Boolean(busy)} onClick={refreshTargets}>重试检查</button></p>}</div></div>
    <div className="se-discovery-modes"><div role="group" aria-label="发现范围">{[['local','我的 Skills'],['curated','精选目录'],['public','公开搜索']].map(([id,label])=><button className={mode===id?'active':''} key={id} aria-pressed={mode===id} disabled={Boolean(busy)} onClick={()=>setMode(id)}>{label}</button>)}</div><button className="se-button quiet" disabled={Boolean(busy)} onClick={()=>setShowSource(!showSource)} aria-expanded={showSource}>GitHub 地址预览</button></div>
    {mode==='public' && <><form className="se-discover-search" onSubmit={search}><label><Icon name="search"/><span className="se-sr-only">公开搜索词</span><input disabled={Boolean(busy)} value={query} onChange={event=>setQuery(event.target.value)} placeholder="搜索公开技能、仓库或能力" maxLength={180}/></label><button className="se-button primary" type="submit" disabled={!query.trim() || Boolean(busy)}>{busy==='search'?'搜索中…':`搜索 ${source==='github'?'GitHub':'skills.sh'}`}</button></form><div className="se-search-controls"><label>公开来源<select disabled={Boolean(busy)} value={source} onChange={event=>{revision.current++;controller.current?.abort();setBusy('');setResults(null);setLocal([]);setSource(event.target.value);}}><option value="github">GitHub</option><option value="skills">skills.sh</option></select></label>{source==='github'?<label>排序<select disabled={Boolean(busy)} value={sort} onChange={event=>{revision.current++;controller.current?.abort();setBusy('');setResults(null);setSort(event.target.value);}}><option value="stars">仓库星数</option><option value="updated">最近更新</option></select></label>:<span className="se-secondary">按目录相关性排序</span>}</div><p className="se-search-disclosure">点击搜索后，关键词发送至所选来源。星数与安装量仅用于发现。</p></>}
    {showSource && <form className="se-source-form" onSubmit={event=>{event.preventDefault();inspect({url:url.trim(),...(path.trim()?{path:path.trim()}:{}),...(ref.trim()?{ref:ref.trim()}:{}),operation:'install'});}}><h2>预览准确来源</h2><label>GitHub 地址<input type="url" disabled={Boolean(busy)} value={url} onChange={event=>setUrl(event.target.value)} placeholder="https://github.com/owner/repo" required/></label><div><label>技能目录（可选）<input disabled={Boolean(busy)} value={path} onChange={event=>setPath(event.target.value)} placeholder="skills/example"/></label><label>分支或版本（可选）<input disabled={Boolean(busy)} value={ref} onChange={event=>setRef(event.target.value)} placeholder="默认分支"/></label></div><button type="submit" className="se-button secondary" disabled={!url.trim() || Boolean(busy)}>读取完整目录</button></form>}
    {error && <Message>{error}</Message>}{busy==='inspect' && <Message tone="info">正在读取来源并锁定版本…</Message>}
    {(targetAgent?[...list(preview?.target?.recoveryWarnings),...list(preview?.target?.journalWarnings),...list(updates?.target?.recoveryWarnings),...list(updates?.target?.journalWarnings)]:[...list(catalogConfig?.recoveryWarnings),...list(catalogConfig?.journalWarnings)]).map((warning,index)=><Message tone="info" key={index}>目录事务提示：{warningText(warning)}</Message>)}
    {updates && <section className="se-updates"><div className="se-section-heading"><h2>此目标的 Skills</h2><button className="se-button quiet" onClick={()=>setUpdates(null)}>收起</button></div>{!list(updates.installs).length && <p className="se-secondary">此目标还没有通过应用采用的 Skills。</p>}{list(updates.warnings).map((item,index)=><p className="se-warning" key={index}>{words(item)}</p>)}<ul>{list(updates.installs).map(item=><li key={item.managedId}><div><h3>{item.name}</h3><p>{item.source?.label || item.source?.repo} · {shortSha(item.currentRevision || item.currentCommit)}</p>{item.locallyModified && <p className="se-warning">本地有修改，采用更新前需要核对差异。</p>}</div><div className="se-update-actions">{item.hasUpdate?<button className="se-button secondary" disabled={Boolean(busy)} onClick={()=>inspect({operation:'update',managedId:item.managedId})}>预览更新</button>:<span className="se-secondary">{item.latestRevision || item.latestCommit?'未发现新版本':item.source?.kind==='local'?'原个人包状态未知':'上游状态未知'}</span>}{list(item.versions).length>0 && <label className="se-version-select"><span className="se-sr-only">选择要恢复的版本</span><select value="" aria-label={`恢复 ${item.name} 的历史版本`} disabled={Boolean(busy)} onChange={event=>{if(event.target.value)inspect({operation:'rollback',managedId:item.managedId,versionId:event.target.value});}}><option value="">预览历史版本…</option>{item.versions.map(version=><option key={version.versionId} value={version.versionId}>{stamp(version.createdAt)} · {shortSha(version.source?.revision || version.source?.commit || version.sha)}</option>)}</select></label>}</div></li>)}</ul></section>}
    <div ref={previewRef}><Preview preview={preview} busy={Boolean(busy) || !targetReady} rechecking={busy==='preflight'} onRecheck={recheck} onInstall={install} onClose={()=>{revision.current++;controller.current?.abort();setBusy('');setPreview(null);setSelectedCuratedId(null);}} onChoosePath={selectedPath=>inspect({...inspectPayload.current,path:selectedPath.replace(/\/?SKILL\.md$/,'')})}/></div>
    {mode==='local' && <LocalSkillPicker targetAgent={targetAgent} disabled={Boolean(busy) || !targetReady} onInspect={item=>inspect({...item,operation:'install'})} onDiscover={()=>setMode('curated')}/>}
    <div hidden={mode!=='curated'}><CuratedCatalog query={query} onQueryChange={setQuery} initialCategory={taskDirectoryFilters(seed).category} loadCatalog={loadCurated} busy={Boolean(busy) || !targetReady} selectedId={selectedCuratedId} deployments={curatedDeployments} onInspect={entry=>inspect({curatedId:entry.id,operation:'install'})}/></div>
    {mode==='public' && local.length>0 && <section className="se-local-results"><div className="se-section-heading"><h2>本地已有</h2><span>文件记录，不代表已激活</span></div><ul>{local.map(item=><li key={item.id}><button onClick={()=>onLibrary(item.id)}><div><h3>{item.name}</h3><p>{item.description}</p></div><Icon name="chevron"/></button></li>)}</ul></section>}
    {mode==='public' && results && <section className="se-remote-results"><div className="se-section-heading"><h2>{source==='github'?'GitHub 公开结果':'skills.sh 公开结果'}</h2><span>{results.cached?'缓存结果':stamp(results.fetchedAt)}</span></div>{list(results.warnings).map((item,index)=><p className="se-warning" key={index}>{words(item)}</p>)}{!list(results.results).length?<p className="se-empty-result">没有匹配结果。换一个能力关键词，或直接预览准确的 GitHub 地址。</p>:<ul>{results.results.map((item,index)=><li key={item.id || item.repo || index}><div className="se-result-main"><SourceLink url={item.url}><h3>{item.name || item.repo}</h3></SourceLink><p>{item.description || '来源未提供简介。'}</p><div className="se-result-meta"><span>{item.repo}</span>{item.stars!=null && <span>仓库星数 {Number(item.stars).toLocaleString()}</span>}{item.installs!=null && <span>技能安装量 {Number(item.installs).toLocaleString()}</span>}{item.updatedAt && <span>更新于 {stamp(item.updatedAt)}</span>}{item.warning && <span>{item.warning}</span>}</div></div><button className="se-button secondary" disabled={Boolean(busy) || item.installable===false || !item.url} onClick={()=>inspect({url:item.url,path:item.path || undefined,ref:item.defaultBranch || undefined,operation:'install'})}>{item.installable===false?'来源暂不支持':'预览来源'}<Icon name="chevron"/></button></li>)}</ul>}</section>}
  </main>;
}

export default function App() {
  const [tab,setTab]=useState('agents'),[config,setConfig]=useState(null),[configError,setConfigError]=useState('');
  const [tasks,setTasks]=useState([]),[historyLoading,setHistoryLoading]=useState(true),[historyError,setHistoryError]=useState('');
  const [task,setTask]=useState(null),[selected,setSelected]=useState(null),[taskLoading,setTaskLoading]=useState(false),[events,setEvents]=useState([]);
  const [draft,setDraft]=useState(''),[busy,setBusy]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState(''),[seed,setSeed]=useState(''),[syncing,setSyncing]=useState(false);
  const [targetAgent,setTargetAgent]=useState('');
  const [librarySelection,setLibrarySelection]=useState(null),[libraryRevision,setLibraryRevision]=useState(0);
  const inputRef=useRef(null),selectionRevision=useRef(0),readController=useRef(null),actionController=useRef(null),historyController=useRef(null),configController=useRef(null),catalogTaskController=useRef(null),mounted=useRef(true),appliedVersions=useRef(new Map()),currentSelected=useRef(selected);
  currentSelected.current=selected;
  const refreshConfig=useCallback(async()=>{configController.current?.abort();const controller=new AbortController();configController.current=controller;try{const value=await api('/api/engine/config',{signal:controller.signal});if(!controller.signal.aborted){setConfig(value);setConfigError('');}}catch(err){if(err.name!=='AbortError')setConfigError(err.message);}},[]);
  const refreshHistory=useCallback(async()=>{historyController.current?.abort();const controller=new AbortController();historyController.current=controller;setHistoryLoading(true);try{const value=await api('/api/tasks',{signal:controller.signal});if(!controller.signal.aborted){setTasks(previous=>{const incoming=list(value.tasks),byId=new Map(incoming.map(item=>[item.id,item]));for(const item of previous){const current=byId.get(item.id);if(!current || (item.updatedAt || '')>(current.updatedAt || ''))byId.set(item.id,item);}return [...byId.values()].sort((a,b)=>(b.updatedAt || '').localeCompare(a.updatedAt || ''));});setHistoryError('');}}catch(err){if(err.name!=='AbortError')setHistoryError(err.message);}finally{if(!controller.signal.aborted)setHistoryLoading(false);}},[]);
  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;selectionRevision.current++;readController.current?.abort();actionController.current?.abort();historyController.current?.abort();configController.current?.abort();catalogTaskController.current?.abort();};},[refreshConfig,refreshHistory]);
  useEffect(()=>{if(tab==='task' || tab==='discover'){refreshConfig();if(tab==='task')refreshHistory();}},[tab,refreshConfig,refreshHistory]);
  const applyTask=useCallback(value=>{const next=taskFrom(value);if(!next?.id)return;const sequence=list(next.events).at(-1)?.sequence || 0,previousVersion=appliedVersions.current.get(next.id);if(previousVersion && sequence<previousVersion.sequence)return;appliedVersions.current.set(next.id,{sequence,sha:next.sha});setTask(next);setEvents(list(next.events));setTasks(previous=>[next,...previous.filter(item=>item.id!==next.id)]);},[]);
  const openTask=useCallback(async id=>{actionController.current?.abort();setBusy('');setSelected(id);setTab('task');setTask(null);setEvents([]);setError('');setNotice('');setTaskLoading(true);const rev=++selectionRevision.current;readController.current?.abort();const controller=new AbortController();readController.current=controller;try{const value=await api(`/api/task?id=${encodeURIComponent(id)}`,{signal:controller.signal});if(rev===selectionRevision.current)applyTask(value);}catch(err){if(err.name!=='AbortError' && rev===selectionRevision.current)setError(err.message);}finally{if(rev===selectionRevision.current)setTaskLoading(false);}},[applyTask]);
  function newTask() {selectionRevision.current++;readController.current?.abort();actionController.current?.abort();setSelected(null);setTask(null);setEvents([]);setTaskLoading(false);setBusy('');setError('');setNotice('');setTab('task');requestAnimationFrame(()=>inputRef.current?.focus());}
  async function createTask(mode) {if(!draft.trim() || busy)return;const rev=++selectionRevision.current;actionController.current?.abort();const controller=new AbortController();actionController.current=controller;setBusy('create');setError('');try{const value=taskFrom(await api('/api/tasks',{body:{request:draft.trim(),mode},signal:controller.signal}));if(rev!==selectionRevision.current)return;setSelected(value.id);applyTask(value);setDraft('');}catch(err){if(err.name!=='AbortError' && rev===selectionRevision.current)setError(err.message);}finally{if(rev===selectionRevision.current)setBusy('');}}
  async function taskAction(action,payload) {if(busy)return;const rev=selectionRevision.current;actionController.current?.abort();const controller=new AbortController();actionController.current=controller;setBusy(action);setError('');try{const value=await api(`/api/task/${action}`,{body:payload,signal:controller.signal});if(rev!==selectionRevision.current)return null;if(action!=='handoff'){const updated=taskFrom(value);if(updated?.id && updated?.status)applyTask(updated);else{const fresh=await api(`/api/task?id=${encodeURIComponent(payload.taskId)}`,{signal:controller.signal});if(rev===selectionRevision.current)applyTask(fresh);}}return value;}catch(err){if(err.name!=='AbortError' && rev===selectionRevision.current){setError(err.message);if(err.status===409){try{const fresh=await api(`/api/task?id=${encodeURIComponent(payload.taskId)}`,{signal:controller.signal});if(rev===selectionRevision.current)applyTask(fresh);}catch{}}}return null;}finally{if(rev===selectionRevision.current)setBusy('');}}
  useEffect(()=>{if(!selected || !ACTIVE.has(task?.status))return;const controller=new AbortController(),rev=selectionRevision.current;let timeout;const tick=async()=>{try{const value=await api(`/api/task?id=${encodeURIComponent(selected)}`,{signal:controller.signal});if(!controller.signal.aborted && rev===selectionRevision.current)applyTask(value);}catch(err){if(err.name!=='AbortError' && rev===selectionRevision.current)setError(`执行状态读取失败：${err.message}`);}if(!controller.signal.aborted)timeout=setTimeout(tick,2200);};timeout=setTimeout(tick,1000);return()=>{controller.abort();clearTimeout(timeout);};},[selected,task?.status,applyTask]);
  async function sync() {
    if(syncing)return;
    setSyncing(true);setNotice('');
    try {
      const result=await api('/api/engine/sync',{body:{}});
      if(!mounted.current)return;
      const warnings=[...new Set([...list(result.scanWarnings),...list(result.warnings)].map(warningText).filter(Boolean))];
      setLibraryRevision(value=>value+1);
      setNotice(warnings.length?`本地索引已刷新，但有 ${warnings.length} 项扫描提示，部分来源仍需核对。\n${warnings.join('\n')}\n已有任务的方案需要重新规划后才会更新。`:'本地索引已刷新。已有任务的方案需要重新规划后才会更新。');
      refreshConfig();
    } catch(err) {if(mounted.current)setNotice(`同步未完成：${err.message}`);}
    finally {if(mounted.current)setSyncing(false);}
  }
  function discover(query) {setTargetAgent('');setSeed(query || '');setTab('discover');}
  async function installed(result,linkedTaskId) {
    const outcome=catalogOutcome(result),rev=selectionRevision.current;
    setLibraryRevision(value=>value+1);refreshConfig();refreshHistory();
    setNotice([outcome.summary,...outcome.issues,result.task?'关联任务已返回新的规划记录。':''].filter(Boolean).join('\n'));
    if(result.task?.id) {
      if(result.task.id===currentSelected.current)applyTask(result.task);
      return;
    }
    if(!linkedTaskId || linkedTaskId!==currentSelected.current)return;
    catalogTaskController.current?.abort();const controller=new AbortController();catalogTaskController.current=controller;
    try {
      const fresh=await api(`/api/task?id=${encodeURIComponent(linkedTaskId)}`,{signal:controller.signal});
      if(!controller.signal.aborted && mounted.current && rev===selectionRevision.current && currentSelected.current===linkedTaskId)applyTask(fresh);
    } catch(err) {
      if(err.name!=='AbortError' && mounted.current && rev===selectionRevision.current && currentSelected.current===linkedTaskId)setNotice(previous=>`${previous}\n任务当前状态读取失败：${err.message}`);
    }
  }
  return <div className="se-app se-agent-scene">
    <a className="se-skip-link" href="#engine-content">跳到主要内容</a>
    <header className="se-topbar">
      <button className="se-brand" aria-label="Skill Engine，Agent 首页" onClick={()=>setTab('agents')}><svg className="se-brand-symbol" viewBox="0 0 28 30" fill="none" aria-hidden="true"><path d="m14 2 11 6-11 6L3 8 14 2Z" stroke="currentColor" strokeWidth="1.6"/><path d="m3 15 11 6 11-6M3 22l11 6 11-6" stroke="currentColor" strokeWidth="1.6"/></svg>Skill Engine</button>
      <nav className="se-topnav" aria-label="主导航">{[['agents','Agent','agent'],['library','我的技能','library'],['discover','发现','search'],['task','任务','file']].map(([id,label,icon])=><button key={id} aria-current={tab===id?'page':undefined} className={tab===id?'active':''} onClick={()=>{setTab(id);if(id==='discover')setSeed('');}}><Icon name={icon} className="se-nav-icon"/>{label}</button>)}</nav>
      <AppMenu config={config} error={configError} onRefresh={refreshConfig} onSync={sync} syncing={syncing}/>
    </header>
    {tab!=='task' && notice && <div className="se-global-notice"><Message tone="info">{notice}</Message></div>}
    <div id="engine-content" className={`se-content se-view-${tab}`} tabIndex={-1}>
      {tab==='agents'?<AgentWorkspace key={libraryRevision} onLibrary={()=>setTab('library')} onDiscover={id=>{setTargetAgent(id || '');setSeed('');setTab('discover');}} onTask={newTask}/>:tab==='task'?<>
        <TaskHistory tasks={tasks} selected={selected} loading={historyLoading} error={historyError} onSelect={openTask} onNew={newTask} onRetry={refreshHistory}/>
        <main className={`se-task-main ${selected?'has-task':''}`}>
          {notice && <Message tone="info">{notice}</Message>}
          {selected?(taskLoading?<div className="se-loading" role="status"><Icon name="refresh"/><p>正在读取任务…</p></div>:task?<TaskPanel task={task} events={events} config={config} busy={busy} error={error} onAction={taskAction} onDiscover={discover} onError={setError} onRefine={request=>{newTask();setDraft(request);}}/>:<Message onRetry={()=>openTask(selected)}>{error || '任务暂时不可读取。'}</Message>):<Composer value={draft} onChange={setDraft} onSubmit={createTask} busy={busy==='create'} config={config} error={error} inputRef={inputRef}/>}
        </main>
      </>:tab==='library'?<Library key={libraryRevision} initialSkill={librarySelection}/>:<Discover seed={seed} taskId={task?.id} catalogConfig={config?.catalog} targetAgent={targetAgent} onTargetAgent={setTargetAgent} onLibrary={id=>{setLibrarySelection(id);setTab('library');}} onInstalled={installed}/>}
    </div>
  </div>;
}
