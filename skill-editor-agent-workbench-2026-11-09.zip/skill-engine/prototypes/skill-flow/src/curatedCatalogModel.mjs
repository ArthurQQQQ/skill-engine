const list=value=>Array.isArray(value)?value:[];

export function taskDirectoryFilters(seed='') {
  const query=typeof seed==='string'?seed:'';
  const categories={web_design:'design',development:'app',debugging:'testing',ui_review:'design',research:'research',paper_writing:'writing',paper_review:'research',writing:'writing',document:'office',pdf:'office',presentation:'office',data:'office',visualization:'analysis',scheduling:'knowledge',files:'knowledge'};
  const role=query.startsWith('agent skill ')?query.slice(12).replaceAll(' ','_'):'';
  return Object.hasOwn(categories,role)?{query:'',category:categories[role]}:{query,category:''};
}

export function filterCuratedEntries(entries,{query='',category='',use=''}={}) {
  const terms=query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  return list(entries).filter(entry=>{
    if(category && entry.category!==category && !list(entry.functionTags).includes(category))return false;
    if(use && !list(entry.useCases).includes(use))return false;
    const text=[entry.name,entry.title,entry.description,entry.source?.repo,...list(entry.requirements),...list(entry.limitations)].join(' ').toLocaleLowerCase();
    return terms.every(term=>text.includes(term));
  });
}

export function deploymentLabel(deployment) {
  return {blocked:'暂不能安装',needs_setup:'需准备环境',ready_for_install:'可安装文件',installed_unverified:'已安装 · 宿主待验证'}[deployment?.status] || '待检查环境';
}

export function deploymentNextAction(deployment) {
  return {blocked:'先处理阻止项，再重新检查；详细原因见检查依据。',needs_setup:deployment?.installAllowed?'可先安装文件。补齐列出的依赖与任务环境后，再验证宿主发现与实际任务。':'请补齐列出的依赖与任务环境，再重新检查。',ready_for_install:'安装锁定目录，再到目标宿主验证发现与实际任务。',installed_unverified:'在目标宿主确认发现，补齐任务环境，再验证一个实际任务。'}[deployment?.status] || '环境状态待确认，请重新检查并核对检查依据。';
}

export function deploymentAllowsInstall(deployment) {
  return ['ready_for_install','needs_setup'].includes(deployment?.status) && deployment.installAllowed===true;
}

export function curatedReadiness(entry) {
  if(entry.decision==='hold')return '暂缓采用';
  if(entry.deployment && typeof entry.deployment==='object')return deploymentLabel(entry.deployment);
  return entry.decision==='candidate_core_only'?'需限定安装分支':'待检查环境';
}

export function licenseLabel(license) {
  if(typeof license==='string')return license;
  return license?.applicable_license || license?.spdx || license?.repo_api_spdx || '未确认';
}

export function mergePreflight(current,response,identity) {
  if(!current || current.candidateId!==identity.candidateId || current.previewSha!==identity.previewSha)return current;
  if(response?.candidateId!==identity.candidateId || response?.previewSha!==identity.previewSha)throw new Error('环境检查返回的预览版本不一致，请重新预览。');
  if(!response.deployment || typeof response.deployment!=='object')throw new Error('环境检查未返回部署状态，请重试。');
  return {...current,deployment:response.deployment};
}
