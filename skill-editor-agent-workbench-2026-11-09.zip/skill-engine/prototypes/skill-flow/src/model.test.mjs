import test from 'node:test';
import assert from 'node:assert/strict';
import {buildGraph,selectSkills,skillMeta} from './model.mjs';

const mainPlugin={id:'plugin-v1',name:'example',source:'plugin',path:'/skills/cache/example/1.0.0/SKILL.md',fileStatus:'present'};
const secondVersion={...mainPlugin,id:'plugin-v2',path:'/skills/cache/example/2.0.0/SKILL.md',inventoryRole:'cache-only'};
const missingVersion={...mainPlugin,id:'plugin-missing',path:'/skills/cache/example/0.1.0/SKILL.md',fileStatus:'missing'};
const personal={id:'personal',name:'personal',source:'personal',path:'/skills/personal/SKILL.md',fileStatus:'present'};
const records=[personal,mainPlugin,{...mainPlugin,id:'duplicate-cache-copy'},secondVersion,missingVersion];

test('browse current files once while preserving distinct plugin versions',()=>{
  const visible=selectSkills(records,{source:'all'});
  assert.deepEqual(visible.map(item=>item.id),['personal','plugin-v1','plugin-v2']);
});

test('cache-only metadata cannot claim session availability or editability',()=>{
  const meta=skillMeta({...secondVersion,editable:true,sessionAvailable:true});
  assert.equal(meta.editable,false);
  assert.equal(meta.sourceLabel,'插件缓存');
  assert.equal(meta.sessionLabel,'当前会话可用性未知');
  assert.equal(meta.statusLabel,'缓存只读');
  assert.equal(meta.versionLabel,'2.0.0');
});

test('first view shows actual skills and matching purpose counts',()=>{
  const overview=buildGraph(records,{source:'all'});
  assert.equal(overview.visibleSkills.length,3);
  assert.deepEqual(overview.nodes.filter(node=>node.type==='skill').map(node=>node.id),['personal','plugin-v1','plugin-v2']);
  assert.equal(overview.nodes.filter(node=>node.type==='group').reduce((sum,node)=>sum+node.data.count,0),3);
  assert.equal(overview.nodes.some(node=>node.type==='category'),false);
  const plugins=buildGraph(records,{source:'plugin',category:'other'});
  assert.deepEqual(plugins.nodes.map(node=>node.id),['plugin-v1','plugin-v2']);
});

test('purpose stays independent from a skill source',()=>{
  const pluginWriter={...mainPlugin,name:'paper-writing'};
  const systemInstaller={id:'installer',name:'skill-installer',source:'system'};
  assert.equal(skillMeta(pluginWriter).categoryId,'writing');
  assert.equal(skillMeta(systemInstaller).categoryId,'tools');
  assert.equal(selectSkills([pluginWriter],{source:'plugin',category:'writing'}).length,1);
});

test('original identities remain searchable and moved positions survive filtering',()=>{
  const writer={...personal,name:'paper-writing'};
  const graph=buildGraph([writer],{source:'personal',query:'paper-writing',positions:{personal:{x:123,y:456}}});
  assert.equal(graph.nodes.length,1);
  assert.deepEqual(graph.nodes[0].position,{x:123,y:456});
  assert.equal(graph.nodes[0].data.name,'paper-writing');
});
