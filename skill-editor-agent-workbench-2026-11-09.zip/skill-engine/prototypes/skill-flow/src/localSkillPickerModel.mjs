const record=value=>value!==null && typeof value==='object' && !Array.isArray(value);
const scalar=value=>value==null || typeof value==='string' || typeof value==='number' || typeof value==='boolean';
const identifier=value=>typeof value==='string' && value.trim().length>0 && value===value.trim();

export function localSkillText(value,missing='未提供') {
  if(value==null || value==='')return missing;
  if(typeof value==='string')return value;
  try {return JSON.stringify(value) ?? missing;}catch{return missing;}
}

function inventoryRecords(inventory) {
  if(!record(inventory))throw new Error('个人库返回内容无效，请重新读取。');
  if(inventory.error!=null)throw new Error(localSkillText(inventory.error,'读取个人库失败，请重试。'));
  if(Array.isArray(inventory.librarySkills))return inventory.librarySkills;
  if(Array.isArray(inventory.skills))return inventory.skills;
  throw new Error('个人库未返回有效的技能列表，请重新读取。');
}

function personalEntryPath(path,root) {
  if(typeof path!=='string' || !path.startsWith('/') || !path.endsWith('/SKILL.md') || /[\u0000-\u001f\\]/.test(path))return false;
  const parts=path.slice(1).split('/');
  if(parts.length<2 || parts.some(part=>!part || part==='.' || part==='..'))return false;
  if(path.startsWith('/Volumes/') || parts.includes('.system') || path.includes('/plugins/cache/'))return false;
  if(typeof root==='string' && root.length>0) {
    const prefix=root.replace(/\/+$/,'')+'/';
    if(!path.startsWith(prefix))return false;
    const relative=path.slice(prefix.length).split('/');
    if(relative.length!==2 || relative[0].startsWith('.'))return false;
  }
  return true;
}

export function selectAdoptableLocalSkills(inventory,query='') {
  const records=inventoryRecords(inventory),root=inventory.scope?.personalRoot;
  const identities=new Map(),ambiguous=new Set();
  for(const item of records) {
    if(!record(item) || !identifier(item.id) || typeof item.path!=='string' || typeof item.source!=='string')continue;
    const identity=`${item.source}\0${item.path}`;
    if(identities.has(item.id) && identities.get(item.id)!==identity)ambiguous.add(item.id);
    identities.set(item.id,identity);
  }
  const terms=(typeof query==='string'?query:'').trim().toLocaleLowerCase().split(/\s+/).filter(Boolean),seen=new Set();
  return records.filter(item=>{
    if(!record(item) || !identifier(item.id) || ambiguous.has(item.id) || seen.has(item.id))return false;
    if(item.source!=='personal' || item.editable!==true || (item.inventoryRole!=null && item.inventoryRole!=='main'))return false;
    if(item.fileStatus!=='present' || item.presentOnDisk!==true || !personalEntryPath(item.path,root))return false;
    if(!scalar(item.name) || !scalar(item.description))return false;
    seen.add(item.id);
    const text=[item.name,item.description,item.source,item.path].map(value=>localSkillText(value,'')).join(' ').toLocaleLowerCase();
    return terms.every(term=>text.includes(term));
  });
}

export function localSkillChangeEvidence(inventory,skill) {
  if(!record(skill))return {status:'unknown'};
  const changes=Array.isArray(inventory?.delta?.changed)?inventory.delta.changed:[];
  const change=changes.find(item=>record(item) && item.id===skill.id && item.path===skill.path && item.source===skill.source
    && typeof item.beforeSha==='string' && item.beforeSha.length>0 && typeof item.afterSha==='string' && item.afterSha.length>0
    && item.beforeSha!==item.afterSha && item.afterSha===skill.sha256);
  return change?{status:'changed-since-scan',beforeSha:change.beforeSha,afterSha:change.afterSha}:{status:'unknown'};
}
