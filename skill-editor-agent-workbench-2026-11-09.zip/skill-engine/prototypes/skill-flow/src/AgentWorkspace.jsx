import React, {useCallback, useEffect, useId, useReducer, useRef} from 'react';
import {
  agentCountLabel,
  agentDetectionLabel,
  agentWorkspaceReducer,
  fileCountLabel,
  initialAgentWorkspaceState,
  normalizeAgentSnapshot,
  rootScopeLabel,
  rootStatusLabel,
} from './agentWorkspaceModel.mjs';

function Icon({name,className=''}) {
  const shapes = {
    refresh:<><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6 6a8 8 0 0 1 13 3M18 18a8 8 0 0 1-13-3"/></>,
    arrow:<path d="M5 12h14m-6-6 6 6-6 6"/>,
    chevron:<path d="m9 5 7 7-7 7"/>,
    add:<path d="M12 5v14M5 12h14"/>,
    host:<><rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 9h16M8 13h3m-3 3h7"/></>,
  };
  return <svg className={`aw-icon ${className}`} width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{shapes[name] || shapes.host}</svg>;
}

function FlowSymbol({source=false}) {
  return <svg className="aw-flow-symbol" width="72" height="72" viewBox="0 0 72 72" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {source ? <><path d="M15 49H9V12h31v6M23 57h-6V20h31v6"/><path d="M25 28h28l10 10v27H25ZM53 28v10h10M33 47h22M33 54h16"/></> : <><rect x="10" y="10" width="52" height="52" rx="10"/><path d="M10 26h52M21 38l8 7-8 7m17 0h13"/><circle cx="20" cy="18" r="1"/><circle cx="27" cy="18" r="1"/></>}
  </svg>;
}

function checkedAtLabel(value) {
  if (!value) return '检测时间未提供';
  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) return '检测时间未提供';
  return `检测于 ${date.toLocaleString('zh-CN',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})}`;
}

function compactCount(agent) {
  if (agent.skillCount === null) return '未知';
  if (!agent.countComplete && agent.skillCount === 0) return '未完整';
  return `${agent.countComplete ? '' : '≥ '}${agent.skillCount.toLocaleString('zh-CN')} 个`;
}

const evidenceStatus = {
  present:'已找到',
  missing:'未找到',
  symlink_skipped:'符号链接未读取',
  external_skipped:'外置路径未读取',
  unavailable:'读取失败',
  not_executable:'文件不可执行',
  not_directory:'路径不是目录',
};

async function readSnapshot(signal) {
  let response;
  try {
    response = await fetch('/api/agents',{method:'GET',signal,cache:'no-store',credentials:'same-origin'});
  } catch (error) {
    if (signal.aborted || error.name === 'AbortError') throw error;
    throw new Error('无法读取本机服务，请检查服务状态后刷新。');
  }
  let data;
  try {
    data = await response.json();
  } catch (error) {
    if (signal.aborted || error.name === 'AbortError') throw error;
    throw new Error(`本机服务未返回可读取的 Agent 数据（${response.status}）。`);
  }
  if (!response.ok || data?.error) {
    const message = typeof data?.error === 'string' ? data.error : data?.error?.message;
    throw new Error(typeof message === 'string' ? message : `Agent 状态读取失败（${response.status}），请刷新实况。`);
  }
  return normalizeAgentSnapshot(data);
}

function AgentFlow({library,selected,onLibrary}) {
  const Source = typeof onLibrary === 'function' ? 'button' : 'div';
  const countLabel = fileCountLabel(library.personalCount,library.countComplete);
  return <section className="aw-flow" aria-label="我的 Skills 与所选 Agent 的目录关系">
    <Source className="aw-flow-source" type={Source === 'button' ? 'button' : undefined} onClick={Source === 'button' ? () => onLibrary() : undefined}>
      <FlowSymbol source/>
      <span className="aw-flow-copy"><strong className="aw-flow-title">我的 Skills</strong><span className="aw-flow-subtitle">{countLabel}</span>{library.path && <code className="aw-flow-path">{library.path}</code>}</span>
    </Source>
    <div className="aw-flow-link"><svg viewBox="0 0 160 20" fill="none" preserveAspectRatio="none" aria-hidden="true"><path d="M1 10h155m-7-7 7 7-7 7" stroke="currentColor" strokeWidth="1.4" vectorEffect="non-scaling-stroke"/></svg><span>目录对照</span></div>
    <div className="aw-flow-target"><FlowSymbol/><span className="aw-flow-copy"><strong className="aw-flow-title">{selected?.name || '选择 Agent'}</strong><span className="aw-flow-subtitle">{selected ? `目录现有 ${agentCountLabel(selected)}` : '在下方选择宿主'}</span>{selected && <span className="aw-flow-subtitle">待宿主验证</span>}</span></div>
  </section>;
}

function AgentDetails({agent,panelId,onDiscover}) {
  const canDiscover = typeof onDiscover === 'function';
  const installation = agent.installation;
  return <section className="aw-detail" id={panelId} aria-labelledby={`${panelId}-title`}>
    <div className="aw-detail-heading"><h2 id={`${panelId}-title`}>{agent.name}</h2><span className="aw-tag" data-status={agent.status}>{agentDetectionLabel(agent)}</span></div>
    <dl className="aw-facts">
      <div><dt>可执行文件</dt><dd>{agent.executableDetected === true ? '检测到' : agent.executableDetected === false ? '未检测到' : '待核对'}</dd></div>
      <div><dt>目录文件</dt><dd>{agentCountLabel(agent)}</dd></div>
      <div><dt>宿主加载</dt><dd>待宿主验证</dd></div>
    </dl>
    {agent.error && <p className="aw-error" role="status">{agent.error}</p>}
    <section className="aw-directories" aria-labelledby={`${panelId}-roots`}>
      <h3 id={`${panelId}-roots`}>技能目录</h3>
      {agent.roots.length ? <ul className="aw-root-list">{agent.roots.map((root,index) => <li className="aw-root" key={`${root.path}-${index}`}>
        <div className="aw-root-heading"><span>{rootScopeLabel(root)}</span><span className="aw-muted">{root.count === null ? '数量未知' : fileCountLabel(root.count,root.countComplete)}</span></div>
        <code className="aw-path">{root.path || '路径未提供'}</code>
        <span className="aw-root-status" data-status={root.status}>{rootStatusLabel(root)}</span>
        {root.supportStatus === 'unverified' && <span className="aw-root-support">宿主支持待验证</span>}
        {root.error && <p className="aw-muted">{root.error}</p>}
      </li>)}</ul> : <p className="aw-empty">未提供技能目录。刷新实况后再查看。</p>}
    </section>
    {installation && <div className="aw-install-target"><span className="aw-muted">添加位置{installation.shared ? '（共享目录）' : ''}</span><code className="aw-path">{installation.targetPath || '尚无可用目标目录'}</code>{installation.shared && <p className="aw-muted">此目录供多个 Agent 共用。</p>}</div>}
    {canDiscover && installation && <div className="aw-detail-actions"><button type="button" className="aw-button aw-button-primary" disabled={!installation.available} onClick={() => onDiscover(agent.id)}><Icon name="add"/>添加 Skills</button>{!installation.available && <p className="aw-muted">{installation.reason || '此目标目录暂不可写。'}</p>}</div>}
    <details className="aw-evidence"><summary>检测详情</summary>
      {agent.detectionComplete === false && <p className="aw-muted">部分路径未能检查，检测结果不完整。</p>}
      {agent.evidence.length > 0 ? <ul className="aw-evidence-list">{agent.evidence.map((evidence,index) => <li key={`${evidence.path}-${index}`}><div><span>{evidence.kind === 'executable' ? '可执行文件' : evidence.kind === 'configuration_directory' ? '配置目录' : '本机证据'}</span><span className="aw-muted">{evidenceStatus[evidence.status] || '状态未提供'}</span></div>{evidence.path && <code className="aw-path">{evidence.path}</code>}{evidence.message && <p>{evidence.message}</p>}</li>)}</ul> : <p className="aw-muted">本机服务未提供检测明细。</p>}
      {agent.roots.some(root => root.message || root.sourceUrl || root.warnings.length) && <ul className="aw-evidence-list">{agent.roots.filter(root => root.message || root.sourceUrl || root.warnings.length).map((root,index) => <li key={`root-${root.path}-${index}`}><code className="aw-path">{root.path || '路径未提供'}</code>{root.message && <p>{root.message}</p>}{root.sourceUrl && <a className="aw-root-reference" href={root.sourceUrl} target="_blank" rel="noreferrer">目录依据</a>}{root.warnings.length > 0 && <details className="aw-path-warnings"><summary>{root.warnings.length} 条路径提示</summary><ul>{root.warnings.map((warning,warningIndex) => <li key={`${warning.path}-${warningIndex}`}>{warning.path && <code className="aw-path">{warning.path}</code>}<p>{warning.message || rootStatusLabel(warning)}{warning.error ? `：${warning.error}` : ''}</p></li>)}</ul></details>}</li>)}</ul>}
      <p className="aw-muted">检测到程序或配置目录，不代表已连接。技能数量来自目录文件；宿主是否发现、加载及任务效果仍需验证。</p>
      {installation?.available && <p className="aw-muted">“添加 Skills”进入来源与文件预览。目录可写不代表宿主兼容性已验证。</p>}
    </details>
  </section>;
}

export default function AgentWorkspace({onLibrary,onDiscover,onTask}) {
  const [state,dispatch] = useReducer(agentWorkspaceReducer,initialAgentWorkspaceState);
  const request = useRef(null),sequence = useRef(0),mounted = useRef(false);
  const panelId = `aw-agent-${useId()}`;
  const refresh = useCallback(async () => {
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    const requestId = ++sequence.current;
    let timedOut = false;
    dispatch({type:'start',requestId});
    const timeout = setTimeout(() => {timedOut = true;controller.abort();},15000);
    try {
      const snapshot = await readSnapshot(controller.signal);
      if (mounted.current && !controller.signal.aborted && requestId === sequence.current) dispatch({type:'success',requestId,snapshot});
    } catch (error) {
      if (!mounted.current || requestId !== sequence.current || (controller.signal.aborted && !timedOut)) return;
      dispatch({type:'failure',requestId,error:timedOut ? '读取超时，请检查本机服务后刷新实况。' : error.message || '无法读取本机 Agent，请刷新实况。'});
    } finally {
      clearTimeout(timeout);
      if (request.current === controller) request.current = null;
    }
  },[]);

  useEffect(() => {
    mounted.current = true;
    refresh();
    return () => {mounted.current = false;sequence.current++;request.current?.abort();};
  },[refresh]);

  const loading = state.phase === 'loading' || state.phase === 'idle';
  const agents = state.snapshot?.agents || [];
  const selected = agents.find(agent => agent.id === state.selectedId) || null;
  const detectedCount = agents.filter(agent => agent.status === 'detected').length;
  return <main className="aw-workspace" data-loading={loading}>
    <header className="aw-header"><div><h1>本机 Agent</h1>{state.snapshot && <p className="aw-updated">{checkedAtLabel(state.snapshot.checkedAt)}</p>}</div><div className="aw-header-actions"><button type="button" className="aw-button aw-button-secondary" onClick={refresh} disabled={loading}><Icon name="refresh"/>{loading ? '正在读取…' : '刷新实况'}</button>{typeof onLibrary === 'function' && <button type="button" className="aw-button aw-button-secondary" onClick={() => onLibrary()}>管理 Skills</button>}</div></header>
    {loading ? <div className="aw-loading" role="status"><span className="aw-loading-line" aria-hidden="true"/><p>正在读取本机目录…</p></div> : state.error ? <div className="aw-error" role="alert"><p>{state.error}</p><button type="button" className="aw-button aw-button-secondary" onClick={refresh}>重新读取</button></div> : state.snapshot && <>
      <AgentFlow library={state.snapshot.library} selected={selected} onLibrary={onLibrary}/>
      <div className="aw-body"><section className="aw-agents" aria-labelledby={`${panelId}-list`}><div className="aw-section-heading"><h2 id={`${panelId}-list`}>Agent</h2><span className="aw-muted">{detectedCount} 个检测到</span></div>
        {agents.length ? <ul className="aw-agent-list">{agents.map(agent => <li key={agent.id}><button type="button" className="aw-agent" aria-pressed={agent.id === selected?.id} aria-controls={panelId} onClick={() => dispatch({type:'select',id:agent.id})}><span className="aw-agent-symbol"><Icon name="host"/></span><span className="aw-agent-info"><strong>{agent.name}</strong><span className="aw-agent-status" data-status={agent.status}>{agentDetectionLabel(agent)}</span></span><span className="aw-agent-count" aria-label={agentCountLabel(agent)}>{compactCount(agent)}</span><Icon name="chevron"/></button></li>)}</ul> : <p className="aw-empty">本机服务未返回 Agent。刷新实况后再查看。</p>}
        <div className="aw-list-actions">{typeof onDiscover === 'function' && <button type="button" className="aw-button aw-button-quiet" onClick={() => onDiscover()}>发现 Skills<Icon name="arrow"/></button>}{typeof onTask === 'function' && <button type="button" className="aw-button aw-button-quiet" onClick={() => onTask()}>打开任务<Icon name="arrow"/></button>}</div>
      </section>{selected ? <AgentDetails key={selected.id} agent={selected} panelId={panelId} onDiscover={onDiscover}/> : <section className="aw-detail aw-empty"><p>选择 Agent，查看实际目录。</p></section>}</div>
    </>}
  </main>;
}
