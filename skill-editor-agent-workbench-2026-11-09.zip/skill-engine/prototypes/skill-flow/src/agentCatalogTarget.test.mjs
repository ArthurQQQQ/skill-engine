import test from 'node:test';
import assert from 'node:assert/strict';
import {catalogTargetPath,catalogTargetPayload} from './agentCatalogTarget.mjs';

test('catalog target follows an explicit supported host in GET and POST requests',()=>{
  assert.equal(catalogTargetPath('/api/catalog/updates','claude-code'),'/api/catalog/updates?agentId=claude-code');
  assert.deepEqual(catalogTargetPayload({candidateId:'one',agentId:'cursor'},'codex'),{candidateId:'one',agentId:'codex'});
});
test('editor library retains legacy requests and removes inherited target identity',()=>{
  assert.equal(catalogTargetPath('/api/catalog/updates',''),'/api/catalog/updates');
  assert.deepEqual(catalogTargetPayload({candidateId:'one',agentId:'cursor'},''),{candidateId:'one'});
});
test('arbitrary directory strings cannot become catalog target ids',()=>{
  assert.throws(()=>catalogTargetPayload({},'../../other'));
  assert.throws(()=>catalogTargetPath('/api/catalog/updates','unrecognised'));
});

test('target selection replaces an old query target while retaining other parameters',()=>{
  assert.equal(catalogTargetPath('/api/catalog/updates?agentId=cursor&view=all','codex'),'/api/catalog/updates?view=all&agentId=codex');
  assert.equal(catalogTargetPath('/api/catalog/updates?agentId=cursor',''),'/api/catalog/updates');
});
