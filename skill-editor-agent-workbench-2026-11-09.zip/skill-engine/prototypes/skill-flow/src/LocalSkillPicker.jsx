import React, {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import {localSkillChangeEvidence,localSkillText,selectAdoptableLocalSkills} from './localSkillPickerModel.mjs';

function LocalEvidence({skill,inventory}) {
  const change=localSkillChangeEvidence(inventory,skill);
  return <details className="lsp-evidence"><summary>来源与本地修改</summary><dl>
    <div><dt>原始名称</dt><dd>{localSkillText(skill.name)}</dd></div>
    <div><dt>来源</dt><dd>个人库（{localSkillText(skill.source)}）</dd></div>
    <div><dt>入口文件</dt><dd><code>{skill.path}</code></dd></div>
    <div><dt>文件证据</dt><dd>入口文件已读取（{skill.fileStatus}）</dd></div>
    <div><dt>当前 SHA-256</dt><dd><code>{localSkillText(skill.sha256)}</code></dd></div>
    {Object.hasOwn(skill,'bytes') && <div><dt>文件大小</dt><dd>{localSkillText(skill.bytes)} 字节</dd></div>}
    <div><dt>本地修改</dt><dd>{change.status==='changed-since-scan'?<>自上次扫描后内容有变化。<span className="lsp-hash"><span>上次</span><code>{change.beforeSha}</code></span><span className="lsp-hash"><span>当前</span><code>{change.afterSha}</code></span></>:'未提供可核对的修改基线。'}</dd></div>
    <div><dt>采用范围</dt><dd>预览当前本地内容；宿主是否发现与任务效果仍需验证。</dd></div>
  </dl></details>;
}

async function readInventory(signal) {
  const response=await fetch('/api/inventory',{signal,cache:'no-store',headers:{Accept:'application/json'}});
  let value;
  try {value=await response.json();}catch(error) {
    if(error?.name==='AbortError')throw error;
    throw new Error('个人库返回内容无法读取，请重新读取。');
  }
  if(!response.ok)throw new Error(localSkillText(value?.error,`读取个人库失败（${response.status}），请重试。`));
  selectAdoptableLocalSkills(value);
  return value;
}

export default function LocalSkillPicker({targetAgent='',disabled=false,onInspect,onDiscover}) {
  const [inventory,setInventory]=useState(null),[loading,setLoading]=useState(true),[error,setError]=useState('');
  const [query,setQuery]=useState(''),[inspectingId,setInspectingId]=useState(null),[inspectError,setInspectError]=useState('');
  const revision=useRef(0),controller=useRef(null),inspectionRevision=useRef(0),inspectionPending=useRef(false),searchRef=useRef(null);
  const hasTarget=typeof targetAgent==='string' && targetAgent.trim().length>0;
  const load=useCallback(async()=>{
    controller.current?.abort();
    const next=new AbortController(),rev=++revision.current;
    controller.current=next;setLoading(true);setError('');setInventory(null);
    try {const value=await readInventory(next.signal);if(rev===revision.current && !next.signal.aborted)setInventory(value);}
    catch(err) {if(err?.name!=='AbortError' && rev===revision.current && !next.signal.aborted)setError(localSkillText(err?.message,'读取个人库失败，请重试。'));}
    finally {if(rev===revision.current && !next.signal.aborted)setLoading(false);}
  },[]);
  useEffect(()=>{
    load();
    return()=>{revision.current++;controller.current?.abort();inspectionRevision.current++;inspectionPending.current=false;};
  },[load]);
  useEffect(()=>{inspectionRevision.current++;inspectionPending.current=false;setInspectingId(null);setInspectError('');},[targetAgent]);
  const allSkills=useMemo(()=>inventory?selectAdoptableLocalSkills(inventory):[],[inventory]);
  const filtered=useMemo(()=>inventory?selectAdoptableLocalSkills(inventory,query):[],[inventory,query]);
  const hasQuery=query.length>0;
  const inspectDisabled=Boolean(disabled) || !hasTarget || loading || inspectingId!==null || typeof onInspect!=='function';
  function clearQuery(){setQuery('');searchRef.current?.focus();}
  async function inspect(skill) {
    if(inspectDisabled || inspectionPending.current)return;
    const rev=++inspectionRevision.current;
    inspectionPending.current=true;setInspectingId(skill.id);setInspectError('');
    try {await onInspect({skillId:skill.id});}
    catch(err) {if(rev===inspectionRevision.current)setInspectError(localSkillText(err?.message,'预览未完成，请重试。'));}
    finally {if(rev===inspectionRevision.current){inspectionPending.current=false;setInspectingId(null);}}
  }
  return <section className="lsp-picker" aria-label="我的 Skills" aria-busy={loading}>
    <div className="lsp-controls"><label className="lsp-search"><span className="se-sr-only">搜索我的 Skills</span><input ref={searchRef} type="search" value={query} onChange={event=>setQuery(event.target.value)} maxLength={180} placeholder="搜索名称或用途"/></label>{hasQuery && <button type="button" className="se-button quiet" onClick={clearQuery}>清除搜索</button>}</div>
    <div className="lsp-heading"><p role="status" aria-live="polite">{loading?'正在读取个人库…':inventory?(hasQuery?`找到 ${filtered.length} / ${allSkills.length} 项`:`${allSkills.length} 项可复制`):'个人库未读取'}</p></div>
    {!hasTarget && <p className="lsp-target-note">先选择目标 Agent</p>}
    {error && <div className="se-message error" role="alert"><p>{error}</p><button type="button" className="se-button quiet" onClick={load}>重新读取</button></div>}
    {inspectError && <div className="se-message error" role="alert"><p>{inspectError}</p></div>}
    {inventory && <>
      <ul className="lsp-list">{filtered.map(skill=>{
        const name=localSkillText(skill.name,skill.id),description=localSkillText(skill.description,'用途说明未提供');
        return <li key={skill.id} className={inspectingId===skill.id?'lsp-row is-previewing':'lsp-row'}>
          <div className="lsp-main"><h3>{name}</h3><p className="lsp-description" title={description}>{description}</p><LocalEvidence skill={skill} inventory={inventory}/></div>
          <button type="button" className="se-button secondary" disabled={inspectDisabled} title={!hasTarget?'先选择目标 Agent':typeof disabled==='string'?disabled:undefined} aria-label={`预览 ${name} 到此 Agent`} onClick={()=>inspect(skill)}>{inspectingId===skill.id?'正在预览…':'预览到此 Agent'}</button>
        </li>;
      })}</ul>
      {filtered.length===0 && <div className="lsp-empty"><p>{hasQuery?'没有匹配的 Skills。试试其他关键词。':'个人库中还没有可复制的 Skills。'}</p><div className="lsp-empty-actions">{hasQuery?<button type="button" className="se-button secondary" onClick={clearQuery}>显示全部 Skills</button>:<>{typeof onDiscover==='function' && <button type="button" className="se-button secondary" onClick={onDiscover}>浏览精选目录</button>}<button type="button" className="se-button quiet" onClick={load}>重新读取</button></>}</div></div>}
    </>}
  </section>;
}
