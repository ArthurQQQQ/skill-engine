import test from 'node:test';
import assert from 'node:assert/strict';
import {localSkillChangeEvidence,localSkillText,selectAdoptableLocalSkills} from './localSkillPickerModel.mjs';

const personal={id:'local-original',name:'Original:skill-name',description:'Review manuscript evidence.',source:'personal',editable:true,inventoryRole:'main',path:'/Users/arthur/.codex/skills/original/SKILL.md',fileStatus:'present',presentOnDisk:true,sha256:'current-sha',sessionAvailable:null};
const inventory=skills=>({librarySkills:skills,scope:{personalRoot:'/Users/arthur/.codex/skills'}});

test('only editable personal entries with current SKILL.md evidence can be selected',()=>{
  const records=[personal,
    {...personal,id:'plugin',source:'plugin'},
    {...personal,id:'system',source:'system'},
    {...personal,id:'readonly',editable:false},
    {...personal,id:'string-editable',editable:'true'},
    {...personal,id:'cache',inventoryRole:'cache-only'},
    {...personal,id:'missing',fileStatus:'missing',presentOnDisk:false},
    {...personal,id:'unknown-file',fileStatus:'present',presentOnDisk:null},
    {...personal,id:'unsupported',fileStatus:'unavailable-or-unsupported'},
    {...personal,id:'no-file-status',fileStatus:undefined},
    {...personal,id:'directory',path:'/Users/arthur/.codex/skills/original'},
  ];
  assert.deepEqual(selectAdoptableLocalSkills(inventory(records)).map(item=>item.id),['local-original']);
});

test('malformed records and paths outside the personal layout cannot become inspect requests',()=>{
  const records=[null,[],{},17,
    {...personal,id:''},
    {...personal,id:0},
    {...personal,id:'relative',path:'original/SKILL.md'},
    {...personal,id:'traversal',path:'/Users/arthur/.codex/skills/../outside/SKILL.md'},
    {...personal,id:'system-path',path:'/Users/arthur/.codex/skills/.system/original/SKILL.md'},
    {...personal,id:'cache-path',path:'/Users/arthur/.codex/plugins/cache/original/SKILL.md'},
    {...personal,id:'outside-root',path:'/Users/arthur/elsewhere/original/SKILL.md'},
    {...personal,id:'nested-entry',path:'/Users/arthur/.codex/skills/original/references/SKILL.md'},
    {...personal,id:'bad-name',name:{title:'Fabricated name'}},
  ];
  assert.deepEqual(selectAdoptableLocalSkills(inventory(records)),[]);
});

test('same names at different source identities remain independent entries',()=>{
  const another={...personal,id:'second-original',path:'/Users/arthur/.codex/skills/another/SKILL.md'};
  const input=inventory([personal,another]);
  const result=selectAdoptableLocalSkills(input);
  assert.deepEqual(result.map(item=>[item.id,item.name,item.source]),[
    ['local-original','Original:skill-name','personal'],
    ['second-original','Original:skill-name','personal'],
  ]);
  assert.equal(result[0],personal);
  assert.equal(input.librarySkills.length,2);
  assert.equal(result[0].sessionAvailable,null);
});

test('an empty current library stays empty instead of reviving the legacy collection',()=>{
  assert.deepEqual(selectAdoptableLocalSkills({librarySkills:[],skills:[personal]}),[]);
  assert.deepEqual(selectAdoptableLocalSkills({skills:[personal]}).map(item=>item.id),['local-original']);
});

test('invalid inventories and API errors remain errors instead of empty-library states',()=>{
  assert.throws(()=>selectAdoptableLocalSkills(null),/个人库/);
  assert.throws(()=>selectAdoptableLocalSkills({librarySkills:{}}),/个人库/);
  assert.throws(()=>selectAdoptableLocalSkills({error:'Inventory source unavailable',skills:[]}),/Inventory source unavailable/);
  assert.throws(()=>selectAdoptableLocalSkills({error:0,skills:[]}),/0/);
  assert.deepEqual(selectAdoptableLocalSkills({error:null,skills:[]}),[]);
});

test('local search combines terms without renaming or modifying a selected record',()=>{
  const another={...personal,id:'drafting',name:'paper-writing',description:'Draft the manuscript.',path:'/Users/arthur/.codex/skills/writing/SKILL.md'};
  assert.deepEqual(selectAdoptableLocalSkills(inventory([personal,another]),'ORIGINAL evidence').map(item=>item.id),['local-original']);
  assert.deepEqual(selectAdoptableLocalSkills(inventory([personal,another]),'manuscript review').map(item=>item.id),['local-original']);
  assert.deepEqual(selectAdoptableLocalSkills(inventory([personal]),'missing'),[]);
  assert.deepEqual(selectAdoptableLocalSkills(inventory([personal]),'   ').map(item=>item.id),['local-original']);
  assert.equal(personal.name,'Original:skill-name');
});

test('ambiguous duplicate IDs cannot target an arbitrary path',()=>{
  const otherPath={...personal,path:'/Users/arthur/.codex/skills/another/SKILL.md'};
  assert.deepEqual(selectAdoptableLocalSkills(inventory([personal,otherPath])),[]);
  assert.equal(selectAdoptableLocalSkills(inventory([personal,{...personal}])).length,1);
});

test('change evidence belongs to the exact identity and distinguishes unknown from a recorded change',()=>{
  const input={...inventory([personal]),delta:{changed:[
    {id:personal.id,source:'personal',path:personal.path,beforeSha:'previous-sha',afterSha:'current-sha'},
  ]}};
  assert.deepEqual(localSkillChangeEvidence(input,personal),{status:'changed-since-scan',beforeSha:'previous-sha',afterSha:'current-sha'});
  assert.deepEqual(localSkillChangeEvidence({...input,delta:{changed:[]}},personal),{status:'unknown'});
  assert.deepEqual(localSkillChangeEvidence({...input,delta:{changed:[{id:personal.id,source:'plugin',path:personal.path,beforeSha:'previous-sha',afterSha:'current-sha'}]}},personal),{status:'unknown'});
  assert.deepEqual(localSkillChangeEvidence(input,{...personal,sha256:'newer-current-sha'}),{status:'unknown'});
});

test('display values preserve zero and null has an explicit missing value',()=>{
  assert.equal(localSkillText(0),'0');
  assert.equal(localSkillText(null),'未提供');
  assert.equal(localSkillText(undefined),'未提供');
  assert.equal(localSkillText('Original:skill-name'),'Original:skill-name');
  assert.equal(localSkillText('', '用途说明未提供'),'用途说明未提供');
});
