const AGENTS=new Set(['codex','claude-code','cursor','opencode']);
function knownTarget(agentId) {
  if(agentId!=='' && agentId!=null && !AGENTS.has(agentId))throw new Error('请选择支持的 Agent。');
  return agentId || '';
}
export function catalogTargetPath(path,agentId) {
  const id=knownTarget(agentId);
  const [pathname,query='']=path.split('?'),params=new URLSearchParams(query);
  params.delete('agentId');if(id)params.set('agentId',id);
  const search=params.toString();return pathname+(search?`?${search}`:'');
}
export function catalogTargetPayload(payload,agentId) {
  const id=knownTarget(agentId),{agentId:ignored,...body}=payload;
  return id?{...body,agentId:id}:body;
}
