import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {Background, BaseEdge, Controls, EdgeLabelRenderer, getSmoothStepPath, Handle, Position, ReactFlow, ReactFlowProvider, useNodesState, useReactFlow} from '@xyflow/react';
import {CATEGORIES, sources, skillMeta, selectSkills, buildGraph, graphEdges, relatedTo, makeIssuePrompt} from './model.mjs';

const LAYOUT_KEY='skill-flow.workspace.v2';
const EMPTY=[];
const statusNames={current:'引文匹配',stale:'来源已变化',unavailable:'来源不可读取',uncertain:'判断待确认'};

function readPositions() {
  try {
    const value=JSON.parse(localStorage.getItem(LAYOUT_KEY));
    return value && typeof value==='object' && !Array.isArray(value)?value:{};
  } catch {return {};}
}

function GroupNode({data}) {
  return <div className="group-heading"><h2>{data.category.label}</h2><span>{data.count}</span></div>;
}

function SkillNode({data,selected}) {
  return <article className={`skill-node ${selected?'is-active':''}`} data-category={data.categoryId}>
    <Handle type="target" position={Position.Left} isConnectable={false}/>
    <h2 className="skill-title">{data.title}</h2>
    <p className="skill-original-name" title={data.name}>{data.name}{data.versionLabel && <span className="node-version"> · {data.versionLabel}</span>}</p>
    <p className="skill-purpose">{data.summary || data.description || data.sourceLabel}</p>
    <Handle type="source" position={Position.Right} isConnectable={false}/>
  </article>;
}
const nodeTypes={group:GroupNode,skill:SkillNode};

function EvidenceEdge({id,sourceX,sourceY,targetX,targetY,sourcePosition,targetPosition,style,label,data}) {
  const [path,labelX,labelY]=getSmoothStepPath({sourceX,sourceY,targetX,targetY,sourcePosition,targetPosition});
  return <><BaseEdge id={id} path={path} style={style} interactionWidth={24}/>
    <EdgeLabelRenderer><button className="evidence-edge-label nodrag nopan" style={{transform:`translate(-50%, -50%) translate(${labelX}px, ${labelY}px)`}}
      aria-label={`查看${label}的原文依据`} onClick={event=>{event.stopPropagation();data.onInspect(data.relation);}}>{label}</button></EdgeLabelRenderer>
  </>;
}
const edgeTypes={evidence:EvidenceEdge};

function Icon({name}) {
  const paths={search:<><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></>,more:<><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,back:<><path d="m10 5-7 7 7 7M3 12h18"/></>,center:<><path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/><circle cx="12" cy="12" r="3"/></>,close:<path d="m6 6 12 12M18 6 6 18"/>,all:<><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></>,writing:<><path d="m4 16-1 5 5-1L20 8l-4-4Z M14 6l4 4M3 21h9"/></>,reviews:<><path d="M8 4H5v17h14V4h-3M8 3h8v4H8Z M8 13l2 2 5-5"/></>,research:<><circle cx="10" cy="10" r="6"/><path d="m15 15 6 6M7 10h6M10 7v6"/></>,design:<><path d="m12 3 9 9-9 9-9-9ZM12 3v18M3 12h18"/></>,tools:<><path d="m8 8-5 4 5 4m8-8 5 4-5 4m-3-11-2 14"/></>,other:<><rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 9h8M8 15h8"/></>};
  return <svg className="ui-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function RelationCard({relation,selected,byId,active,onChoose}) {
  const neighbor=relation.sourceId===selected?relation.targetId:relation.sourceId;
  return <article className={`relation-card ${active?'focused':''}`}>
    <button onClick={()=>onChoose(neighbor)} disabled={!byId.has(neighbor)}>{skillMeta(byId.get(neighbor) || {id:neighbor}).title}</button>
    {relation.type!=='reference' && <p>{relation.summary}</p>}{relation.condition && <p className="muted">{relation.condition}</p>}
    <details open={active || undefined}><summary>查看依据</summary><p>{relation.label || relation.type}：{statusNames[relation.status] || '待核对'}</p>{(relation.evidence || []).map((item,index)=><blockquote key={index}>
      <code>{item.path}{item.line?`:${item.line}`:''}</code><p>{item.quote}</p><small>{statusNames[item.status] || '待核对'}</small>
    </blockquote>)}<small>引文匹配不等于实际调用或效果验证。</small></details>
  </article>;
}

async function readJson(path,signal) {
  const response=await fetch(path,{signal,cache:'no-store'});
  const result=await response.json();
  if(!response.ok || result.error) throw new Error(result.error || '读取失败，请检查本地服务。');
  return result;
}

function Workspace({initialSkill}) {
  const [inventory,setInventory]=useState(null);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState('');
  const [source,setSource]=useState('personal');
  const [category,setCategory]=useState('all');
  const [query,setQuery]=useState('');
  const [selected,setSelected]=useState(null);
  const [detail,setDetail]=useState(null);
  const [detailError,setDetailError]=useState('');
  const [detailLoading,setDetailLoading]=useState(false);
  const [activeRelation,setActiveRelation]=useState(null);
  const [issueOpen,setIssueOpen]=useState(false);
  const [issueText,setIssueText]=useState('');
  const [prompt,setPrompt]=useState('');
  const [copyFallback,setCopyFallback]=useState(false);
  const [notice,setNotice]=useState('');
  const [canvasSize,setCanvasSize]=useState({width:0,height:0,narrow:false});
  const positions=useRef(null);
  if(!positions.current) positions.current=readPositions();
  const promptRef=useRef(null);
  const searchRef=useRef(null);
  const issueRef=useRef(null);
  const flowRef=useRef(null);
  const menuRef=useRef(null);
  const closeRef=useRef(null);
  const returnFocusRef=useRef(null);
  const lastFitKey=useRef('');
  const requestRevision=useRef(0);
  const copyRevision=useRef(0);
  const graphApi=useReactFlow();
  const skills=inventory?.librarySkills || inventory?.skills || EMPTY;
  const relationships=inventory?.relationships || EMPTY;
  const currentSkills=useMemo(()=>selectSkills(skills,{source:'all'}),[skills]);
  const byId=useMemo(()=>new Map(currentSkills.map(item=>[item.id,item])),[currentSkills]);
  const scopedSkills=useMemo(()=>selectSkills(skills,{source}),[skills,source]);
  const purposeCounts=useMemo(()=>Object.fromEntries(CATEGORIES.map(item=>[item.id,scopedSkills.filter(skill=>skillMeta(skill).categoryId===item.id).length])),[scopedSkills]);
  const layout=useMemo(()=>{
    const columns=Math.max(1,Math.min(4,Math.floor(((canvasSize.width || 920)-40+24)/288)));
    return {columns,cardWidth:canvasSize.narrow?Math.max(264,Math.floor(((canvasSize.width || 375)-48-(columns-1)*24)/columns)):264};
  },[canvasSize.width,canvasSize.narrow]);
  const layoutScope=`${source}\0${category}\0${query.trim().toLocaleLowerCase()}\0${layout.columns}\0${layout.cardWidth}`;

  const loadInventory=useCallback(async signal=>{
    setLoading(true);setError('');
    try {setInventory(await readJson('/api/inventory',signal));}
    catch(err) {if(err.name!=='AbortError') setError(err.message);}
    finally {if(!signal?.aborted) setLoading(false);}
  },[]);
  useEffect(()=>{const controller=new AbortController();loadInventory(controller.signal);return()=>controller.abort();},[loadInventory]);
  useEffect(()=>{
    const frame=flowRef.current;
    if(!frame) return;
    const measure=()=>setCanvasSize({width:frame.clientWidth,height:frame.clientHeight,narrow:window.innerWidth<=760});
    measure();
    const observer=new ResizeObserver(measure);observer.observe(frame);
    return()=>observer.disconnect();
  },[]);

  const clearIssue=useCallback(()=>{copyRevision.current++;setIssueOpen(false);setIssueText('');setPrompt('');setCopyFallback(false);},[]);
  const choose=useCallback(id=>{
    const skill=byId.get(id);if(!skill) return;
    returnFocusRef.current=document.activeElement;
    if(!selectSkills(skills,{source,category,query}).some(item=>item.id===id)) {
      setSource('all');setCategory('all');setQuery('');
    }
    setSelected(id);setActiveRelation(null);clearIssue();
  },[byId,skills,source,category,query,clearIssue]);
  const initialOpened=useRef(null);
  useEffect(()=>{
    if(initialSkill && byId.has(initialSkill) && initialOpened.current!==initialSkill) {
      initialOpened.current=initialSkill;choose(initialSkill);
    }
  },[initialSkill,byId,choose]);
  const openCategory=useCallback(id=>{
    setCategory(id);setQuery('');setSelected(null);setActiveRelation(null);clearIssue();
  },[clearIssue]);
  const graph=useMemo(()=>buildGraph(skills,{source,category,query,positions:positions.current[layoutScope],...layout}),[skills,source,category,query,layout,layoutScope]);
  const [nodes,setNodes,onNodesChange]=useNodesState([]);
  useEffect(()=>{setNodes(graph.nodes);},[graph,setNodes]);
  useEffect(()=>{setNodes(items=>items.map(node=>({...node,selected:node.id===selected})));},[selected,graph,setNodes]);
  const edges=useMemo(()=>graphEdges(relationships,graph.visibleSkills,selected,true).map(edge=>({...edge,type:'evidence',data:{...edge.data,onInspect:setActiveRelation}})),[graph,relationships,selected]);
  const related=useMemo(()=>relatedTo(relationships,selected),[relationships,selected]);

  const fit=useCallback(()=>{
    const items=graphApi.getNodes();const frame=flowRef.current;
    if(!items.length || !frame?.clientWidth || !frame.clientHeight) return;
    const left=Math.min(...items.map(item=>item.position.x));
    const top=Math.min(...items.map(item=>item.position.y));
    const right=Math.max(...items.map(item=>item.position.x+(item.measured?.width || item.style?.width || 264)));
    // Start at readable size. Searching and panning handle large libraries.
    const scale=1;
    const spreadTooWide=(right-left)>frame.clientWidth-40;
    const anchor=(items.find(item=>item.type==='skill') || items[0]).position;
    graphApi.setViewport({
      x:24-(spreadTooWide?anchor.x:left)*scale,
      y:24-(spreadTooWide?anchor.y:top)*scale,zoom:scale,
    },{duration:0});
  },[graphApi]);
  const viewKey=`${source}\0${category}\0${query}\0${currentSkills.length}`;
  useEffect(()=>{
    if(!graph.nodes.length || !canvasSize.width || lastFitKey.current===viewKey) return;
    lastFitKey.current=viewKey;
    let second;
    const first=requestAnimationFrame(()=>{second=requestAnimationFrame(()=>fit());});
    return()=>{cancelAnimationFrame(first);cancelAnimationFrame(second);};
  },[viewKey,graph.nodes.length,canvasSize.width,fit]);

  useEffect(()=>{
    const revision=++requestRevision.current;
    copyRevision.current++;
    setDetail(null);setDetailError('');setPrompt('');setCopyFallback(false);
    if(!selected){setDetailLoading(false);return;}
    const controller=new AbortController();setDetailLoading(true);
    readJson(`/api/skill?id=${encodeURIComponent(selected)}`,controller.signal)
      .then(value=>{if(revision===requestRevision.current) setDetail(value);})
      .catch(err=>{if(err.name!=='AbortError' && revision===requestRevision.current) setDetailError(err.message);})
      .finally(()=>{if(revision===requestRevision.current) setDetailLoading(false);});
    return()=>controller.abort();
  },[selected,inventory]);
  useEffect(()=>{
    if(inventory && selected && !byId.has(selected)) {
      setSelected(null);setActiveRelation(null);clearIssue();setNotice('该技能已不在当前可浏览目录，请重新选择。');
    }
  },[inventory,selected,byId,clearIssue]);

  const closeDetail=useCallback(()=>{
    setSelected(null);setActiveRelation(null);clearIssue();
    requestAnimationFrame(()=>{
      const target=returnFocusRef.current;
      if(target?.isConnected && !target.closest('[inert]')) target.focus();
      else flowRef.current?.focus();
    });
  },[clearIssue]);
  useEffect(()=>{
    const handler=event=>{
      if(event.key==='Escape') {if(menuRef.current?.open){menuRef.current.open=false;return;}if(selected || issueOpen) closeDetail();}
      if(event.key==='/' && !event.metaKey && !event.ctrlKey && !event.altKey && !event.target.closest('input,textarea,select,[contenteditable="true"]')) {
        event.preventDefault();searchRef.current?.focus();
      }
    };
    document.addEventListener('keydown',handler);return()=>document.removeEventListener('keydown',handler);
  },[closeDetail,selected,issueOpen]);
  useEffect(()=>{if(!notice)return;const timer=setTimeout(()=>setNotice(''),4500);return()=>clearTimeout(timer);},[notice]);
  useEffect(()=>{
    if(issueOpen) issueRef.current?.focus();
    else if(selected) closeRef.current?.focus();
  },[issueOpen,selected]);

  function savePosition(_,node) {
    positions.current={...positions.current,[layoutScope]:{...positions.current[layoutScope],[node.id]:{x:node.position.x,y:node.position.y}}};
    try {localStorage.setItem(LAYOUT_KEY,JSON.stringify(positions.current));}
    catch {setNotice('浏览器未允许保存布局，本次拖动仍然有效。');}
  }
  function resetLayout() {
    positions.current={};
    try {localStorage.removeItem(LAYOUT_KEY);} catch {}
    setNodes(buildGraph(skills,{source,category,query,...layout}).nodes.map(node=>({...node,selected:node.id===selected})));
    requestAnimationFrame(()=>fit());
  }
  function openIssue(id=null) {
    copyRevision.current++;
    if(!selected && !issueOpen) returnFocusRef.current=document.activeElement;
    if(menuRef.current) menuRef.current.open=false;
    if(id!==selected) {setSelected(id);setIssueText('');}
    setActiveRelation(null);setPrompt('');setCopyFallback(false);setIssueOpen(true);
  }
  async function copyIssue() {
    if(!issueText.trim() || (selected && !currentDetail)) return;
    const revision=++copyRevision.current;
    const value=makeIssuePrompt({question:issueText,skill:currentDetail?.skill || null,sha:currentDetail?.sha || ''});
    setPrompt(value);setCopyFallback(false);
    try {
      await navigator.clipboard.writeText(value);
      if(revision===copyRevision.current) setNotice('已复制，粘贴到 Codex 继续。');
    }
    catch {
      if(revision!==copyRevision.current) return;
      setCopyFallback(true);setNotice('自动复制未成功，交接内容已展开，可手动复制。');
      requestAnimationFrame(()=>{if(revision===copyRevision.current){promptRef.current?.focus();promptRef.current?.select();}});
    }
  }

  const currentDetail=detail?.skill?.id===selected?detail:null;
  const selectedSkill=currentDetail?.skill || byId.get(selected);
  const selectedMeta=selectedSkill?skillMeta(selectedSkill):null;
  const categoryTitle=CATEGORIES.find(item=>item.id===category)?.label;
  const visibleCount=graph.visibleSkills.length;
  const missingCount=skills.filter(item=>item.fileStatus==='missing').length;
  const warningCount=inventory?.scanWarnings?.length || 0;
  const showAllRelations=activeRelation && related.findIndex(item=>item.id===activeRelation.id)>=3;
  const relationCard=relation=><RelationCard key={relation.id} relation={relation} selected={selected} byId={byId} active={activeRelation?.id===relation.id} onChoose={choose}/>;

  return <div className={`engine-app library-app ${(selected || issueOpen)?'has-panel':''}`}>
    <main className="engine-main" inert={Boolean((selected || issueOpen) && canvasSize.narrow)}>
      <header className="engine-header">
        <div className="stage-search"><label><Icon name="search"/><input ref={searchRef} name="skill-search" autoComplete="off" aria-label="搜索技能" placeholder="搜索技能…" value={query} onChange={event=>{setQuery(event.target.value);setSelected(null);setActiveRelation(null);clearIssue();}}/></label>
          {query && <button className="search-clear" aria-label="清空搜索" onClick={()=>setQuery('')}><Icon name="close"/></button>}
        </div>
        <div className="header-actions">{!selected && !issueOpen && <button className="text-button" onClick={()=>openIssue()}>排查问题</button>}
          <details className="workspace-menu" ref={menuRef}><summary aria-label="更多选项"><Icon name="more"/></summary><div className="menu-content">
            <button className="menu-action" disabled={loading} title="读取现有索引，不扫描新增文件" onClick={()=>{menuRef.current.open=false;loadInventory();}}>重新读取</button>
            <button className="menu-action" onClick={()=>{menuRef.current.open=false;resetLayout();}}>重置位置</button>
            <a className="menu-action" href="/maintenance">高级维护</a>
            <details className="menu-status"><summary>目录状态</summary><p className="menu-hint">{currentSkills.length} 条可浏览记录{missingCount>0 && `，${missingCount} 条缺失历史`}{warningCount>0 && `，${warningCount} 条扫描提示`}。</p></details>
          </div></details>
        </div>
      </header>
      <div className="workspace-content">
      <nav className="purpose-nav" aria-label="按用途浏览"><div className="purpose-nav-top">
        <button className={`purpose-link ${category==='all'?'is-active':''}`} aria-current={category==='all'?'page':undefined} onClick={()=>openCategory('all')}><Icon name="all"/><span>全部技能</span><span className="purpose-count">{scopedSkills.length}</span></button>
        {CATEGORIES.filter(item=>purposeCounts[item.id]>0).map(item=><button key={item.id} className={`purpose-link ${category===item.id?'is-active':''}`} aria-current={category===item.id?'page':undefined} onClick={()=>openCategory(item.id)}><Icon name={item.icon}/><span>{item.label}</span><span className="purpose-count">{purposeCounts[item.id]}</span></button>)}
      </div><div className="purpose-nav-bottom"><a href="/maintenance">高级维护</a></div></nav>
      <section className="flow-stage" aria-label="技能画布">
        <div className="stage-toolbar"><div className="view-heading">
          <h1>{query?'搜索结果':categoryTitle || (source==='personal'?'我的技能':'技能库')}</h1><span className="count-label">{visibleCount}</span>
        </div><label className="source-select"><select aria-label="技能来源" value={source} onChange={event=>{setSource(event.target.value);openCategory('all');}}>{sources.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</select></label></div>
        <div className="flow-canvas" ref={flowRef} tabIndex={-1} onKeyDownCapture={event=>{
          if(event.key!=='Enter' && event.key!==' ') return;
          const element=event.target.closest('.react-flow__node');
          if(!element || event.target.closest('button,input,textarea,select')) return;
          const node=nodes.find(item=>item.id===element.dataset.id);
          if(node?.type==='skill'){event.preventDefault();event.stopPropagation();choose(node.id);}
        }}>
          <ReactFlow nodes={nodes} edges={edges} nodeTypes={nodeTypes} edgeTypes={edgeTypes} onNodesChange={onNodesChange}
            onNodeClick={(_,node)=>node.type==='skill' && choose(node.id)}
            onNodeDoubleClick={(_,node)=>node.type==='skill' && choose(node.id)}
            onNodeDragStop={savePosition} onEdgeClick={(_,edge)=>setActiveRelation(edge.data.relation)} onPaneClick={()=>setActiveRelation(null)}
            nodesConnectable={false} edgesReconnectable={false} deleteKeyCode={null}
            panOnScroll zoomOnScroll={false} zoomActivationKeyCode="Meta"
            minZoom={0.15} maxZoom={1.7} colorMode="dark" zoomOnDoubleClick={false}
            ariaLabelConfig={{'controls.zoomIn.ariaLabel':'放大画布','controls.zoomOut.ariaLabel':'缩小画布'}}>
            <Background gap={24} size={1} color="#2c323c"/>
            <Controls showInteractive={false} showFitView={false}><button className="react-flow__controls-button" aria-label="回到画布起点" onClick={fit}><Icon name="center"/></button></Controls>
          </ReactFlow>
        </div>
        {(loading || error || (!loading && !visibleCount)) && <div className="stage-message" role="status"><h2>{loading?'正在读取技能':error?'暂时无法读取':'没有匹配的技能'}</h2>
          {error?<><p>{error}</p><button onClick={()=>loadInventory()}>重新读取</button></>:!loading && <><p>换个关键词试试。</p>{(source!=='all' || category!=='all') && <button onClick={()=>{setSource('all');setCategory('all');}}>搜索全部来源</button>}</>}
        </div>}
      </section>
      </div>
    </main>

    {(selected || issueOpen) && <aside className="detail-panel" role={canvasSize.narrow?'dialog':undefined} aria-modal={canvasSize.narrow?true:undefined} aria-label={issueOpen?'排查使用问题':'技能详情'} onKeyDown={event=>{
      if(!canvasSize.narrow || event.key!=='Tab') return;
      const items=Array.from(event.currentTarget.querySelectorAll('button,a[href],input,textarea,select,summary,[tabindex="0"]')).filter(item=>!item.disabled && item.getClientRects().length);
      const first=items[0],last=items.at(-1);
      if(event.shiftKey && (document.activeElement===first || !event.currentTarget.contains(document.activeElement))){event.preventDefault();last?.focus();}
      else if(!event.shiftKey && document.activeElement===last){event.preventDefault();first?.focus();}
    }}>
      <div className="detail-top"><div className="detail-top-actions">{issueOpen && selected && <button className="icon-button" aria-label="返回技能详情" onClick={()=>{copyRevision.current++;setIssueOpen(false);setPrompt('');}}><Icon name="back"/></button>}<span>{issueOpen?'排查问题':'技能详情'}</span></div><button className="icon-button" ref={closeRef} aria-label="关闭详情" onClick={closeDetail}><Icon name="close"/></button></div>
      <div className="detail-scroll">
        {issueOpen?<>
          <div className="issue-heading"><h2>哪里没有按预期？</h2></div>
          {selected && <p className="issue-context">{selectedMeta?.title || '所选技能'}</p>}
          {detailLoading && <p className="muted" role="status">正在核对所选技能的当前版本…</p>}{detailError && <p className="warning" role="alert">{detailError}</p>}
          <label className="issue-label"><span>想做什么，实际发生了什么</span><textarea className="issue-input" aria-label="这次使用经历" ref={issueRef} rows={6} maxLength={4000} placeholder="例如：只想调整文章结构，却开始评价论文能不能录用。" value={issueText} onChange={event=>{copyRevision.current++;setIssueText(event.target.value);setPrompt('');setCopyFallback(false);}}/></label>
          <button className="codex-button" disabled={!issueText.trim() || Boolean(selected && (!currentDetail || detailLoading))} onClick={copyIssue}>复制给 Codex</button>
          {prompt && <details className="prompt-preview" open={copyFallback || undefined}><summary>查看交接内容</summary><textarea ref={promptRef} aria-label="交给 Codex 的排查提示" value={prompt} readOnly rows={12}/></details>}
        </>:<>
          <span className="detail-source">{selectedMeta?.sourceLabel || '读取中'}{selectedMeta?.versionLabel && ` ${selectedMeta.versionLabel}`}{selectedMeta && !selectedMeta.editable && <span className="readonly-note">只读</span>}</span><h2>{selectedMeta?.title || '技能详情'}</h2>{selectedMeta?.title!==selectedMeta?.name && <p className="detail-name">{selectedMeta?.name}</p>}
          {detailLoading && <p role="status" className="muted">正在核对当前原文…</p>}{detailError && <p role="alert" className="warning">{detailError}</p>}
          {currentDetail && <>
            <div className="detail-section"><p className="description-text">{currentDetail.description}</p></div>
            <button className="codex-button" onClick={()=>openIssue(selected)}>排查问题</button>
            {related.length>0 && <div className="detail-section"><div className="section-title"><h3>相关技能</h3><span>{related.length}</span></div>
              {related.slice(0,3).map(relationCard)}{related.length>3 && <details className="more-relations" open={showAllRelations || undefined}><summary>另外 {related.length-3} 条关系</summary>{related.slice(3).map(relationCard)}</details>}
            </div>}
            <details className="source-facts"><summary>来源与状态</summary><div className="source-facts-content"><span>{selectedMeta.sessionLabel}</span><span>{selectedMeta.statusLabel}</span><p>历史目录与本地文件不能证明本次已调用；关系依据来自原文审阅。</p><code>{currentDetail.skill.path}</code><code>SHA {currentDetail.sha}</code></div></details>
            <details className="detail-section raw-content"><summary>查看 SKILL.md 原文</summary><pre>{currentDetail.content}</pre></details>
          </>}
        </>}
      </div><div className="detail-footer"><a href="/maintenance">高级维护</a></div>
    </aside>}
    {notice && <div role="status" className="engine-toast">{notice}</div>}
  </div>;
}

export default function Library({initialSkill}){return <ReactFlowProvider><Workspace initialSkill={initialSkill}/></ReactFlowProvider>;}
