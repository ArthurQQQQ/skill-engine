import test from 'node:test';
import assert from 'node:assert/strict';
import * as curatedModel from './curatedCatalogModel.mjs';
import {curatedReadiness,deploymentAllowsInstall,deploymentLabel,filterCuratedEntries,mergePreflight} from './curatedCatalogModel.mjs';

const entries=[{id:'verify',name:'verification-before-completion',title:'完成声明前的证据门',category:'app',functionTags:['app','testing'],useCases:['verify'],requirements:['项目验证命令']},{id:'design',name:'frontend-design',title:'审美方向与界面生成',category:'design',useCases:['create']},{id:'held',name:'file-organizer',title:'整理文件',category:'knowledge',decision:'hold'}];

test('task gap category navigation finds candidates without public-search boilerplate',()=>{
  assert.equal(typeof curatedModel.taskDirectoryFilters,'function');
  const filters=curatedModel.taskDirectoryFilters('agent skill web design');
  assert.deepEqual(filters,{query:'',category:'design'});
  assert.deepEqual(filterCuratedEntries(entries,filters).map(entry=>entry.id),['design']);
  assert.deepEqual(curatedModel.taskDirectoryFilters('my custom design query'),{query:'my custom design query',category:''});
});

test('curated discovery combines functional tags, use and local evidence text',()=>{
  assert.deepEqual(filterCuratedEntries(entries,{category:'testing',use:'verify',query:'验证命令'}).map(entry=>entry.id),['verify']);
  assert.equal(filterCuratedEntries(entries,{category:'testing',use:'create'}).length,0);
  assert.deepEqual(filterCuratedEntries(entries,{query:'FRONTEND'}).map(entry=>entry.id),['design']);
});

test('metadata never becomes host readiness or effectiveness certification',()=>{
  assert.equal(curatedReadiness({...entries[0],evidence:{sourceReviewed:true}}),'待检查环境');
  assert.equal(curatedReadiness(entries[2]),'暂缓采用');
  assert.equal(deploymentLabel({status:'ready_for_install'}),'可安装文件');
  assert.equal(deploymentLabel({status:'installed_unverified'}),'已安装 · 宿主待验证');
});

test('metadata deployment notes never replace a required core-only warning',()=>{
  const core={decision:'candidate_core_only',deployment:'heavy: full repository runtime'};
  assert.equal(curatedReadiness(core),'需限定安装分支');
  assert.equal(curatedReadiness({...core,deployment:{status:'blocked',installAllowed:false}}),'暂不能安装');
});

test('file install requires a recognized explicit positive preflight result',()=>{
  assert.equal(deploymentAllowsInstall(undefined),false);
  assert.equal(deploymentAllowsInstall({}),false);
  assert.equal(deploymentAllowsInstall({status:'ready_for_install'}),false);
  assert.equal(deploymentAllowsInstall({status:'blocked',installAllowed:true}),false);
  assert.equal(deploymentAllowsInstall({status:'needs_setup',installAllowed:true}),true);
  assert.equal(deploymentAllowsInstall({status:'ready_for_install',installAllowed:true}),true);
});

test('environment recheck only changes deployment of the exact selected preview',()=>{
  const current={candidateId:'candidate',previewSha:'sha',source:{commit:'pinned'},content:'locked',deployment:{status:'needs_setup'}};
  const identity={candidateId:'candidate',previewSha:'sha'};
  const result=mergePreflight(current,{...identity,deployment:{status:'ready_for_install',installAllowed:true},content:'unexpected'},identity);
  assert.equal(result.content,'locked');
  assert.equal(result.source,current.source);
  assert.equal(result.deployment.status,'ready_for_install');
  assert.equal(mergePreflight({...current,candidateId:'other'},result,identity).candidateId,'other');
  assert.throws(()=>mergePreflight(current,{candidateId:'other',previewSha:'sha',deployment:{}},identity),/版本不一致/);
  assert.throws(()=>mergePreflight(current,identity,identity),/未返回部署状态/);
});
