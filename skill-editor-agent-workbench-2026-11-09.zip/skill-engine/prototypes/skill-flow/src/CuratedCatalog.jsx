import React, {useEffect, useMemo, useRef, useState} from 'react';
import {curatedReadiness,filterCuratedEntries,licenseLabel} from './curatedCatalogModel.mjs';

const list=value=>Array.isArray(value)?value:[];
const text=value=>typeof value==='string'?value:value==null?'':JSON.stringify(value);
const shortSha=value=>value?String(value).slice(0,12):'未提供';
const safeSource=url=>/^https:\/\/github\.com\//.test(url || '');

function EntryEvidence({entry,catalog}) {
  const category=list(catalog.functionCategories).find(item=>item.id===entry.category)?.label || entry.category;
  const uses=list(entry.useCases).map(id=>list(catalog.useCases).find(item=>item.id===id)?.label || id);
  const evidence=entry.evidence || {};
  const licenseUrl=entry.license?.url || entry.license?.evidence_url;
  return <details className="se-curated-evidence"><summary>来源与要求</summary><dl>
    <div><dt>用途</dt><dd>{[category,...uses].filter(Boolean).join(' · ')}</dd></div>
    <div><dt>来源</dt><dd>{safeSource(entry.source?.url)?<a className="se-source-link" href={entry.source.url} target="_blank" rel="noreferrer">{entry.source.repo}</a>:entry.source?.repo || '未提供'}<code>{entry.source?.path}</code></dd></div>
    <div><dt>固定版本</dt><dd><code title={entry.source?.ref}>{shortSha(entry.source?.ref)}</code>{entry.source?.blobSha && <code title={entry.source.blobSha}>入口 blob {shortSha(entry.source.blobSha)}</code>}</dd></div>
    <div><dt>许可证</dt><dd>{safeSource(licenseUrl)?<a className="se-source-link" href={licenseUrl} target="_blank" rel="noreferrer">{licenseLabel(entry.license)}</a>:licenseLabel(entry.license)}</dd></div>
    {list(entry.requirements).length>0 && <div><dt>需要</dt><dd><ul>{entry.requirements.map((item,index)=><li key={index}>{text(item)}</li>)}</ul></dd></div>}
    {list(entry.optionalRequirements).length>0 && <div><dt>可选依赖</dt><dd><ul>{entry.optionalRequirements.map((item,index)=><li key={index}>{text(item)}</li>)}</ul></dd></div>}
    {list(entry.limitations).length>0 && <div><dt>限制</dt><dd><ul>{entry.limitations.map((item,index)=><li key={index}>{text(item)}</li>)}</ul></dd></div>}
    <div><dt>核对记录</dt><dd>{evidence.sourceReviewed?'来源资料已核对':'来源核对未记录'}；宿主发现与任务效果待验证。{evidence.upstreamEvidence && <p>{evidence.upstreamEvidence}</p>}</dd></div>
    {entry.hostDeclaration && <div><dt>宿主声明</dt><dd>{entry.hostDeclaration}</dd></div>}
    {entry.modelDeclaration && <div><dt>模型声明</dt><dd>{entry.modelDeclaration}</dd></div>}
  </dl></details>;
}

function EntryRows({entries,catalog,busy,selectedId,onInspect}) {
  return <ul className="se-curated-list">{entries.map(entry=><li key={entry.id} className={selectedId===entry.id?'selected':''}>
    <div className="se-curated-main"><div className="se-curated-title"><h3>{entry.name || entry.title}</h3><span className={`se-readiness ${entry.deployment?.status || (entry.decision==='hold'?'blocked':'unknown')}`}>{curatedReadiness(entry)}</span></div><p>{entry.title || entry.description || '用途资料待补齐'}</p><EntryEvidence entry={entry} catalog={catalog}/></div>
    <button className="se-button secondary" disabled={busy} onClick={()=>onInspect(entry)} aria-label={`检查 ${entry.name || entry.title} 的安装条件`}>检查安装条件</button>
  </li>)}</ul>;
}

export default function CuratedCatalog({query,onQueryChange,initialCategory='',loadCatalog,busy,selectedId,deployments,onInspect}) {
  const [catalog,setCatalog]=useState(null),[loading,setLoading]=useState(true),[error,setError]=useState(''),[category,setCategory]=useState(initialCategory),[use,setUse]=useState('');
  const revision=useRef(0),controller=useRef(null);
  async function load() {
    controller.current?.abort();const next=new AbortController();controller.current=next;const rev=++revision.current;setLoading(true);setError('');
    try {const value=await loadCatalog(next.signal);if(rev===revision.current)setCatalog(value);}catch(err){if(err.name!=='AbortError' && rev===revision.current)setError(err.message);}finally{if(rev===revision.current)setLoading(false);}
  }
  useEffect(()=>{load();return()=>{revision.current++;controller.current?.abort();};},[loadCatalog]);
  useEffect(()=>{setCategory(initialCategory);setUse('');},[initialCategory]);
  const filtered=useMemo(()=>filterCuratedEntries(list(catalog?.entries).map(entry=>deployments?.[entry.id]?{...entry,deployment:deployments[entry.id]}:entry),{query,category,use}),[catalog,query,category,use,deployments]);
  const candidates=filtered.filter(entry=>entry.decision!=='hold'),held=filtered.filter(entry=>entry.decision==='hold');
  const activeFilters=Boolean(query.trim() || category || use);
  function clearFilters(){onQueryChange('');setCategory('');setUse('');}
  return <section className="se-curated" aria-label="精选技能目录">
    <div className="se-curated-controls"><label className="se-curated-query"><span className="se-sr-only">在精选目录中查找</span><input type="search" value={query} onChange={event=>onQueryChange(event.target.value)} placeholder="查找技能或任务关键词" maxLength={180}/></label><label><span className="se-sr-only">功能分类</span><select value={category} onChange={event=>setCategory(event.target.value)}><option value="">全部功能</option>{list(catalog?.functionCategories).map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</select></label><label><span className="se-sr-only">用途</span><select value={use} onChange={event=>setUse(event.target.value)}><option value="">全部用途</option>{list(catalog?.useCases).map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</select></label></div>
    <div className="se-curated-heading"><p role="status" aria-live="polite">{loading?'正在读取精选目录…':`${candidates.length} 项候选${held.length?` · ${held.length} 项暂缓`:''}`}{catalog?.researchedOn && <span>资料核对 {catalog.researchedOn}</span>}</p>{activeFilters && <button className="se-button quiet" onClick={clearFilters}>清除筛选</button>}</div>
    {error && <div className="se-message error" role="alert"><p>{error}</p><button className="se-button quiet" onClick={load}>重新读取</button></div>}
    {loading && !catalog && <div className="se-curated-loading" aria-hidden="true">{[0,1,2].map(item=><div key={item}><i/><i/></div>)}</div>}
    {catalog && <><EntryRows entries={candidates} catalog={catalog} busy={busy} selectedId={selectedId} onInspect={onInspect}/>{!candidates.length && <div className="se-curated-empty"><p>{activeFilters?'没有匹配的候选。可调整关键词、功能或用途。':'目录暂未返回候选，请重新读取。'}</p>{activeFilters?<button className="se-button secondary" onClick={clearFilters}>显示全部候选</button>:<button className="se-button secondary" onClick={load}>重新读取</button>}</div>}{held.length>0 && <details className="se-curated-held"><summary>暂缓采用（{held.length}）</summary><EntryRows entries={held} catalog={catalog} busy={busy} selectedId={selectedId} onInspect={onInspect}/></details>}</>}
  </section>;
}
