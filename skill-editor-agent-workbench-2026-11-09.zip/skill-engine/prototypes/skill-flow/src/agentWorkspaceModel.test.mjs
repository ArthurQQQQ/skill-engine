import test from 'node:test';
import assert from 'node:assert/strict';
import {
  agentCountLabel,
  agentDetectionLabel,
  agentWorkspaceReducer,
  chooseAgentId,
  initialAgentWorkspaceState,
  normalizeAgentSnapshot,
  rootStatusLabel,
} from './agentWorkspaceModel.mjs';

const root = overrides => ({path:'/Users/example/.codex/skills',exists:true,count:0,countComplete:true,scope:'personal',shared:false,status:'present',...overrides});
const agent = overrides => ({id:'codex',name:'Codex',detected:true,executableDetected:true,configurationDetected:true,skillCount:0,countComplete:true,status:'detected',roots:[root()],evidence:[],runtimeStatus:'unverified',...overrides});
const snapshot = agents => normalizeAgentSnapshot({agents,checkedAt:'2026-11-09T12:00:00Z'});

test('zero files remains a known empty directory; missing and unreadable roots stay unknown', () => {
  const value = snapshot([
    agent(),
    agent({id:'missing',skillCount:null,countComplete:false,status:'not_detected',detected:false,roots:[root({exists:false,count:null,countComplete:false,status:'missing'})]}),
    agent({id:'unreadable',skillCount:null,countComplete:false,status:'unavailable',detected:false,roots:[root({exists:null,count:null,countComplete:false,status:'unavailable'})]}),
  ]);
  assert.equal(agentCountLabel(value.agents[0]), '0 个技能文件');
  assert.equal(agentCountLabel(value.agents[1]), '数量未知');
  assert.equal(rootStatusLabel(value.agents[1].roots[0]), '目录不存在');
  assert.equal(rootStatusLabel(value.agents[2].roots[0]), '读取失败');
  assert.equal(agentDetectionLabel(value.agents[2]), '读取失败');
});

test('partial counts do not look like complete installation or runtime verification', () => {
  const value = snapshot([agent({skillCount:12,countComplete:false,runtimeStatus:'connected'})]).agents[0];
  assert.equal(agentCountLabel(value), '至少 12 个技能文件');
  assert.equal(value.runtimeStatus, 'unverified');
  assert.equal(agentDetectionLabel(agent({executableDetected:false,configurationDetected:true})), '配置目录可见');
});

test('normalization rejects malformed snapshots and does not invent counts or installation permission', () => {
  assert.throws(() => normalizeAgentSnapshot({}), /Agent/);
  assert.throws(() => snapshot([agent(),agent()]), /重复/);
  const value = snapshot([agent({skillCount:-2,roots:[root({count:'3'})],installation:{agentId:'codex',targetPath:'/tmp/skills',available:'true'}})]).agents[0];
  assert.equal(value.skillCount, null);
  assert.equal(value.roots[0].count, null);
  assert.equal(value.installation.available, false);
  assert.equal(value.installation.targetPath, '/tmp/skills');
});

test('personal library count is kept separate from host counts', () => {
  const value = normalizeAgentSnapshot({agents:[agent({skillCount:40})],library:{path:'/Users/example/.codex/skills',personalCount:5,countComplete:true,roots:[root({count:5})]}});
  assert.equal(value.library.personalCount, 5);
  assert.equal(value.agents[0].skillCount, 40);
  assert.equal(value.library.path, '/Users/example/.codex/skills');
});

test('directory compatibility and scan warnings survive normalization as separate evidence', () => {
  const value = snapshot([agent({detectionComplete:false,roots:[root({relationship:'compatibility',supportStatus:'unverified',sourceUrl:'https://example.com/skills',message:'仅检测文件',warnings:[{path:'/skills/link',status:'symlink_skipped',message:'未跟随链接'}]})]})]).agents[0];
  assert.equal(value.detectionComplete, false);
  assert.equal(value.roots[0].supportStatus, 'unverified');
  assert.equal(value.roots[0].relationship, 'compatibility');
  assert.equal(value.roots[0].warnings[0].status, 'symlink_skipped');
  assert.equal(value.runtimeStatus, 'unverified');
});

test('only an explicit installation permission for this agent and a real target path enables its action', () => {
  const value = snapshot([
    agent({id:'ready',installation:{agentId:'ready',targetPath:'/Users/example/.agents/skills',available:true}}),
    agent({id:'mismatch',installation:{agentId:'other',targetPath:'/Users/example/.agents/skills',available:true}}),
    agent({id:'empty',installation:{agentId:'empty',targetPath:' ',available:true}}),
  ]);
  assert.equal(value.agents[0].installation.available, true);
  assert.equal(value.agents[1].installation.available, false);
  assert.equal(value.agents[2].installation.available, false);
});

test('selection is resolved against the new snapshot after removal or replacement', () => {
  assert.equal(chooseAgentId([agent({id:'claude',status:'not_detected'}),agent()], 'removed'), 'codex');
  assert.equal(chooseAgentId([agent({id:'claude'}),agent()], 'claude'), 'claude');
  assert.equal(chooseAgentId([], 'codex'), null);
});

test('refresh discards stale details and ignores old successful or failed requests', () => {
  let state = agentWorkspaceReducer(initialAgentWorkspaceState, {type:'start',requestId:1});
  state = agentWorkspaceReducer(state, {type:'success',requestId:1,snapshot:snapshot([agent()])});
  assert.equal(state.selectedId, 'codex');
  state = agentWorkspaceReducer(state, {type:'start',requestId:2});
  assert.equal(state.snapshot, null);
  assert.equal(state.phase, 'loading');
  const loading = state;
  state = agentWorkspaceReducer(state, {type:'success',requestId:1,snapshot:snapshot([agent({id:'old'})])});
  assert.equal(state, loading);
  state = agentWorkspaceReducer(state, {type:'failure',requestId:1,error:'old error'});
  assert.equal(state, loading);
  state = agentWorkspaceReducer(state, {type:'success',requestId:2,snapshot:snapshot([agent({id:'cursor'})])});
  assert.equal(state.selectedId, 'cursor');
  assert.equal(state.snapshot.agents[0].id, 'cursor');
});

test('selection and failures cannot expose an agent outside the current response', () => {
  let state = agentWorkspaceReducer(initialAgentWorkspaceState, {type:'start',requestId:1});
  state = agentWorkspaceReducer(state, {type:'success',requestId:1,snapshot:snapshot([agent()])});
  const selected = state;
  assert.equal(agentWorkspaceReducer(state, {type:'select',id:'removed'}), selected);
  state = agentWorkspaceReducer(state, {type:'start',requestId:2});
  state = agentWorkspaceReducer(state, {type:'failure',requestId:2,error:'无法读取'});
  assert.equal(state.snapshot, null);
  assert.equal(state.selectedId, null);
  assert.equal(state.error, '无法读取');
});
