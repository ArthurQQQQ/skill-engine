const count = value => Number.isSafeInteger(value) && value >= 0 ? value : null;
const text = value => typeof value === 'string' ? value : '';
const list = value => Array.isArray(value) ? value : [];
const record = value => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
const booleanOrUnknown = value => typeof value === 'boolean' ? value : null;
const AGENT_STATUSES = new Set(['detected','not_detected','unavailable']);
const ROOT_STATUSES = new Set(['present','missing','symlink_skipped','external_skipped','unavailable','not_directory','limit_reached']);

function normalizeRoot(value) {
  const root = record(value);
  return {
    path:text(root.path),
    exists:booleanOrUnknown(root.exists),
    count:count(root.count),
    countComplete:root.countComplete === true,
    scope:text(root.scope),
    shared:root.shared === true,
    status:ROOT_STATUSES.has(root.status) ? root.status : 'unknown',
    relationship:text(root.relationship),
    supportStatus:text(root.supportStatus),
    sourceUrl:/^https:\/\//.test(text(root.sourceUrl)) ? root.sourceUrl : '',
    message:text(root.message),
    warnings:list(root.warnings).map(value => {
      const warning = record(value);
      return {path:text(warning.path),status:text(warning.status),message:text(warning.message),error:text(warning.error)};
    }),
    error:text(root.error),
  };
}

function normalizeEvidence(value) {
  if (typeof value === 'string') return {kind:'',path:'',status:'',exists:null,message:value};
  const evidence = record(value);
  return {
    kind:text(evidence.kind),
    path:text(evidence.path),
    status:text(evidence.status),
    exists:booleanOrUnknown(evidence.exists),
    message:text(evidence.message),
  };
}

function normalizeInstallation(value, agentId) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const targetPath = text(value.targetPath).trim();
  return {
    agentId:text(value.agentId) || agentId,
    targetPath,
    shared:value.shared === true,
    available:value.available === true && Boolean(targetPath) && (!value.agentId || value.agentId === agentId),
    reason:text(value.reason),
  };
}

/** File and directory evidence only. No response can assert runtime loading here. */
export function normalizeAgentSnapshot(value) {
  const payload = record(value);
  if (!Array.isArray(payload.agents)) throw new Error('Agent 状态数据不完整，请刷新实况。');
  const seen = new Set();
  const agents = payload.agents.map(value => {
    const agent = record(value);
    const id = text(agent.id).trim();
    const name = text(agent.name).trim();
    if (!id || !name) throw new Error('Agent 状态缺少名称或标识，请刷新实况。');
    if (seen.has(id)) throw new Error('Agent 状态出现重复标识，请刷新实况。');
    seen.add(id);
    return {
      id,
      name,
      detected:agent.detected === true,
      detectionComplete:booleanOrUnknown(agent.detectionComplete),
      executableDetected:booleanOrUnknown(agent.executableDetected),
      configurationDetected:booleanOrUnknown(agent.configurationDetected),
      skillCount:count(agent.skillCount),
      countComplete:agent.countComplete === true,
      status:AGENT_STATUSES.has(agent.status) ? agent.status : 'unknown',
      roots:list(agent.roots).map(normalizeRoot),
      evidence:list(agent.evidence).map(normalizeEvidence),
      runtimeStatus:'unverified',
      installation:normalizeInstallation(agent.installation, id),
      error:text(agent.error),
    };
  });
  const library = record(payload.library);
  return {
    agents,
    checkedAt:text(payload.checkedAt),
    library:{
      path:text(library.path),
      personalCount:count(library.personalCount),
      countComplete:library.countComplete === true,
      roots:list(library.roots).map(normalizeRoot),
    },
  };
}

export function fileCountLabel(value, complete = false) {
  const knownCount = count(value);
  if (knownCount === null) return '数量未知';
  if (!complete && knownCount === 0) return '数量未完整读取';
  return `${complete ? '' : '至少 '}${knownCount.toLocaleString('zh-CN')} 个技能文件`;
}

export function agentCountLabel(agent) {
  return fileCountLabel(agent?.skillCount, agent?.countComplete === true);
}

export function agentDetectionLabel(agent) {
  if (agent?.status === 'unavailable') return '读取失败';
  if (agent?.status === 'not_detected') return '未检测到';
  if (agent?.status !== 'detected') return '状态未知';
  if (agent.configurationDetected === true && agent.executableDetected !== true) return '配置目录可见';
  if (agent.executableDetected === true && agent.configurationDetected !== true) return '检测到可执行文件';
  return '检测到';
}

export function rootStatusLabel(root) {
  const labels = {
    missing:'目录不存在',
    symlink_skipped:'符号链接未读取',
    external_skipped:'外置目录未读取',
    unavailable:'读取失败',
    not_directory:'路径不是目录',
    limit_reached:'目录未完整读取',
  };
  if (root?.status === 'present' && root.exists === true) return '目录可见';
  return labels[root?.status] || '状态待核对';
}

export function rootScopeLabel(root) {
  if (root?.relationship === 'editor_library' || root?.scope === 'editor') return '编辑器目录';
  if (root?.shared) return '共享目录';
  if (root?.relationship === 'compatibility') return '兼容路径';
  return {personal:'个人目录',user:'个人目录',project:'项目目录',system:'系统目录',shared:'共享目录'}[root?.scope] || '技能目录';
}

export function chooseAgentId(agents, previousId) {
  const available = list(agents);
  if (available.some(agent => agent.id === previousId)) return previousId;
  return (available.find(agent => agent.status === 'detected' && agent.roots.some(root => root.exists === true))
    || available.find(agent => agent.status === 'detected')
    || available[0])?.id || null;
}

export const initialAgentWorkspaceState = {
  phase:'idle',
  requestId:0,
  snapshot:null,
  selectedId:null,
  error:'',
};

export function agentWorkspaceReducer(state, action) {
  if (action.type === 'start') {
    if (!Number.isSafeInteger(action.requestId) || action.requestId <= state.requestId) return state;
    return {...state,phase:'loading',requestId:action.requestId,snapshot:null,error:''};
  }
  if (action.type === 'select') {
    if (!state.snapshot?.agents.some(agent => agent.id === action.id)) return state;
    return {...state,selectedId:action.id};
  }
  if (action.requestId !== state.requestId || state.phase !== 'loading') return state;
  if (action.type === 'success') {
    return {...state,phase:'ready',snapshot:action.snapshot,selectedId:chooseAgentId(action.snapshot.agents,state.selectedId),error:''};
  }
  if (action.type === 'failure') {
    return {...state,phase:'error',snapshot:null,selectedId:null,error:action.error || '无法读取本机 Agent，请刷新实况。'};
  }
  return state;
}
