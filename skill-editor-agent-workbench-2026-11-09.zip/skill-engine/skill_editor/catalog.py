"""Pinned skill discovery and reversible full-directory transactions.

Remote archives are untrusted data. Nothing here imports, evaluates, installs
dependencies from, or invokes their contents. Runtime skill trees contain only
the selected upstream directory; editor provenance and backups live separately.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import difflib
import fcntl
import gzip
import hashlib
import io
import json
import base64
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .core import EditorError, SkillStore, description_span, _frontmatter_lines
from . import curated as reviewed_directory


MAX_ARCHIVE = 20_000_000
MAX_TOTAL = 40_000_000
MAX_FILE = 2_000_000
MAX_FILES = 2000
MAX_JSON = 2_000_000
MAX_PREVIEW = 12_000_000
CACHE_SECONDS = 600
GITHUB_SEARCH_SCOPE = "skill-metadata-v1"
SHA = re.compile(r"^[0-9a-f]{40}$")
IDENTIFIER = re.compile(r"^[0-9a-f]{32}$")
NAME = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


class _Tree(dict):
    """Bytes plus non-executable filesystem metadata; no archive objects escape parsing."""
    def __init__(self, files=None, *, modes=None, directories=None, root_mode=0o755):
        super().__init__(files or {})
        self.modes = modes or {}
        self.directories = directories or {}
        self.root_mode = root_mode
        self.archive_links = []


def _now():
    return datetime.now(timezone.utc).isoformat()


def _digest(raw):
    return hashlib.sha256(raw).hexdigest()


def _canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _internal(path):
    return SkillStore._physical_internal(Path(path))


def _directory_fd(path):
    """Open a physical directory without following any replaced ancestor."""
    path = _internal(path)
    descriptor = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _identity(info):
    return {"device": info.st_dev, "inode": info.st_ino}


def _matches_identity(info, identity):
    return isinstance(identity, dict) and all(isinstance(identity.get(key), int) and not isinstance(identity.get(key), bool) for key in ("device", "inode")) and _identity(info) == identity


def _write(path, raw):
    path = _internal(path)
    _internal(path.parent)
    descriptor, temporary = tempfile.mkstemp(prefix=".catalog-", dir=path.parent)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        _internal(path)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _read_json(path, default=None, *, limit=MAX_JSON):
    _internal(path)
    try:
        with path.open("rb") as handle:
            raw = handle.read(limit + 1)
    except FileNotFoundError:
        return default
    if len(raw) > limit:
        raise EditorError("Catalog state exceeds its size limit.", 413)
    try:
        return json.loads(raw)
    except (ValueError, UnicodeError):
        raise EditorError("Catalog state is invalid; existing files were preserved.", 409) from None


def _mkdir_internal(path):
    """Create a physical directory without following a swapped ancestor."""
    path = _internal(path)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    descriptor = os.open("/", flags)
    try:
        for part in path.parts[1:]:
            try:
                child = os.open(part, flags, dir_fd=descriptor)
            except FileNotFoundError:
                try:
                    os.mkdir(part, mode=0o700, dir_fd=descriptor)
                except FileExistsError:
                    pass
                child = os.open(part, flags, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        _internal(path)
    except OSError:
        raise EditorError("Installation root changed or is not a writable physical directory.", 403) from None
    finally:
        os.close(descriptor)


def _path(value, *, allow_root=False):
    if not isinstance(value, str) or len(value) > 1000:
        raise EditorError("Select an exact repository skill path.")
    if value in ("", ".") and allow_root:
        return ""
    if not value or value.startswith("/") or "\\" in value or any(ord(c) < 32 for c in value):
        raise EditorError("Repository paths must be relative without traversal.")
    parts = value.split("/")
    if any(part in ("", ".", "..") for part in parts) or ":" in parts[0]:
        raise EditorError("Repository paths must be relative without traversal.")
    if any(part.casefold() in (".skill-editor", ".system") for part in parts):
        raise EditorError("Editor notes and system directories cannot enter a runtime skill.", 403)
    return "/".join(parts)


def _metadata(raw):
    try:
        content = raw.decode("utf-8")
        lines, closing = _frontmatter_lines(content)
        names = [line.split(":", 1)[1].strip() for line in lines[1:closing] if re.match(r"^name[ \t]*:", line)]
        if len(names) != 1:
            raise EditorError("The selected SKILL.md must declare one name.")
        name = names[0]
        if name.startswith('"'):
            name = json.loads(name)
        elif name.startswith("'") and name.endswith("'"):
            name = name[1:-1].replace("''", "'")
        else:
            name = re.split(r"\s+#", name, maxsplit=1)[0].strip()
        if not isinstance(name, str) or not NAME.fullmatch(name):
            raise EditorError("Skill name must be a lowercase letter/digit/hyphen directory name, at most 64 characters.")
        description = description_span(content)[2]
        if not description.strip():
            raise EditorError("The selected SKILL.md must declare a description.")
    except (UnicodeError, ValueError) as error:
        if isinstance(error, EditorError):
            raise
        raise EditorError("The selected SKILL.md has unsupported UTF-8 frontmatter.") from None
    requirements = []
    for line in lines[1:closing]:
        if re.match(r"^(compatibility|allowed-tools)[ \t]*:", line):
            requirements.append({"kind": line.split(":", 1)[0], "evidence": line.strip(), "verified": False})
    return name, description, content, requirements


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # In particular, never carry an API authorization header to a new host.
        raise EditorError("Upstream redirect rejected; no credentials were forwarded.", 502)


class CatalogService:
    def __init__(self, store, *, target_root=None, state_namespace=None):
        self.store = store
        if state_namespace is not None and (not isinstance(state_namespace, str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,39}", state_namespace)):
            raise EditorError("Select a known Agent catalog namespace.")
        if target_root is not None and not state_namespace:
            raise EditorError("A separate Agent target requires its own catalog state.")
        self.install_root = _internal(Path(target_root) if target_root is not None else store.personal_root)
        self.root = _internal(store.project / ".state/catalog-agents" / state_namespace if state_namespace else store.project / ".state/catalog")
        self.candidates = self.root / "candidates"
        self.backups = self.root / "backups"
        self.cache = self.root / "search"
        self.transactions = self.root / "transactions"
        for path in (self.root, self.candidates, self.backups, self.cache, self.transactions):
            _internal(path)
            path.mkdir(parents=True, exist_ok=True, mode=0o700)
            _internal(path)
        self.managed_path = self.root / "managed.json"
        self.recovery_warnings = []
        self.journal_warnings = []
        with self._locked():
            if state_namespace:
                binding_path = _internal(self.root / "target-root.json")
                if binding_path.exists():
                    binding = _read_json(binding_path, limit=10_000)
                    if not isinstance(binding, dict) or binding.get("targetRoot") != str(self.install_root):
                        raise EditorError("This Agent catalog belongs to a different installation root; recovery and writes were stopped.", 409)
                else:
                    _write(binding_path, _canonical({"schemaVersion": 1, "targetRoot": str(self.install_root)}))
            self._recover()

    @contextmanager
    def _locked(self):
        with self.store._lock:
            lock_path = _internal(self.root / "transaction.lock")
            descriptor = os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX)
                yield
            finally:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
                os.close(descriptor)

    def config(self):
        oidc = bool(os.environ.get("VERCEL_OIDC_TOKEN"))
        return {
            "sources": {
                "github": {"available": True, "authenticated": bool(os.environ.get("SKILL_EDITOR_GITHUB_TOKEN") or os.environ.get("GITHUB_TOKEN")), "label": "GitHub repositories", "popularityMetric": "Repository stars"},
                "skills": {"available": oidc, "oidcConfigured": oidc, "reason": "A fresh configured Vercel OIDC token is read for each uncached request; upstream verifies validity." if oidc else "The formal skills.sh API requires VERCEL_OIDC_TOKEN; no undocumented scraping is used.", "popularityMetric": "Skill installs"},
            },
            "installRoot": str(_internal(self.install_root)),
            "installPolicy": "Selected pinned preview only; existing names are never overwritten by a new install.",
            "updates": "Selected full-version preview and current-tree SHA required; local changes are disclosed and backed up.",
            "limits": {"archiveBytes": MAX_ARCHIVE, "fileBytes": MAX_FILE, "expandedBytes": MAX_TOTAL, "files": MAX_FILES},
            "recoveryWarnings": list(self.recovery_warnings),
            "journalWarnings": list(self.journal_warnings),
        }

    def curated(self, query="", category="", use_case=""):
        return reviewed_directory.directory_result(self.store.project, query, category, use_case)

    def _fetch(self, url, *, limit):
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != "https" or parsed.hostname not in ("api.github.com", "codeload.github.com", "skills.sh") or parsed.username or parsed.password or parsed.port is not None or parsed.fragment:
            raise EditorError("Only official configured source HTTPS endpoints are allowed.", 403)
        headers = {"User-Agent": "SkillEditor/0.1", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
        token = os.environ.get("SKILL_EDITOR_GITHUB_TOKEN") or os.environ.get("GITHUB_TOKEN")
        if token and parsed.hostname == "api.github.com":
            if any(c in token for c in "\r\n"):
                raise EditorError("GitHub credential configuration is invalid.", 503)
            headers["Authorization"] = "Bearer " + token
        if parsed.hostname == "skills.sh":
            oidc = os.environ.get("VERCEL_OIDC_TOKEN")
            if not oidc or any(c in oidc for c in "\r\n"):
                raise EditorError("The formal skills.sh API requires a valid VERCEL_OIDC_TOKEN.", 503)
            headers = {"User-Agent": "SkillEditor/0.1", "Accept": "application/json", "Authorization": "Bearer " + oidc}
        request = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.build_opener(_NoRedirect()).open(request, timeout=25) as response:
                if response.geturl() != url:
                    raise EditorError("Unexpected upstream URL rejected.", 502)
                length = response.headers.get("Content-Length")
                if length and (not length.isdigit() or int(length) > limit):
                    raise EditorError("Upstream response exceeds its size limit.", 413)
                raw = response.read(limit + 1)
        except urllib.error.HTTPError as error:
            code = error.code
            if parsed.hostname == "skills.sh":
                if code in (401, 403):
                    raise EditorError("skills.sh rejected the OIDC identity. Configure a fresh Vercel OIDC token.", 503) from None
                if code == 429:
                    raise EditorError("skills.sh rate limit reached. Try again later.", 503) from None
                raise EditorError("The formal skills.sh API is unavailable.", 503) from None
            if code in (401, 403, 429):
                raise EditorError("GitHub denied the request or its rate limit was reached. Check the source configuration.", 503) from None
            if code == 404:
                raise EditorError("GitHub repository, path, or revision was not found.", 404) from None
            raise EditorError("GitHub returned an upstream error.", 502) from None
        except EditorError:
            raise
        except (urllib.error.URLError, TimeoutError, OSError, ValueError):
            raise EditorError("The selected source could not be reached; no alternate service was used.", 502) from None
        if len(raw) > limit:
            raise EditorError("Upstream response exceeds its size limit.", 413)
        return raw

    def _api(self, path):
        raw = self._fetch("https://api.github.com" + path, limit=MAX_JSON)
        try:
            value = json.loads(raw)
        except (ValueError, UnicodeError):
            raise EditorError("GitHub returned unsupported data.", 502) from None
        if not isinstance(value, dict):
            raise EditorError("GitHub returned unsupported data.", 502)
        return value

    def search(self, query, source="github", sort="stars"):
        if source == "skills":
            return self._skills_search(query, sort)
        if source != "github" or sort not in ("stars", "updated"):
            raise EditorError("Choose GitHub and sort by stars or updated.")
        if not isinstance(query, str) or not query.strip() or len(query) > 180 or any(ord(c) < 32 for c in query):
            raise EditorError("Enter a public search query between 1 and 180 characters.")
        query = query.strip()
        # GitHub's documented repository search accepts in:name,description.
        # A task keyword alone would rank general software by repository stars.
        # This remains repository discovery, never proof that SKILL.md exists.
        effective_query = query + " skills in:name,description"
        scope = {"version": GITHUB_SEARCH_SCOPE, "kind": "skill-related-repository-candidates", "requiredTerm": "skills", "fields": ["name", "description"], "skillPresenceVerified": False}
        cache_path = self.cache / (_digest(_canonical([source, GITHUB_SEARCH_SCOPE, query, sort])) + ".json")
        with self._locked():
            saved = _read_json(cache_path)
        if isinstance(saved, dict) and time.time() - saved.get("cachedAt", 0) < CACHE_SECONDS:
            return {**saved["result"], "cached": True}
        params = urllib.parse.urlencode({"q": effective_query, "sort": sort, "order": "desc", "per_page": 20})
        try:
            response = self._api("/search/repositories?" + params)
        except EditorError:
            if isinstance(saved, dict) and isinstance(saved.get("result"), dict):
                old = saved["result"]
                return {**old, "cached": True, "stale": True, "warnings": [*old.get("warnings", []), "GitHub is unavailable; these are previously cached repository results."]}
            raise
        results = []
        for item in response.get("items", [])[:20]:
            if not isinstance(item, dict) or not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", str(item.get("full_name", ""))):
                continue
            repo = item["full_name"]
            metadata = str(item.get("name", "")) + " " + str(item.get("description") or "")
            if not re.search(r"(?:^|[^a-z0-9])skills?(?:$|[^a-z0-9])", metadata, flags=re.I):
                continue
            license_data = item.get("license") or {}
            results.append({"id": _digest(repo.lower().encode())[:24], "repo": repo, "url": "https://github.com/" + repo, "name": item.get("name", repo), "description": item.get("description") or "", "stars": item.get("stargazers_count", 0), "starsScope": "repository", "updatedAt": item.get("updated_at"), "license": license_data.get("spdx_id") if isinstance(license_data, dict) else None, "defaultBranch": item.get("default_branch"), "path": None, "requiresPathSelection": True, "candidateKind": "repository", "skillPresenceVerified": False})
        result = {"source": source, "query": query, "effectiveQuery": effective_query, "scope": scope, "sort": sort, "results": results, "fetchedAt": _now(), "cached": False, "warnings": ["Search is limited to skill-related repository names/descriptions. Results are repository candidates; SKILL.md presence is not verified.", "Repository popularity is not a skill quality score. Inspect an actual SKILL.md directory before installing.", "Collections where the task wording appears only inside files may be absent. Exact repository/path inspection remains available."]}
        with self._locked():
            _write(cache_path, _canonical({"cachedAt": time.time(), "result": result}))
        return result

    def _skills_search(self, query, sort):
        token = os.environ.get("VERCEL_OIDC_TOKEN")
        if not token:
            raise EditorError(self.config()["sources"]["skills"]["reason"], 503)
        if not isinstance(query, str) or not 2 <= len(query.strip()) <= 180 or any(ord(c) < 32 for c in query):
            raise EditorError("skills.sh search requires 2 to 180 public query characters.")
        if sort not in ("stars", "updated"):
            raise EditorError("Unknown discovery sort.")
        query = query.strip()
        # JWT expiry is used only to bound cache lifetime, never as proof of identity.
        expires = time.time() + 60
        try:
            segment = token.split(".")[1]
            claims = json.loads(base64.urlsafe_b64decode(segment + "=" * (-len(segment) % 4)))
            exp = claims.get("exp") if isinstance(claims, dict) else None
            if isinstance(exp, (int, float)):
                expires = min(expires, exp)
        except (ValueError, IndexError, UnicodeError):
            pass
        if expires <= time.time():
            raise EditorError("The configured Vercel OIDC token has expired. Configure a fresh token.", 503)
        cache_path = self.cache / (_digest(_canonical(["skills", query])) + ".json")
        with self._locked():
            cached = _read_json(cache_path)
        if isinstance(cached, dict) and cached.get("expiresAt", 0) > time.time():
            return {**cached["result"], "cached": True}
        url = "https://skills.sh/api/v1/skills/search?" + urllib.parse.urlencode({"q": query, "limit": 20})
        try:
            value = json.loads(self._fetch(url, limit=MAX_JSON))
        except EditorError:
            raise
        except (ValueError, UnicodeError):
            raise EditorError("The formal skills.sh API returned unsupported data.", 502) from None
        if not isinstance(value, dict) or not isinstance(value.get("data"), list):
            raise EditorError("The formal skills.sh API returned unsupported data.", 502)
        results = []
        seen = set()
        for item in value["data"][:20]:
            if not isinstance(item, dict):
                continue
            repo = item.get("source")
            if not isinstance(repo, str) or not isinstance(item.get("slug"), str) or not isinstance(item.get("id"), str):
                continue
            is_github = item.get("sourceType") == "github" and isinstance(repo, str) and re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo)
            identity = (repo, item.get("slug"))
            if identity in seen:
                continue
            seen.add(identity)
            canonical_url = "https://github.com/" + repo if is_github else None
            results.append({"id": item.get("id"), "repo": repo, "url": canonical_url, "name": item.get("name") or item.get("slug"), "description": "", "stars": None, "starsScope": None, "installs": item.get("installs"), "installsScope": "skill", "updatedAt": None, "license": None, "path": None, "slugHint": item.get("slug"), "requiresPathSelection": True, "installable": bool(is_github), "sourceType": item.get("sourceType"), "isDuplicate": item.get("isDuplicate") is True, "catalogId": item.get("id"), "catalogUrl": "https://skills.sh/" + urllib.parse.quote(str(item.get("id", "")), safe="/"), "warning": None if is_github else "This source does not identify a supported GitHub repository. It cannot be installed by this adapter."})
        result = {"source": "skills", "query": query, "sort": "source_relevance", "searchType": value.get("searchType"), "results": results, "fetchedAt": _now(), "cached": False, "warnings": ["skills.sh returns source relevance order; repository-star/updated ordering is not offered by this formal search endpoint.", "Install counts measure skill popularity, not quality. A slug is a path hint; inspect the actual SKILL.md directory."]}
        with self._locked():
            _write(cache_path, _canonical({"expiresAt": expires, "result": result}))
        return result

    def _source_request(self, payload):
        url = payload.get("url")
        if not isinstance(url, str) or len(url) > 1800:
            raise EditorError("Provide an exact GitHub repository or skill URL.")
        parsed = urllib.parse.urlsplit(url)
        try:
            port = parsed.port
        except ValueError:
            raise EditorError("Invalid GitHub URL.") from None
        if parsed.scheme != "https" or parsed.hostname != "github.com" or parsed.username or parsed.password or port is not None or parsed.query or parsed.fragment:
            raise EditorError("Use an official GitHub HTTPS URL without credentials, query, or fragment.")
        decoded = urllib.parse.unquote(parsed.path).strip("/")
        parts = decoded.split("/")
        if len(parts) < 2 or not all(re.fullmatch(r"[A-Za-z0-9_.-]+", part) and part not in (".", "..") for part in parts[:2]):
            raise EditorError("GitHub URL must identify owner/repository.")
        repo = "/".join(parts[:2])
        if repo.endswith(".git"):
            repo = repo[:-4]
        path = payload.get("path")
        ref = payload.get("ref")
        if len(parts) > 2:
            if len(parts) < 4 or parts[2] not in ("tree", "blob"):
                raise EditorError("Select a repository, tree, or SKILL.md URL.")
            if ref is None:
                if SHA.fullmatch(parts[3]):
                    ref = parts[3]
                else:
                    raise EditorError("For tree/blob URLs, specify an exact ref to avoid branch/path ambiguity. Repository URLs may use their default branch.")
            if path is None:
                if ref != parts[3]:
                    # Slash-containing refs cannot be inferred by splitting a URL.
                    suffix = "/".join(parts[3:])
                    if not suffix.startswith(str(ref) + "/"):
                        raise EditorError("Specify exact path and ref for this URL.")
                    path = suffix[len(ref) + 1:]
                else:
                    path = "/".join(parts[4:])
        if path is not None:
            path = _path(path, allow_root=True)
            if path == "SKILL.md":
                path = ""
            elif path.endswith("/SKILL.md"):
                path = path[:-len("/SKILL.md")]
            elif path.endswith(".md"):
                raise EditorError("Select SKILL.md or its containing skill directory.")
        if ref is not None and (not isinstance(ref, str) or not ref or len(ref) > 200 or any(ord(c) < 32 for c in ref) or ref.startswith("/") or any(p in ("", ".", "..") for p in ref.split("/"))):
            raise EditorError("Provide an exact branch, tag, or commit ref.")
        return repo, path, ref

    def _unpack(self, raw, *, selected_path=None):
        if selected_path is not None:
            selected_path = _path(selected_path, allow_root=True)
        if len(raw) > MAX_ARCHIVE:
            raise EditorError("Repository archive exceeds its size limit.", 413)
        # Bound decompression before tar parsing: pax headers and directory
        # padding can otherwise expand without ever yielding a regular member.
        expanded_limit = MAX_TOTAL + MAX_FILES * 2048
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(raw)) as compressed:
                expanded = compressed.read(expanded_limit + 1)
        except (OSError, EOFError):
            raise EditorError("GitHub archive compression is invalid.", 502) from None
        if len(expanded) > expanded_limit:
            raise EditorError("Expanded repository archive exceeds its size limit.", 413)
        files = _Tree()
        known = set()
        spellings = {}
        root = None
        total = 0
        count = 0
        try:
            with tarfile.open(fileobj=io.BytesIO(expanded), mode="r:") as handle:
                for member in handle:
                    count += 1
                    if count > MAX_FILES:
                        raise EditorError("Repository archive contains too many entries.", 413)
                    name = member.name.rstrip("/") if member.isdir() else member.name
                    if not name or name.startswith("/") or "\\" in name or any(ord(c) < 32 for c in name):
                        raise EditorError("Unsafe archive path rejected.", 403)
                    parts = name.split("/")
                    if any(p in ("", ".", "..") for p in parts) or ":" in parts[0]:
                        raise EditorError("Archive traversal rejected.", 403)
                    if root is None:
                        root = parts[0]
                    if parts[0] != root or (len(parts) == 1 and not member.isdir()):
                        raise EditorError("Repository archive must have one enclosing directory.", 403)
                    for index in range(1, len(parts) + 1):
                        spelling = "/".join(parts[:index])
                        folded_spelling = spelling.casefold()
                        if folded_spelling in spellings and spellings[folded_spelling] != spelling:
                            raise EditorError("Case-colliding archive paths rejected.", 403)
                        spellings[folded_spelling] = spelling
                    folded = name.casefold()
                    if folded in known:
                        raise EditorError("Duplicate or case-colliding archive paths rejected.", 403)
                    known.add(folded)
                    if member.size < 0 or member.size > MAX_FILE:
                        raise EditorError("Repository entry exceeds the 2 MB limit.", 413)
                    total += member.size
                    if total > MAX_TOTAL:
                        raise EditorError("Expanded repository exceeds its size limit.", 413)
                    path = "/".join(parts[1:])
                    if member.issym() or member.islnk():
                        # Link headers are inspected only as data. They are never
                        # passed to extractfile, extracted, or dereferenced.
                        touches_selected = selected_path is not None and (selected_path == "" or path == selected_path or path.startswith(selected_path + "/") or selected_path.startswith(path + "/"))
                        if touches_selected:
                            raise EditorError("Links inside the selected skill directory or its ancestors are not supported.", 403)
                        files.archive_links.append({"path": path, "type": "symlink" if member.issym() else "hardlink", "target": member.linkname})
                        continue
                    if not (member.isfile() or member.isdir()):
                        raise EditorError("Archive special entries are not supported.", 403)
                    if member.isdir():
                        if len(parts) > 1:
                            files.directories["/".join(parts[1:])] = 0o755
                        continue
                    source = handle.extractfile(member)
                    if source is None:
                        raise EditorError("Archive file could not be read.", 502)
                    with source:
                        content = source.read(MAX_FILE + 1)
                    if len(content) != member.size or len(content) > MAX_FILE:
                        raise EditorError("Archive file size is invalid.", 413)
                    files[path] = content
                    files.modes[path] = 0o755 if member.mode & 0o111 else 0o644
                    for parent in PurePosixPath(path).parents:
                        if parent.as_posix() != ".":
                            files.directories.setdefault(parent.as_posix(), 0o755)
                    # Ancestors must never have been regular files.
                    if any("/".join(parts[1:i]) in files for i in range(2, len(parts))):
                        raise EditorError("Archive file/directory collision rejected.", 403)
        except (tarfile.TarError, EOFError, OSError):
            raise EditorError("GitHub archive was invalid; no files were installed.", 502) from None
        if not files:
            raise EditorError("Repository archive has no supported files.", 502)
        # A later regular file can also collide with an earlier descendant.
        folded_files = {key.casefold() for key in files} | {entry["path"].casefold() for entry in files.archive_links}
        for path in files:
            if any(parent.as_posix().casefold() in folded_files for parent in PurePosixPath(path).parents if parent.as_posix() != "."):
                raise EditorError("Archive file/directory collision rejected.", 403)
        return files

    def _tree(self, directory):
        """Bounded descriptor-relative reads; do not follow replaced ancestors."""
        directory = _internal(directory)
        root_fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            for part in directory.parts[1:]:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root_fd)
                os.close(root_fd)
                root_fd = child
            files = _Tree(root_mode=stat.S_IMODE(os.fstat(root_fd).st_mode))
            if files.root_mode & 0o7000:
                raise EditorError("Privileged skill directory modes cannot be replaced.", 403)
            total = 0
            count = 0

            def visit(fd, prefix):
                nonlocal total, count
                with os.scandir(fd) as iterator:
                    names = sorted(entry.name for entry in iterator)
                for name in names:
                    count += 1
                    if count > MAX_FILES or prefix.count("/") > 60:
                        raise EditorError("Skill directory contains too many entries or levels.", 413)
                    path = prefix + name
                    _path(path)
                    info = os.stat(name, dir_fd=fd, follow_symlinks=False)
                    if info.st_mode & 0o7000:
                        raise EditorError("Privileged skill resource modes cannot be replaced.", 403)
                    if stat.S_ISDIR(info.st_mode):
                        files.directories[path] = stat.S_IMODE(info.st_mode)
                        child_fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                        try:
                            visit(child_fd, path + "/")
                        finally:
                            os.close(child_fd)
                    elif stat.S_ISREG(info.st_mode) and info.st_nlink == 1:
                        file_fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=fd)
                        with os.fdopen(file_fd, "rb") as handle:
                            before = os.fstat(handle.fileno())
                            if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
                                raise EditorError("Non-regular or hard-linked skill files are read-only.", 403)
                            raw = handle.read(MAX_FILE + 1)
                            after = os.fstat(handle.fileno())
                        if len(raw) > MAX_FILE:
                            raise EditorError("Skill resource exceeds its size limit.", 413)
                        if (before.st_ino, before.st_size, before.st_mode, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_size, after.st_mode, after.st_mtime_ns, after.st_ctime_ns):
                            raise EditorError("Skill changed while being read. Prepare a fresh preview.", 409)
                        total += len(raw)
                        files[path] = raw
                        files.modes[path] = stat.S_IMODE(before.st_mode)
                        if total > MAX_TOTAL or len(files) > MAX_FILES:
                            raise EditorError("Skill directory exceeds its size limit.", 413)
                    else:
                        raise EditorError("Skill links and special files cannot be installed or replaced.", 403)
            visit(root_fd, "")
            return files
        finally:
            os.close(root_fd)

    @staticmethod
    def _files(files):
        modes = getattr(files, "modes", {})
        return [{"path": path, "bytes": len(raw), "sha256": _digest(raw), "mode": modes.get(path, 0o644)} for path, raw in sorted(files.items())]

    def _tree_sha(self, files):
        return _digest(_canonical({"files": self._files(files), "directories": getattr(files, "directories", {}), "rootMode": getattr(files, "root_mode", 0o755)}))

    def _write_tree(self, directory, files):
        _internal(directory)
        directory.mkdir(mode=0o700)
        directories = getattr(files, "directories", {})
        for path in sorted(directories, key=lambda item: (item.count("/"), item)):
            _internal(directory / _path(path)).mkdir(parents=True, exist_ok=True, mode=0o700)
        for path, raw in sorted(files.items()):
            safe = _path(path)
            target = _internal(directory / safe)
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with target.open("xb") as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            target.chmod(getattr(files, "modes", {}).get(path, 0o644) & 0o777)
        for path, mode in sorted(directories.items(), key=lambda item: -item[0].count("/")):
            _internal(directory / path).chmod(mode & 0o777)
        directory.chmod(getattr(files, "root_mode", 0o755) & 0o777)

    def _managed(self):
        value = _read_json(self.managed_path, {"schemaVersion": 1, "installs": {}})
        if not isinstance(value, dict) or not isinstance(value.get("installs"), dict):
            raise EditorError("Managed installation state is invalid; files were preserved.", 409)
        return value

    def _save_managed(self, value):
        raw = _canonical(value)
        if len(raw) > MAX_JSON:
            raise EditorError("Managed history exceeds its state limit; prior files were preserved.", 413)
        _write(self.managed_path, raw)

    @staticmethod
    def _committed_transactions(record):
        history = record.get("committedTransactionIds", [])
        if not isinstance(history, list) or any(not isinstance(value, str) or not IDENTIFIER.fullmatch(value) for value in history):
            raise EditorError("Committed transaction history is invalid; files were preserved.", 409)
        history = list(dict.fromkeys(history))
        # Retain the previous schema's sole commit marker during the first update.
        legacy = record.get("transactionId")
        if legacy is not None:
            if not isinstance(legacy, str) or not IDENTIFIER.fullmatch(legacy):
                raise EditorError("Committed transaction marker is invalid; files were preserved.", 409)
            if legacy not in history:
                history.append(legacy)
        return history

    def _preserve_recovery_directory(self, target, destination, identity, *, empty=False, expected_sha=None):
        """Move a proven directory into state; never delete a reservation."""
        source_fd = _directory_fd(target.parent)
        destination_fd = None
        try:
            destination_fd = _directory_fd(destination.parent)
            info = os.stat(target.name, dir_fd=source_fd, follow_symlinks=False)
            if not stat.S_ISDIR(info.st_mode) or not _matches_identity(info, identity):
                raise EditorError("Recovery directory identity cannot be proven.", 409)
            child_fd = os.open(target.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=source_fd)
            try:
                if not _matches_identity(os.fstat(child_fd), identity):
                    raise EditorError("Recovery directory identity changed.", 409)
                if empty:
                    with os.scandir(child_fd) as entries:
                        if next(entries, None) is not None:
                            raise EditorError("Install reservation acquired content; review is required.", 409)
            finally:
                os.close(child_fd)
            os.rename(target.name, destination.name, src_dir_fd=source_fd, dst_dir_fd=destination_fd)
            captured = os.stat(destination.name, dir_fd=destination_fd, follow_symlinks=False)
            if not _matches_identity(captured, identity):
                raise EditorError("Captured recovery directory changed; its contents were preserved for review.", 409)
            files = self._tree(destination)
            if empty and (files or files.directories) or expected_sha is not None and self._tree_sha(files) != expected_sha:
                raise EditorError("Captured recovery directory acquired changes; its contents were preserved for review.", 409)
        finally:
            os.close(source_fd)
            if destination_fd is not None:
                os.close(destination_fd)

    def _recover(self):
        """Recover interrupted renames without replacing externally changed trees.

        Immutable manifest transaction history is the commit evidence. Every
        other copy is retained, including empty install reservations.
        """
        managed = self._managed()
        for directory in sorted(self.transactions.iterdir()):
            if not IDENTIFIER.fullmatch(directory.name):
                continue
            try:
                _internal(directory)
                journal = _read_json(directory / "transaction.json")
                if journal is None:
                    continue
                if not isinstance(journal, dict):
                    raise EditorError("Interrupted transaction journal is invalid.", 409)
                if journal.get("status") in ("committed", "recovered"):
                    continue
                name = journal["name"]
                target = self._target(name)
                record = managed["installs"].get(journal["managedId"], {})
                committed = directory.name in self._committed_transactions(record)
                if committed:
                    try:
                        _write(directory / "transaction.json", _canonical({**journal, "status": "committed"}))
                    except (OSError, EditorError):
                        self.journal_warnings.append({"transactionId": directory.name, "message": "Installation is durably committed in manifest history, but transaction journal finalization remains pending."})
                    continue
                held = directory / "current"
                if held.exists():
                    original = self._tree(held)
                    if self._tree_sha(original) != journal["baselineSha"]:
                        raise EditorError("Preserved current directory changed.", 409)
                    if target.exists():
                        if self._tree_sha(self._tree(target)) != journal["expectedSha"]:
                            raise EditorError("Destination changed after interruption.", 409)
                        destination = directory / ("uncommitted-" + uuid.uuid4().hex)
                        os.rename(target, destination)
                    os.rename(held, target)
                elif journal["operation"] == "install" and target.exists():
                    current = self._tree(target)
                    if self._tree_sha(current) == journal["expectedSha"]:
                        self._preserve_recovery_directory(target, directory / ("uncommitted-" + uuid.uuid4().hex), journal.get("stagedIdentity"), expected_sha=journal["expectedSha"])
                    elif not current and not current.directories:
                        self._preserve_recovery_directory(target, directory / ("reservation-recovered-" + uuid.uuid4().hex), journal.get("reservation"), empty=True)
                    else:
                        raise EditorError("Destination changed after interruption.", 409)
                _write(directory / "transaction.json", _canonical({**journal, "status": "recovered"}))
            except (EditorError, OSError, KeyError, TypeError):
                self.recovery_warnings.append({"transactionId": directory.name, "message": "Interrupted transaction needs review. All captured, staged and current copies were preserved; catalog writes are blocked until it is resolved."})

    def _record(self, managed_id):
        if not isinstance(managed_id, str) or not IDENTIFIER.fullmatch(managed_id):
            raise EditorError("Select a managed personal installation.")
        record = self._managed()["installs"].get(managed_id)
        if not isinstance(record, dict):
            raise EditorError("Managed installation not found.", 404)
        self._target(record.get("name"))
        if record.get("targetPath") != str(self.install_root / record["name"]):
            raise EditorError("Managed installation target has changed; inspect configuration.", 409)
        return record

    def _target(self, name):
        if not isinstance(name, str) or not NAME.fullmatch(name):
            raise EditorError("Invalid personal skill directory name.")
        root = _internal(self.install_root)
        if ".system" in root.parts or self.store.plugin_cache_root == root or self.store.plugin_cache_root in root.parents:
            raise EditorError("System and plugin skill directories are read-only.", 403)
        target = _internal(root / name)
        if target.parent != root:
            raise EditorError("Only direct personal skill directories may be installed.", 403)
        return target

    @staticmethod
    def _diff(old, new):
        chunks = []
        for path in sorted(set(old) | set(new)):
            before_mode = getattr(old, "modes", {}).get(path)
            after_mode = getattr(new, "modes", {}).get(path)
            if old.get(path) == new.get(path) and before_mode == after_mode:
                continue
            if before_mode != after_mode:
                chunks.append(f"File mode {path}: {oct(before_mode) if before_mode is not None else 'absent'} → {oct(after_mode) if after_mode is not None else 'absent'}\n")
            before, after = old.get(path, b""), new.get(path, b"")
            try:
                if b"\x00" in before or b"\x00" in after:
                    raise UnicodeError()
                text = "".join(difflib.unified_diff(before.decode("utf-8").splitlines(keepends=True), after.decode("utf-8").splitlines(keepends=True), fromfile="current/" + path if path in old else "/dev/null", tofile="selected/" + path if path in new else "/dev/null"))
            except UnicodeError:
                text = f"Binary resource {path}: {len(before)} → {len(after)} bytes; SHA256 {_digest(before)} → {_digest(after)}\n"
            chunks.append(text)
        old_dirs, new_dirs = getattr(old, "directories", {}), getattr(new, "directories", {})
        for path in sorted(set(old_dirs) | set(new_dirs)):
            if old_dirs.get(path) != new_dirs.get(path):
                chunks.append(f"Directory {path}/: {oct(old_dirs[path]) if path in old_dirs else 'absent'} → {oct(new_dirs[path]) if path in new_dirs else 'absent'}\n")
        if getattr(old, "root_mode", None) != getattr(new, "root_mode", None):
            chunks.append(f"Skill directory mode: {getattr(old, 'root_mode', 'absent')} → {getattr(new, 'root_mode', 'absent')}\n")
        result = "\n".join(chunks)
        # Full file hashes and change lists remain in the preview even if large text is truncated.
        return result[:250_000], len(result) > 250_000

    def _prepare(self, files, source, operation, record=None, version_id=None, provenance_files=None):
        if "SKILL.md" not in files:
            raise EditorError("The selected directory does not contain SKILL.md.", 404)
        for path in files:
            _path(path)
        name, description, content, requirements = _metadata(files["SKILL.md"])
        if source.get("reviewedPinMatched") and name != source.get("reviewedName"):
            raise EditorError("Downloaded skill name does not match the trusted reviewed entry; inspect a corrected source.", 409)
        if record and name != record["name"]:
            raise EditorError("An update cannot rename an installed skill. Install a separately reviewed skill instead.", 409)
        target = self._target(name)
        current = self._tree(target) if target.exists() else {}
        baseline = self._tree_sha(current) if target.exists() else None
        warnings = ["Selected files are staged as data; scripts, dependencies and instructions have not been executed or security-certified.", "Installing a file does not prove that the current Codex session has exposed or activated the skill."]
        if source.get("kind") == "local":
            warnings.append("This is a complete snapshot of the selected personal library skill. Its original directory is preserved; later source changes require a fresh preview.")
        skipped_links = source.get("skippedArchiveLinks", [])
        if skipped_links:
            examples = ", ".join(entry["path"] for entry in skipped_links[:10])
            warnings.append(f"Skipped {len(skipped_links)} archive symlink/hardlink entries outside the explicitly selected skill directory: {examples}. No link was followed or copied.")
        if requirements:
            warnings.append("Declared runtime requirements have not been verified or installed.")
        target_status = "absent"
        if target.exists():
            if not record:
                target_status = "name_conflict"
                warnings.append("This personal skill name already exists. A new install will not overwrite it.")
            elif baseline != record.get("currentSha"):
                target_status = "locally_modified"
                warnings.append("Local modifications will be replaced only if this full-version preview is selected. The complete current directory will be preserved in a backup.")
            else:
                target_status = "managed"
        elif record:
            raise EditorError("Managed skill is missing. Restore or resolve its location before updating.", 409)
        diff, truncated = self._diff(current, files)
        if truncated:
            warnings.append("The text diff exceeds the display limit and is truncated. Review file hashes and the staged files before adopting this version.")
        candidate_id = uuid.uuid4().hex
        candidate = self.candidates / candidate_id
        candidate.mkdir(mode=0o700)
        self._write_tree(candidate / "tree", files)
        if provenance_files is not None:
            source = {**source, "provenance": {"candidateId": candidate_id, "files": self._files(provenance_files)}}
            self._write_tree(candidate / "provenance", provenance_files)
            _write(candidate / "provenance/source.json", _canonical(source))
        preview = {"candidateId": candidate_id, "source": source, "name": name, "description": description, "files": self._files(files), "directories": files.directories, "rootMode": files.root_mode, "content": content, "diff": diff, "diffTruncated": truncated, "changes": [{"path": path, "change": "added" if path not in current else "removed" if path not in files else "modified", "beforeSha": _digest(current[path]) if path in current else None, "afterSha": _digest(files[path]) if path in files else None, "beforeMode": getattr(current, "modes", {}).get(path), "afterMode": files.modes.get(path)} for path in sorted(set(current) | set(files)) if current.get(path) != files.get(path) or getattr(current, "modes", {}).get(path) != files.modes.get(path)], "operation": operation, "targetStatus": target_status, "baselineSha": baseline, "managedId": record["managedId"] if record else None, "versionId": version_id, "targetPath": str(target), "requirements": requirements, "warnings": warnings, "createdAt": _now(), "treeSha": self._tree_sha(files)}
        preview["deployment"] = reviewed_directory.deployment(self.store.project, preview, files)
        preview["previewSha"] = _digest(_canonical(preview))
        _write(candidate / "preview.json", _canonical(preview))
        return preview

    def _local_snapshot(self, skill_id, expected_source=None):
        """Resolve one editable inventory member; read its package only as data."""
        try:
            skill = self.store.skill(skill_id)
            entry = self.store.writable_path(skill)
            root = _internal(self.store.personal_root)
            package = _internal(entry.parent)
            if package.parent != root:
                raise EditorError("Only direct personal skill packages can be adopted by an Agent.", 403)
            if expected_source is not None and (expected_source.get("skillId") != skill_id or expected_source.get("path") != str(package)):
                raise EditorError("The original personal library skill identity changed. Inspect it again before adoption.", 409)
            descriptor = _directory_fd(package)
            try:
                before = os.fstat(descriptor)
                files = self._tree(package)
                after = package.lstat()
                if _identity(before) != _identity(after) or (before.st_mode, before.st_mtime_ns, before.st_ctime_ns) != (after.st_mode, after.st_mtime_ns, after.st_ctime_ns):
                    raise EditorError("The personal library package changed while being read. Inspect a fresh version.", 409)
            finally:
                os.close(descriptor)
        except OSError:
            raise EditorError("The original personal library package is unavailable; installed and staged files were preserved.", 409) from None
        source = {"kind": "local", "skillId": skill_id, "label": "个人技能库", "path": str(package), "revision": self._tree_sha(files), "identity": _identity(before)}
        return files, source

    def inspect_local(self, payload):
        if not isinstance(payload, dict) or payload.get("operation", "install") != "install":
            raise EditorError("Select one personal library skill for a new Agent installation.")
        with self._locked():
            files, source = self._local_snapshot(payload.get("skillId"))
            return self._prepare(files, source, "install")

    def inspect(self, payload):
        if not isinstance(payload, dict):
            raise EditorError("Inspection requires a source object.")
        operation = payload.get("operation", "install")
        if operation not in ("install", "update", "rollback"):
            raise EditorError("Choose install, update, or rollback.")
        curated_entry = None
        tracking_ref = None
        if "curatedId" in payload:
            if operation != "install":
                raise EditorError("Reviewed directory selection supports a new installation only.")
            curated_entry = reviewed_directory.resolve_entry(self.store.project, payload["curatedId"])
        if operation in ("update", "rollback"):
            with self._locked():
                record = self._record(payload.get("managedId"))
                if operation == "rollback":
                    version = self._version(record, payload.get("versionId"))
                    files = self._tree(self._backup_path(version) / "tree")
                    if self._tree_sha(files) != version["sha"]:
                        raise EditorError("Backup changed; it was not used.", 409)
                    return self._prepare(files, version["source"], operation, record, version["versionId"])
                if record["source"].get("kind") == "local":
                    files, source = self._local_snapshot(record["source"].get("skillId"), record["source"])
                    return self._prepare(files, source, operation, record)
            repo, path, ref = record["source"]["repo"], record["source"]["path"], record["source"]["ref"]
            tracking_ref = record["source"].get("trackingRef")
            ref = tracking_ref or ref
        else:
            record = None
            if curated_entry:
                selected = curated_entry["source"]
                repo, path, ref = selected["repo"], reviewed_directory.source_directory(selected), selected["ref"]
            else:
                repo, path, ref = self._source_request(payload)
        metadata = self._api("/repos/" + repo)
        if curated_entry:
            branch = metadata.get("default_branch")
            if isinstance(branch, str) and branch and len(branch) <= 200 and not any(ord(c) < 32 for c in branch) and not branch.startswith("/") and all(part not in ("", ".", "..") for part in branch.split("/")):
                tracking_ref = branch
        ref = ref or metadata.get("default_branch")
        if not isinstance(ref, str) or not ref:
            raise EditorError("Repository has no resolvable default branch.", 502)
        commit = self._api("/repos/" + repo + "/commits/" + urllib.parse.quote(ref, safe="")).get("sha")
        if not isinstance(commit, str) or not SHA.fullmatch(commit):
            raise EditorError("GitHub did not resolve an exact source commit.", 502)
        if curated_entry and commit != curated_entry["source"]["ref"]:
            raise EditorError("The reviewed source did not resolve to its exact pinned commit; no candidate was prepared.", 409)
        files = self._unpack(self._fetch("https://codeload.github.com/" + repo + "/tar.gz/" + commit, limit=MAX_ARCHIVE), selected_path=path)
        source = {"provider": "github", "repo": repo, "path": path, "ref": ref, "commit": commit, "url": "https://github.com/" + repo + "/tree/" + commit, "license": (metadata.get("license") or {}).get("spdx_id"), "fetchedAt": _now(), "skippedArchiveLinks": files.archive_links if path is not None else [], "archiveLinkCount": len(files.archive_links)}
        if tracking_ref:
            source["trackingRef"] = tracking_ref
            source["resolvedRef"] = ref
            if record:
                # Preserve the originally selected revision separately from the
                # branch used to discover this newly pinned complete version.
                source["ref"] = record["source"]["ref"]
        paths = sorted(key for key in files if (key == "SKILL.md" or key.endswith("/SKILL.md")) and ".skill-editor" not in key.split("/"))
        if path is None and (paths != ["SKILL.md"] or files.archive_links):
            if not paths:
                raise EditorError("Repository contains no SKILL.md directory to select.", 404)
            warnings = ["Select one actual SKILL.md path from this repository. A collection repository is not installed as a skill."]
            if files.archive_links:
                warnings.append("Archive contains links. Select an exact skill directory before unrelated links may be skipped. No link was followed or copied; selecting the repository root still rejects all links.")
            return {"status": "selection_required", "source": source, "paths": paths, "warnings": warnings}
        path = path or ""
        source["path"] = path
        source["url"] += ("/" + path) if path else ""
        prefix = path + "/" if path else ""
        subtree = _Tree({key[len(prefix):]: raw for key, raw in files.items() if key.startswith(prefix)}, modes={key[len(prefix):]: mode for key, mode in files.modes.items() if key.startswith(prefix)}, directories={key[len(prefix):]: mode for key, mode in files.directories.items() if key.startswith(prefix) and key != path})
        if curated_entry and ("SKILL.md" not in subtree or reviewed_directory.git_blob_sha(subtree["SKILL.md"]) != curated_entry["source"]["blobSha"]):
            raise EditorError("Downloaded SKILL.md does not match the reviewed Git blob SHA; no candidate was prepared.", 409)
        matched_entries = reviewed_directory.matching_entries(self.store.project, repo, path, subtree)
        if matched_entries:
            source["curatedScopeIds"] = [item["id"] for item in matched_entries]
        matched = next((item for item in matched_entries if reviewed_directory.source_directory(item["source"]) == path), None)
        source["licenseScope"] = "repository_metadata_only"
        if matched:
            source["curatedId"] = matched["id"]
            source["reviewedName"] = matched["name"]
            source["reviewedCommit"] = matched["source"]["ref"]
            source["reviewedBlobSha"] = matched["source"]["blobSha"]
            source["entryBlobSha"] = reviewed_directory.git_blob_sha(subtree["SKILL.md"]) if "SKILL.md" in subtree else None
            source["reviewedPinMatched"] = commit == source["reviewedCommit"] and source["entryBlobSha"] == source["reviewedBlobSha"]
            if source["reviewedPinMatched"]:
                source["repositoryLicense"] = source["license"]
                source["licenseEvidence"] = {"commit": commit, "entryPath": matched["source"]["path"], "evidence": matched.get("license", {})}
                license_record = matched.get("license", {})
                source["license"] = license_record.get("applicable_license") or license_record.get("spdx")
                source["licenseScope"] = "reviewed_entry_at_selected_commit"
        with self._locked():
            # Re-read the managed identity after the remote request; previews bind current data.
            if record:
                record = self._record(record["managedId"])
            provenance_files = {}
            for key, raw in files.items():
                if "/" not in key and (key.upper().startswith(("LICENSE", "COPYING", "NOTICE"))):
                    provenance_files[_path(key)] = raw
            evidence_path = reviewed_directory.license_evidence_path(source)
            if isinstance(evidence_path, str) and evidence_path in files:
                provenance_files["evidence/" + _path(evidence_path)] = files[evidence_path]
            return self._prepare(subtree, source, operation, record, provenance_files=provenance_files)

    def preflight(self, payload):
        if not isinstance(payload, dict):
            raise EditorError("Select a prepared candidate for deployment checks.")
        with self._locked():
            preview, files = self._preview(payload)
            return {"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "deployment": reviewed_directory.deployment(self.store.project, preview, files)}

    def _preview(self, payload, operation=None):
        candidate_id = payload.get("candidateId")
        if not isinstance(candidate_id, str) or not IDENTIFIER.fullmatch(candidate_id):
            raise EditorError("Select a prepared candidate.")
        candidate = _internal(self.candidates / candidate_id)
        preview = _read_json(candidate / "preview.json", limit=MAX_PREVIEW)
        if not isinstance(preview, dict):
            raise EditorError("Prepared candidate not found.", 404)
        selected_sha = payload.get("previewSha")
        without_sha = {key: value for key, value in preview.items() if key != "previewSha"}
        if selected_sha != preview.get("previewSha") or selected_sha != _digest(_canonical(without_sha)):
            raise EditorError("The selected preview changed. Inspect a fresh version.", 409)
        if preview.get("candidateId") != candidate_id or operation and preview.get("operation") != operation:
            raise EditorError("The selected preview does not match this action.", 409)
        if preview.get("targetPath") != str(self._target(preview.get("name"))):
            raise EditorError("The installation target changed. Inspect a fresh version for this Agent.", 409)
        files = self._tree(candidate / "tree")
        if self._files(files) != preview.get("files") or self._tree_sha(files) != preview.get("treeSha"):
            raise EditorError("Staged candidate files changed. Inspect a fresh version.", 409)
        source = preview.get("source", {})
        if source.get("kind") == "local" and preview.get("operation") != "rollback":
            try:
                _, current_source = self._local_snapshot(source.get("skillId"), source)
            except EditorError:
                raise EditorError("The selected personal library source changed or is unavailable. Inspect a fresh version; existing files were preserved.", 409) from None
            if current_source != source:
                raise EditorError("The selected personal library source changed after preview. Inspect a fresh version; existing files were preserved.", 409)
        provenance = preview.get("source", {}).get("provenance")
        if provenance is not None:
            if not isinstance(provenance, dict) or not isinstance(provenance.get("candidateId"), str) or not IDENTIFIER.fullmatch(provenance["candidateId"]) or not isinstance(provenance.get("files"), list):
                raise EditorError("Selected provenance metadata is invalid; no files were installed.", 409)
            evidence_root = _internal(self.candidates / provenance["candidateId"] / "provenance")
            try:
                evidence_files = self._tree(evidence_root)
            except OSError:
                raise EditorError("Preserved source/license provenance is unavailable; inspect a fresh version.", 409) from None
            evidence_files.pop("source.json", None)
            if self._files(evidence_files) != provenance["files"] or _read_json(evidence_root / "source.json") != preview["source"]:
                raise EditorError("Selected source/license provenance changed; inspect a fresh version.", 409)
        return preview, files

    def _backup_path(self, version):
        identifier = version.get("versionId")
        if not isinstance(identifier, str) or not IDENTIFIER.fullmatch(identifier):
            raise EditorError("Invalid backup version.", 409)
        return _internal(self.backups / identifier)

    def _version(self, record, version_id):
        for version in record.get("versions", []):
            if version.get("versionId") == version_id:
                self._backup_path(version)
                return version
        raise EditorError("Selected backup version was not found.", 404)

    def _backup(self, files, source, upstream_sha=None):
        version = {"versionId": uuid.uuid4().hex, "sha": self._tree_sha(files), "source": source, "createdAt": _now(), "locallyModified": self._tree_sha(files) != upstream_sha if upstream_sha else None}
        path = self._backup_path(version)
        path.mkdir(mode=0o700)
        self._write_tree(path / "tree", files)
        _write(path / "version.json", _canonical(version))
        return version

    def _sync(self):
        try:
            refreshed = self.store.refresh_inventory()
            scope = refreshed.get("scope", {}) if isinstance(refreshed, dict) else {}
            warnings = refreshed.get("scanWarnings", refreshed.get("warnings", [])) if isinstance(refreshed, dict) else []
            return {"ok": not bool(warnings), "warnings": warnings, "message": "Disk inventory refreshed; session activation is unchanged." if not warnings else "Disk inventory refreshed with warnings; review unavailable roots.", "scope": scope}
        except Exception:
            # A completed write must not be reported as rolled back because indexing failed.
            return {"ok": False, "message": "Skill files were written, but inventory refresh failed. Retry synchronization before relying on the index."}

    def _adopt(self, preview, files, baseline):
        if self.recovery_warnings:
            raise EditorError("An interrupted catalog transaction needs review before another write.", 409)
        name = preview["name"]
        target = self._target(name)
        root = _internal(self.install_root)
        _mkdir_internal(root)
        _internal(root)
        managed = self._managed()
        operation = preview["operation"]
        record = None
        if operation != "install":
            record = self._record(preview["managedId"])
            if not isinstance(baseline, str) or baseline != preview.get("baselineSha"):
                raise EditorError("The current-tree SHA must match the selected preview.", 409)
            if operation == "rollback":
                version = self._version(record, preview.get("versionId"))
                if version["sha"] != preview["treeSha"]:
                    raise EditorError("Selected backup no longer matches this preview.", 409)
        elif target.exists() or any(item.get("name") == name for item in managed["installs"].values()):
            raise EditorError("This personal skill name already exists. No files were replaced.", 409)
        committed_history = self._committed_transactions(record) if record else []
        transaction = _internal(self.transactions / uuid.uuid4().hex)
        transaction.mkdir(mode=0o700)
        stage_name, hold_name = "stage", "current"
        stage = transaction / stage_name
        hold = transaction / hold_name
        self._write_tree(stage, files)
        managed_id = record["managedId"] if record else uuid.uuid4().hex
        journal = {"name": name, "managedId": managed_id, "operation": operation, "baselineSha": baseline, "expectedSha": preview["treeSha"], "stagedIdentity": _identity(stage.stat()), "status": "prepared"}
        _write(transaction / "transaction.json", _canonical(journal))
        # Opening root one component at a time prevents ancestor symlink substitution.
        root_fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        moved = False
        adopted = False
        reserved = False
        backup = None
        transaction_fd = None
        try:
            for part in root.parts[1:]:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root_fd)
                os.close(root_fd)
                root_fd = child
            transaction_fd = os.open(transaction, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            if os.fstat(transaction_fd).st_dev != os.fstat(root_fd).st_dev:
                raise EditorError("Atomic installation requires state and personal skills on the same internal filesystem.", 409)
            if operation != "install":
                # Capture the actual current directory before checking all resource hashes.
                os.rename(name, hold_name, src_dir_fd=root_fd, dst_dir_fd=transaction_fd)
                moved = True
                current = self._tree(hold)
                if self._tree_sha(current) != baseline:
                    raise EditorError("Installed files changed after preview. The current directory was preserved.", 409)
                backup = self._backup(current, record["source"], record["currentSha"])
                if self._tree_sha(self._tree(hold)) != baseline:
                    raise EditorError("Installed files changed during backup. Inspect a fresh preview.", 409)
            else:
                # Reserve the destination atomically; a concurrent same-name writer wins safely.
                os.mkdir(name, mode=0o700, dir_fd=root_fd)
                reserved = True
                journal["reservation"] = _identity(os.stat(name, dir_fd=root_fd, follow_symlinks=False))
                _write(transaction / "transaction.json", _canonical(journal))
            os.rename(stage_name, name, src_dir_fd=transaction_fd, dst_dir_fd=root_fd)
            adopted = True
            next_record = {"managedId": managed_id, "name": name, "targetPath": str(target), "source": preview["source"], "currentSha": preview["treeSha"], "createdAt": record["createdAt"] if record else _now(), "updatedAt": _now(), "versions": [*record.get("versions", []), backup] if record else [], "transactionId": transaction.name, "committedTransactionIds": [*committed_history, transaction.name]}
            managed["installs"][managed_id] = next_record
            self._save_managed(managed)
        except Exception as error:
            # Keep every old/new directory on an interrupted transaction; never delete a unique tree.
            try:
                if adopted:
                    os.rename(name, "uncommitted", src_dir_fd=root_fd, dst_dir_fd=transaction_fd)
                if moved:
                    os.rename(hold_name, name, src_dir_fd=transaction_fd, dst_dir_fd=root_fd)
                elif reserved and not adopted:
                    self._preserve_recovery_directory(target, transaction / ("reservation-recovered-" + uuid.uuid4().hex), journal.get("reservation"), empty=True)
                _write(transaction / "transaction.json", _canonical({**journal, "status": "recovered"}))
            except (OSError, EditorError):
                self.recovery_warnings.append({"transactionId": transaction.name, "message": "Interrupted transaction needs review. All captured, staged and current copies were preserved; catalog writes are blocked until it is resolved."})
                raise EditorError("Transaction recovery needs attention. Preserved current/staged directories remain in catalog transaction state; no backup was deleted.", 500) from None
            if isinstance(error, EditorError):
                raise
            raise EditorError("Installation transaction failed; prior files and recovery copies were preserved.", 500) from None
        finally:
            os.close(root_fd)
            if transaction_fd is not None:
                os.close(transaction_fd)
        # Commit history is immutable across later versions, so an old pending
        # journal can never be mistaken for an uncommitted later installation.
        journal_synced = True
        try:
            _write(transaction / "transaction.json", _canonical({**journal, "status": "committed"}))
        except (OSError, EditorError):
            journal_synced = False
            self.journal_warnings.append({"transactionId": transaction.name, "message": "Installation is durably committed in manifest history, but transaction journal finalization remains pending."})
        if moved:
            # The full prior tree is already present and verified in the permanent backup.
            # Keep the captured tree as an additional recovery copy instead of risking a deletion race.
            recovery = self.backups / backup["versionId"] / "captured"
            try:
                os.rename(hold, recovery)
            except OSError:
                pass
        return {"installed": True, "operation": operation, "managedId": managed_id, "name": name, "targetPath": str(target), "currentSha": preview["treeSha"], "source": preview["source"], "backupVersionId": backup["versionId"] if backup else None, "transaction": {"id": transaction.name, "committed": True, "journalSynced": journal_synced}, "warnings": [] if journal_synced else ["Installation committed successfully; transaction journal finalization is pending. Immutable manifest history preserves the commit evidence."], "sync": self._sync()}

    def install(self, payload):
        if not isinstance(payload, dict):
            raise EditorError("Select a prepared installation.")
        with self._locked():
            preview, files = self._preview(payload)
            if preview["operation"] not in ("install", "update"):
                raise EditorError("Use the rollback action for a restore preview.")
            deployment = reviewed_directory.deployment(self.store.project, preview, files)
            if not deployment["installAllowed"]:
                raise EditorError("Installation is blocked: " + " ".join(deployment["blockers"]), 409)
            result = self._adopt(preview, files, payload.get("baselineSha"))
            result["deployment"] = {**deployment, "status": "installed_unverified", "installAllowed": False, "nextAction": "Files were installed. Verify host discovery, prepare the authorized execution environment and run a separately authorized task check."}
            return result

    def rollback(self, payload):
        if not isinstance(payload, dict):
            raise EditorError("Select a prepared rollback.")
        with self._locked():
            preview, files = self._preview(payload, "rollback")
            if payload.get("managedId") != preview["managedId"] or payload.get("versionId") != preview["versionId"]:
                raise EditorError("The selected rollback does not match this preview.", 409)
            result = self._adopt(preview, files, payload.get("baselineSha"))
            result["deployment"] = reviewed_directory.deployment(self.store.project, preview, files, installed=True)
            return result

    def updates(self):
        with self._locked():
            records = list(self._managed()["installs"].values())
        installs = []
        warnings = []
        for saved in records:
            with self._locked():
                record = self._record(saved["managedId"])
                item = {key: record[key] for key in ("managedId", "name", "targetPath", "source", "currentSha", "versions", "updatedAt")}
                local = record["source"].get("kind") == "local"
                item.update({"currentCommit": None if local else record["source"]["commit"], "latestCommit": None, "currentRevision": record["source"]["revision"] if local else record["source"]["commit"], "latestRevision": None, "hasUpdate": None, "locallyModified": None, "baselineSha": None, "status": "unverified"})
                try:
                    current = self._tree(self._target(record["name"]))
                    item["baselineSha"] = self._tree_sha(current)
                    item["locallyModified"] = item["baselineSha"] != record["currentSha"]
                except (OSError, EditorError):
                    item["status"] = "unavailable"
                    item["warning"] = "Managed directory is missing, unsafe, or unreadable; no update may be applied."
            try:
                source = record["source"]
                if local:
                    with self._locked():
                        _, latest_source = self._local_snapshot(source.get("skillId"), source)
                    latest = latest_source["revision"]
                    item["hasUpdate"] = latest != source["revision"]
                else:
                    latest = self._api("/repos/" + source["repo"] + "/commits/" + urllib.parse.quote(source.get("trackingRef") or source["ref"], safe="")).get("sha")
                    if not isinstance(latest, str) or not SHA.fullmatch(latest):
                        raise EditorError("GitHub returned an invalid source revision.", 502)
                    item["latestCommit"] = latest
                    item["hasUpdate"] = latest != source["commit"]
                item["latestRevision"] = latest
                if item["status"] != "unavailable":
                    item["status"] = "update_available" if item["hasUpdate"] else "current"
            except EditorError:
                if local:
                    item["status"] = "unavailable"
                    item["warning"] = "The original personal library source is missing, unsafe, or no longer editable. Installed files and rollback backups were preserved."
                else:
                    item["warning"] = "Update source could not be checked. Installed files were preserved."
                warnings.append({"managedId": record["managedId"], "message": item["warning"]})
            installs.append(item)
        return {"installs": installs, "warnings": warnings, "checkedAt": _now()}
