"""Bounded, read-only evidence about local agent directories and CLI candidates.

No host command is invoked, no configuration or skill text is read, and no
inventory is consulted or refreshed. Directory visibility does not establish
installation, authentication, skill loading, connection, or runtime readiness.
Only target() selects a future install path; the catalog transaction must check
that path again immediately before writing.
"""
from __future__ import annotations

from datetime import datetime, timezone
import os
from pathlib import Path
import stat

from .core import EditorError


MAX_SKILL_ENTRIES = 2000
SYSTEM_BINARY_DIRS = (Path("/usr/local/bin"), Path("/opt/homebrew/bin"))

# Paths are an explicit allowlist, not a PATH search or a scan of the home tree.
# Documentation is descriptive evidence only. Installed versions and settings
# are intentionally not read, so even documented paths have unverified loading.
_SPECS = (
    {
        "id": "codex", "name": "Codex", "configuration": ".codex",
        "commands": ("codex",), "extraBinaries": (),
        "target": ".agents/skills", "targetShared": True,
        "sourceUrl": "https://learn.chatgpt.com/docs/build-skills",
        "roots": (
            (".codex/skills", "native", False, "unverified"),
            (".agents/skills", "shared", True, "documented"),
        ),
    },
    {
        "id": "claude-code", "name": "Claude Code", "configuration": ".claude",
        "commands": ("claude",), "extraBinaries": (),
        "target": ".claude/skills", "targetShared": False,
        "sourceUrl": "https://code.claude.com/docs/en/skills",
        "roots": ((".claude/skills", "native", False, "documented"),),
    },
    {
        "id": "cursor", "name": "Cursor", "configuration": ".cursor",
        "commands": ("cursor-agent", "cursor"), "extraBinaries": (),
        "target": ".cursor/skills", "targetShared": False,
        "sourceUrl": "https://cursor.com/help/customization/skills",
        "roots": (
            (".cursor/skills", "native", False, "documented"),
            (".agents/skills", "shared", True, "documented"),
            (".claude/skills", "compatibility", False, "documented"),
            (".codex/skills", "compatibility", False, "documented"),
        ),
    },
    {
        "id": "opencode", "name": "OpenCode", "configuration": ".config/opencode",
        "commands": ("opencode",), "extraBinaries": (".opencode/bin/opencode",),
        "target": ".config/opencode/skills", "targetShared": False,
        "sourceUrl": "https://opencode.ai/docs/skills/",
        "roots": (
            (".config/opencode/skills", "native", False, "documented"),
            (".agents/skills", "shared", True, "documented"),
            (".claude/skills", "compatibility", False, "documented"),
        ),
    },
)
_DIRECTORY_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
_UNAVAILABLE = {"symlink_skipped", "external_skipped", "unavailable", "not_directory"}
_MESSAGES = {
    "present": "目录可见；未读取配置、验证连接或运行状态。",
    "missing": "白名单位置不存在；未创建目录。",
    "symlink_skipped": "符号链接或含链接的路径已跳过，未跟随目标。",
    "external_skipped": "外置盘路径已跳过。",
    "unavailable": "目录访问失败；状态和数量未验证。",
    "not_directory": "该路径或上级路径不是目录。",
    "not_executable": "候选路径不是带执行位的常规文件。",
    "limit_reached": "达到本次快照的检查上限；数量仅为已确认下限。",
}


class _ProbeError(Exception):
    def __init__(self, status, *, exists=None, error=None):
        self.status = status
        self.exists = exists
        self.error = error
        super().__init__(_MESSAGES[status])


def _error_text(exc):
    # Do not surface raw exception arguments, environment values or file text.
    return type(exc).__name__ + (": " + exc.strerror if getattr(exc, "strerror", None) else ": filesystem access failed")


def _check_path(path):
    if not path.is_absolute() or ".." in path.parts:
        raise _ProbeError("unavailable", error="Absolute physical paths without traversal are required.")
    if path == Path("/Volumes") or Path("/Volumes") in path.parents:
        raise _ProbeError("external_skipped")


def _open_directory(path):
    """Open every ancestor relative to a physical descriptor, without links."""
    _check_path(path)
    descriptor = None
    try:
        descriptor = os.open("/", _DIRECTORY_FLAGS)
        for name in path.parts[1:]:
            info = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                raise _ProbeError("symlink_skipped")
            if not stat.S_ISDIR(info.st_mode):
                raise _ProbeError("not_directory")
            child = os.open(name, _DIRECTORY_FLAGS, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        result = descriptor
        descriptor = None
        return result
    except FileNotFoundError:
        raise _ProbeError("missing", exists=False) from None
    except OSError as exc:
        raise _ProbeError("unavailable", error=_error_text(exc)) from None
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _failure(path, exc):
    result = {"path": str(path), "status": exc.status, "exists": exc.exists,
              "message": _MESSAGES[exc.status]}
    if exc.error:
        result["error"] = exc.error
    return result


def _directory_probe(path):
    try:
        descriptor = _open_directory(path)
    except _ProbeError as exc:
        return _failure(path, exc)
    os.close(descriptor)
    return {"path": str(path), "status": "present", "exists": True,
            "message": _MESSAGES["present"]}


def _executable_probe(path):
    descriptor = None
    try:
        _check_path(path)
        descriptor = _open_directory(path.parent)
        info = os.stat(path.name, dir_fd=descriptor, follow_symlinks=False)
        if stat.S_ISLNK(info.st_mode):
            raise _ProbeError("symlink_skipped", exists=True)
        executable = stat.S_ISREG(info.st_mode) and bool(info.st_mode & 0o111)
        return {"path": str(path), "status": "present" if executable else "not_executable",
                "exists": True,
                "message": "发现带执行位的常规候选文件；未执行或验证其身份、版本及可运行性。" if executable else _MESSAGES["not_executable"]}
    except FileNotFoundError:
        return _failure(path, _ProbeError("missing", exists=False))
    except _ProbeError as exc:
        return _failure(path, exc)
    except OSError as exc:
        return _failure(path, _ProbeError("unavailable", error=_error_text(exc)))
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _scan_skills(path, budget):
    """Count only <root>/<non-hidden-directory>/SKILL.md metadata, never bytes."""
    result = {"path": str(path), "exists": None, "count": None,
              "countComplete": False, "inspectedEntries": 0,
              "warnings": [], "loadingStatus": "unverified",
              "countMethod": "direct_skill_directories"}
    try:
        descriptor = _open_directory(path)
    except _ProbeError as exc:
        result.update(_failure(path, exc))
        return result

    result.update({"exists": True, "status": "present", "message": "仅统计直接子目录内的常规 SKILL.md；未读取内容或验证宿主加载。"})
    count = 0
    complete = True
    started = False

    def warn(item_path, status, error=None):
        nonlocal complete
        complete = False
        warning = {"path": str(item_path), "status": status, "message": _MESSAGES[status]}
        if error:
            warning["error"] = error
        result["warnings"].append(warning)

    try:
        if budget["remaining"] <= 0:
            result.update({"status": "limit_reached", "message": _MESSAGES["limit_reached"]})
            return result
        with os.scandir(descriptor) as iterator:
            started = True
            while budget["remaining"] > 0:
                try:
                    entry = next(iterator)
                except StopIteration:
                    break
                budget["remaining"] -= 1
                budget["inspected"] += 1
                result["inspectedEntries"] += 1
                # Hidden/system/editor state is outside the personal count.
                if entry.name.startswith("."):
                    continue
                child_path = path / entry.name
                child = None
                try:
                    info = os.stat(entry.name, dir_fd=descriptor, follow_symlinks=False)
                    if stat.S_ISLNK(info.st_mode):
                        warn(child_path, "symlink_skipped")
                        continue
                    if not stat.S_ISDIR(info.st_mode):
                        continue
                    child = os.open(entry.name, _DIRECTORY_FLAGS, dir_fd=descriptor)
                    try:
                        skill_info = os.stat("SKILL.md", dir_fd=child, follow_symlinks=False)
                    except FileNotFoundError:
                        continue
                    if stat.S_ISLNK(skill_info.st_mode):
                        warn(child_path / "SKILL.md", "symlink_skipped")
                    elif stat.S_ISREG(skill_info.st_mode):
                        count += 1
                except OSError as exc:
                    warn(child_path, "unavailable", _error_text(exc))
                finally:
                    if child is not None:
                        os.close(child)
            else:
                # Do not consume one extra entry merely to establish exhaustion.
                complete = False
                result.update({"status": "limit_reached", "message": _MESSAGES["limit_reached"]})
        result["count"] = count
        result["countComplete"] = complete
    except OSError as exc:
        result.update({"status": "unavailable", "message": _MESSAGES["unavailable"], "error": _error_text(exc)})
        result["count"] = count if started and result["inspectedEntries"] else None
    finally:
        os.close(descriptor)
    return result


class AgentService:
    """Fresh filesystem evidence limited to explicit local paths.

    home injection exists for isolated fixtures. The HTTP layer must never pass
    an arbitrary request path as home or a skill root.
    """
    def __init__(self, store, home=None):
        self.store = store
        self.home = Path(home if home is not None else Path.home()).absolute()

    def _spec(self, agent_id):
        if isinstance(agent_id, str):
            for spec in _SPECS:
                if spec["id"] == agent_id:
                    return spec
        raise EditorError("Select a supported local agent id.")

    def target(self, agent_id):
        """Return one allowlisted physical target; do not create or write it."""
        spec = self._spec(agent_id)
        target = self.home / spec["target"]
        probe = _directory_probe(target)
        if probe["status"] not in {"present", "missing"}:
            raise EditorError("Agent target is unavailable: " + probe["message"], 403)
        return target

    def _installation(self, spec):
        path = self.home / spec["target"]
        probe = _directory_probe(path)
        available = probe["status"] in {"present", "missing"}
        if available:
            reason = "固定目标路径的现有组件通过检查；安装事务提交时会再次检查。尚未验证实际写入、连接或运行。"
            if spec["targetShared"]:
                reason += "此共享目录也可能被其他兼容 Agent 读取。"
        else:
            reason = probe["message"]
        result = {"agentId": spec["id"], "targetPath": str(path),
                  "shared": spec["targetShared"], "available": available,
                  "reason": reason, "validation": "path_only"}
        if "error" in probe:
            result["error"] = probe["error"]
        return result

    def snapshot(self):
        budget = {"remaining": MAX_SKILL_ENTRIES, "inspected": 0}
        scans = {}

        def root(path, *, scope="user", relationship="native", shared=False,
                 support="documented", source=None):
            key = str(path)
            if key not in scans:
                scans[key] = _scan_skills(path, budget)
            return {**scans[key], "scope": scope, "shared": shared,
                    "relationship": relationship, "supportStatus": support,
                    "sourceUrl": source}

        library_path = Path(self.store.personal_root).absolute()
        library_root = root(library_path, scope="editor", relationship="editor_library", support="unverified")
        agents = []
        for spec in _SPECS:
            candidates = [self.home / ".local/bin" / command for command in spec["commands"]]
            candidates.extend(directory / command for directory in SYSTEM_BINARY_DIRS for command in spec["commands"])
            candidates.extend(self.home / relative for relative in spec["extraBinaries"])
            evidence = [{"kind": "executable", **_executable_probe(path)} for path in dict.fromkeys(candidates)]
            configuration = {"kind": "configuration_directory", **_directory_probe(self.home / spec["configuration"])}
            evidence.append(configuration)
            executable_detected = any(item["kind"] == "executable" and item["status"] == "present" for item in evidence)
            configuration_detected = configuration["status"] == "present"
            detected = executable_detected or configuration_detected
            detection_complete = all(item["status"] not in _UNAVAILABLE for item in evidence)
            roots = [root(self.home / relative, relationship=relationship, shared=shared,
                          support=support, source=spec["sourceUrl"] if support == "documented" else None)
                     for relative, relationship, shared, support in spec["roots"]]
            counts = [item["count"] for item in roots if item["count"] is not None]
            agents.append({
                "id": spec["id"], "name": spec["name"], "detected": detected,
                "executableDetected": executable_detected,
                "configurationDetected": configuration_detected,
                "detectionComplete": detection_complete,
                "status": "detected" if detected else "not_detected" if detection_complete else "unavailable",
                "skillCount": sum(counts) if counts else None,
                "countComplete": all(item["countComplete"] for item in roots),
                "roots": roots, "evidence": evidence,
                "runtimeStatus": "unverified", "connectionStatus": "unverified",
                "loadingStatus": "unverified", "sourceUrl": spec["sourceUrl"],
                "installation": self._installation(spec),
                "notice": "检测到仅表示候选文件或配置目录可见；技能数量是直接目录计数，不能证明已加载或可运行。",
            })
        return {
            "schemaVersion": 1, "checkedAt": datetime.now(timezone.utc).isoformat(),
            "agents": agents,
            "library": {"path": str(library_path), "personalCount": library_root["count"],
                        "countComplete": library_root["countComplete"], "roots": [library_root],
                        "countMethod": "direct_skill_directories"},
            "limits": {"maxSkillEntries": MAX_SKILL_ENTRIES,
                       "inspectedSkillEntries": budget["inspected"],
                       "directChildrenOnly": True, "followsSymlinks": False},
            "notice": "仅检查白名单本机路径的目录与文件元数据；不读取账户凭据、配置或技能正文，不执行 CLI，不验证连接、权限设置或技能加载。",
        }
