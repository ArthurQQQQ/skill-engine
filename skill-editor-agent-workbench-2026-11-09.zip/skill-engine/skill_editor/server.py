"""Run with python3 -m skill_editor.server --port 8765."""
from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
from pathlib import Path
import signal
import threading
import urllib.parse

from . import ai, case_ai
from .cases import CaseStore
from .core import EditorError, SkillStore
from .tasks import EngineStore
from .catalog import CatalogService
from .executor import Executor
from .agents import AgentService


def make_handler(store: SkillStore):
    cases = CaseStore(store)
    engine_services = {}
    agent_catalogs = {}
    local_agents = AgentService(store)
    service_lock = threading.RLock()
    service_stopping = threading.Event()

    def services():
        # Existing read/maintenance endpoints stay lazy and never trigger a scan.
        with service_lock:
            if service_stopping.is_set():
                raise EditorError("服务正在关闭，请重新连接后再试。", 503)
            if not engine_services:
                engine = EngineStore(store, auto_sync=True)
                engine_services.update(engine=engine, catalog=CatalogService(store), executor=Executor(engine))
            return engine_services

    def target_catalog(agent_id=None):
        if agent_id is None or agent_id == "":
            return services()["catalog"]
        if not isinstance(agent_id, str):
            raise EditorError("Select a known Agent.")
        target = local_agents.target(agent_id)
        with service_lock:
            if service_stopping.is_set():
                raise EditorError("服务正在关闭，请重新连接后再试。", 503)
            if agent_id not in agent_catalogs:
                agent_catalogs[agent_id] = CatalogService(store, target_root=target, state_namespace=agent_id)
            return agent_catalogs[agent_id]

    def target_result(result, agent_id=None):
        if agent_id:
            target = agent_catalogs[agent_id].install_root
            result["target"] = {"agentId": agent_id, "path": str(target),
                                "shared": agent_id == "codex", "runtimeStatus": "unverified",
                                "recoveryWarnings": list(agent_catalogs[agent_id].recovery_warnings),
                                "journalWarnings": list(agent_catalogs[agent_id].journal_warnings)}
            if isinstance(result.get("sync"), dict):
                result["sync"]["scope"] = {**result["sync"].get("scope", {}),
                    "inventoryRoot": str(store.personal_root), "targetIncluded": target == store.personal_root}
        return result

    class Handler(BaseHTTPRequestHandler):
        server_version = "SkillEditor/0.1"

        def log_message(self, format, *args):
            # No request payloads, API tokens, or provider responses are logged.
            pass

        def _check_origin(self):
            port = self.server.server_address[1]
            allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
            if self.headers.get("Host") not in allowed_hosts:
                raise EditorError("Loopback Host required.", 403)
            origin = self.headers.get("Origin")
            if origin and origin not in {"http://" + host for host in allowed_hosts}:
                raise EditorError("Cross-origin access denied.", 403)

        def _reply(self, status, payload, content_type="application/json; charset=utf-8"):
            raw = json.dumps(payload, ensure_ascii=False).encode("utf-8") if content_type.startswith("application/json") else payload
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            self.wfile.write(raw)

        def _payload(self):
            if self.headers.get("Content-Type", "").split(";", 1)[0] != "application/json":
                raise EditorError("Use application/json.", 415)
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                raise EditorError("Invalid content length.")
            if length <= 0 or length > 250_000:
                raise EditorError("Request body must be between 1 and 250000 bytes.", 413)
            try:
                payload = json.loads(self.rfile.read(length))
            except (ValueError, UnicodeError):
                raise EditorError("Request body must be JSON.")
            if not isinstance(payload, dict):
                raise EditorError("Request body must be an object.")
            return payload

        def _dispatch(self):
            try:
                self._check_origin()
                url = urllib.parse.urlsplit(self.path)
                path = url.path
                query = urllib.parse.parse_qs(url.query)
                if self.command == "GET":
                    if path == "/api/agents":
                        return self._reply(200, local_agents.snapshot())
                    if path == "/api/engine/config":
                        current = services()
                        planner = current["engine"].config()
                        return self._reply(200, {"planner": planner,
                            "plannerConfigured": planner.get("semanticPlannerAvailable", False),
                            "executor": current["executor"].config(), "catalog": current["catalog"].config(),
                            "automaticSync": True, "automaticInstall": False})
                    if path == "/api/tasks":
                        return self._reply(200, services()["engine"].list())
                    if path == "/api/task":
                        return self._reply(200, services()["engine"].read(query.get("id", [""])[0]))
                    if path == "/api/task/events":
                        try:
                            after = int(query.get("after", ["0"])[0])
                        except ValueError:
                            raise EditorError("事件位置必须是整数。") from None
                        return self._reply(200, services()["engine"].events(query.get("id", [""])[0], after))
                    if path == "/api/task/artifact":
                        return self._reply(200, services()["executor"].artifact(query.get("id", [""])[0], query.get("name", [""])[0]))
                    if path == "/api/catalog":
                        return self._reply(200, services()["catalog"].search(query.get("q", [""])[0], source=query.get("source", ["github"])[0], sort=query.get("sort", ["stars"])[0]))
                    if path == "/api/catalog/curated":
                        return self._reply(200, services()["catalog"].curated(query.get("q", [""])[0], category=query.get("category", [""])[0], use_case=query.get("use", [""])[0]))
                    if path == "/api/catalog/updates":
                        agent_id = query.get("agentId", [None])[0]
                        return self._reply(200, target_result(target_catalog(agent_id).updates(), agent_id))
                    if path == "/api/config":
                        return self._reply(200, ai.config())
                    if path == "/api/health":
                        return self._reply(200, {"ok": True, "version": "0.1.0"})
                    if path == "/api/inventory":
                        return self._reply(200, store.inventory())
                    if path == "/api/cases":
                        return self._reply(200, cases.list())
                    if path == "/api/case":
                        return self._reply(200, cases.read(query.get("id", [""])[0]))
                    if path == "/api/skill":
                        return self._reply(200, store.read(query.get("id", [""])[0]))
                    if path == "/api/intent":
                        identifier = query.get("id", [""])[0]
                        return self._reply(200, {"id": identifier, "markdown": store.intent(identifier)})
                    if path.startswith("/api/"):
                        raise EditorError("Unknown endpoint.", 404)
                    if path == "/maintenance/":
                        # Keep the old page's relative assets rooted at /.
                        self.send_response(308)
                        self.send_header("Location", "/maintenance")
                        self.send_header("Content-Length", "0")
                        self.send_header("Cache-Control", "no-store")
                        self.end_headers()
                        return
                    web = (store.project / "web").resolve()
                    if path in {"/maintenance", "/maintenance/"}:
                        relative = "index.html"
                    elif path in {"/", "/index.html"} and (web / "flow-lab/index.html").is_file():
                        relative = "flow-lab/index.html"
                    else:
                        relative = urllib.parse.unquote(path).lstrip("/") or "index.html"
                    target = (web / relative).resolve()
                    if web not in target.parents or not target.is_file():
                        raise EditorError("File not found.", 404)
                    return self._reply(200, target.read_bytes(), mimetypes.guess_type(target.name)[0] or "application/octet-stream")
                payload = self._payload()
                if self.command == "PUT" and path == "/api/intent":
                    return self._reply(200, store.save_intent(payload.get("id"), payload.get("markdown")))
                if self.command == "PUT" and path == "/api/case":
                    return self._reply(200, cases.update(query.get("id", [""])[0], payload.get("patch"), payload.get("baselineSha")))
                if self.command == "POST":
                    if path == "/api/tasks":
                        return self._reply(201, services()["engine"].create(payload))
                    if path == "/api/task/plan":
                        return self._reply(200, services()["engine"].plan(payload))
                    if path == "/api/task/feedback":
                        return self._reply(200, services()["engine"].feedback(payload))
                    if path == "/api/task/handoff":
                        return self._reply(200, services()["engine"].handoff(payload))
                    if path == "/api/task/run":
                        return self._reply(202, services()["executor"].start(payload))
                    if path == "/api/task/cancel":
                        return self._reply(200, services()["executor"].cancel(payload))
                    if path == "/api/engine/sync":
                        return self._reply(200, store.refresh_inventory())
                    if path == "/api/catalog/local/inspect":
                        agent_id = payload.get("agentId")
                        if not isinstance(agent_id, str) or not agent_id:
                            raise EditorError("先选择要采用个人 Skill 的目标 Agent。")
                        return self._reply(200, target_result(target_catalog(agent_id).inspect_local(payload), agent_id))
                    if path == "/api/catalog/inspect":
                        agent_id = payload.get("agentId")
                        return self._reply(200, target_result(target_catalog(agent_id).inspect(payload), agent_id))
                    if path == "/api/catalog/preflight":
                        agent_id = payload.get("agentId")
                        return self._reply(200, target_result(target_catalog(agent_id).preflight(payload), agent_id))
                    if path in {"/api/catalog/install", "/api/catalog/rollback"}:
                        agent_id = payload.get("agentId")
                        catalog = target_catalog(agent_id)
                        action = catalog.install if path.endswith("install") else catalog.rollback
                        result = target_result(action(payload), agent_id)
                        if payload.get("taskId") and not agent_id:
                            current = services()
                            try:
                                task = current["engine"].read(payload["taskId"])
                                result["task"] = current["engine"].plan({"taskId": task["id"], "baselineSha": task["sha"]})
                            except EditorError as exc:
                                result["taskRefresh"] = {"ok": False, "error": str(exc)}
                        elif payload.get("taskId"):
                            result["taskRefresh"] = {"ok": False, "error": "文件已采用至所选 Agent 目录；当前任务执行环境尚未与该宿主关联。"}
                        return self._reply(200, result)
                    if path == "/api/cases":
                        return self._reply(201, cases.create(payload))
                    if path == "/api/case/preview":
                        return self._reply(200, cases.preview(payload.get("caseId"), payload.get("skillId"), payload.get("baselineSha")))
                    if path == "/api/case/generate":
                        return self._reply(200, case_ai.generate(cases, payload))
                    if path == "/api/case/predict":
                        return self._reply(200, case_ai.predict(cases, payload))
                    if path == "/api/inventory/refresh":
                        return self._reply(200, store.refresh_inventory())
                    if path == "/api/preview":
                        return self._reply(200, store.preview(payload.get("id"), payload.get("description"), payload.get("baselineSha")))
                    if path == "/api/apply":
                        return self._reply(200, store.apply_description(payload.get("id"), payload.get("description"), payload.get("baselineSha")))
                    if path == "/api/analyze":
                        return self._reply(200, ai.analyze(store, payload))
                raise EditorError("Unknown endpoint or method.", 404)
            except EditorError as exc:
                self._reply(exc.status, {"error": str(exc)})
            except (OSError, UnicodeError):
                self._reply(500, {"error": "A filesystem operation failed. Check paths and permissions."})
            except Exception:
                self._reply(500, {"error": "The operation failed. No diagnostic secrets are returned."})

        do_GET = _dispatch
        do_POST = _dispatch
        do_PUT = _dispatch

        @staticmethod
        def shutdown_engine():
            with service_lock:
                service_stopping.set()
                executor = engine_services.get("executor")
            if executor:
                executor.close()

    return Handler


def main():
    parser = argparse.ArgumentParser(description="Local Skill Editor")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parent.parent)
    args = parser.parse_args()
    store = SkillStore(args.project)
    handler = make_handler(store)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    def stop_service(signum, frame):
        raise KeyboardInterrupt
    previous_term = signal.signal(signal.SIGTERM, stop_service)
    print(f"Skill Editor: http://127.0.0.1:{server.server_address[1]}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        handler.shutdown_engine()
        server.server_close()
        signal.signal(signal.SIGTERM, previous_term)


if __name__ == "__main__":
    main()
