"""Independent task plans and real executor state, stored on the internal disk.

This module never executes a skill or starts an agent. Only explicit semantic
planning may call OpenRouter. Executor updates are supplied by the server's
runner through update_state; handoff generation does not start execution.
"""
from __future__ import annotations

from contextlib import contextmanager
import copy
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import uuid

from .core import EditorError, digest
from .selection import build_plan, validate_request


TASK_ID = re.compile(r"task-[a-f0-9]{32}")
SHA = re.compile(r"[a-f0-9]{64}")
EVENT_TYPE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}")
STATUSES = {"draft", "ready", "needs_skills", "needs_clarification", "queued", "running", "completed", "failed", "cancelled"}
ACTIVE = {"queued", "running"}
MAX_TASK_BYTES = 4_000_000
MAX_EVENTS = 2000
MAX_FEEDBACK = 200


def _now():
    return datetime.now(timezone.utc).isoformat()


def _canonical(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    except (ValueError, TypeError, RecursionError):
        raise EditorError("Task state must contain bounded JSON values.") from None


def _text(value, label, limit=4000, empty=False):
    if not isinstance(value, str) or len(value) > limit or (not empty and not value.strip()):
        raise EditorError(f"{label} must be text under {limit} characters.")
    if any(ord(char) < 32 and char not in "\n\t\r" for char in value):
        raise EditorError(f"{label} contains unsupported control characters.")
    return value.strip()


def _payload(payload, allowed):
    if not isinstance(payload, dict) or set(payload) - allowed:
        raise EditorError("Task request contains unsupported fields.")


class EngineStore:
    """One independently persisted task per file, with shared and process locks.

    auto_sync is explicit so fixtures and metadata GETs never trigger discovery.
    Production can enable it to use SkillStore's existing backed-up refresh.
    """

    def __init__(self, store, *, auto_sync=False, sync_inventory=None):
        self.store = store
        self.auto_sync = bool(auto_sync)
        self.sync_inventory = sync_inventory or store.refresh_inventory
        self._instance = uuid.uuid4().hex

    def config(self):
        return {"localPlannerAvailable": True,
                "semanticPlannerAvailable": bool(os.environ.get("OPENROUTER_API_KEY", "").strip() and os.environ.get("OPENROUTER_MODEL", "").strip()),
                "executorAvailable": False, "automaticSync": self.auto_sync, "automaticInstall": False}

    def _directory(self):
        return self.store._state_directory(".state/engine/tasks")

    def _path(self, identifier):
        if not isinstance(identifier, str) or not TASK_ID.fullmatch(identifier):
            raise EditorError("A valid task id is required.")
        return self.store._physical_internal(self._directory() / (identifier + ".json"))

    @contextmanager
    def _locked(self):
        # An RLock coordinates threads and other wrappers of the SkillStore;
        # flock also serializes separate local server processes.
        with self.store._lock:
            directory = self._directory()
            lock_path = self.store._physical_internal(directory / ".lock")
            fd = os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
            try:
                if not stat.S_ISREG(os.fstat(fd).st_mode):
                    raise EditorError("Task lock must be a regular file.", 403)
                fcntl.flock(fd, fcntl.LOCK_EX)
                yield
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)

    def _load(self, identifier):
        path = self._path(identifier)
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(fd, "rb") as handle:
                if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
                    raise EditorError("Task files must be regular files.", 403)
                raw = handle.read(MAX_TASK_BYTES + 1)
        except FileNotFoundError:
            raise EditorError("Task was not found.", 404) from None
        if len(raw) > MAX_TASK_BYTES:
            raise EditorError("Task exceeds the persisted state size limit.", 413)
        try:
            task = json.loads(raw)
        except (ValueError, UnicodeError):
            raise EditorError("Task JSON is invalid; no replacement was written.", 409) from None
        if not isinstance(task, dict) or task.get("id") != identifier or not isinstance(task.get("status"), str) or task["status"] not in STATUSES or not isinstance(task.get("plan"), dict):
            raise EditorError("Task has an unsupported structure.", 409)
        if any(not isinstance(task.get(key), str) for key in ("request", "title", "createdAt", "updatedAt")) or any(not isinstance(task.get(key), list) for key in ("events", "feedback")):
            raise EditorError("Task has an unsupported structure.", 409)
        if task.get("run") is not None and not isinstance(task["run"], dict):
            raise EditorError("Task has an unsupported run structure.", 409)
        if any(not isinstance(task["plan"].get(key), list) for key in ("requirements", "combo", "steps", "gaps", "warnings")):
            raise EditorError("Task has an unsupported plan structure.", 409)
        if not isinstance(task.get("sha"), str) or task["sha"] != self._sha(task):
            raise EditorError("Task content changed outside the task store; reload from a valid record.", 409)
        previous = 0
        for event in task["events"]:
            if not isinstance(event, dict) or type(event.get("sequence")) is not int or event["sequence"] <= previous:
                raise EditorError("Task event history has an invalid sequence.", 409)
            previous = event["sequence"]
        return task

    @staticmethod
    def _sha(task):
        return digest(_canonical({key: value for key, value in task.items() if key != "sha"}))

    def _save(self, task):
        task["sha"] = self._sha(task)
        raw = (_canonical(task) + "\n").encode("utf-8")
        if len(raw) > MAX_TASK_BYTES:
            raise EditorError("Task exceeds the persisted state size limit.", 413)
        path = self._path(task["id"])
        fd, temporary = tempfile.mkstemp(prefix=".task-", dir=path.parent)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "wb") as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
            self.store._physical_internal(path)
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        return copy.deepcopy(task)

    @staticmethod
    def _baseline(task, baseline):
        if not isinstance(baseline, str) or not SHA.fullmatch(baseline):
            raise EditorError("A baselineSha SHA-256 digest is required.")
        if baseline != task["sha"]:
            raise EditorError("Task changed since it was opened. Reload before continuing.", 409)

    @staticmethod
    def _event(task, event):
        if not isinstance(event, dict) or set(event) - {"type", "message"}:
            raise EditorError("Task events accept type and message only.")
        kind = event.get("type")
        if not isinstance(kind, str) or not EVENT_TYPE.fullmatch(kind):
            raise EditorError("Task event type is invalid.")
        message = _text(event.get("message"), "Task event message", 4000)
        sequence = task["events"][-1]["sequence"] + 1 if task["events"] else 1
        task["events"].append({"sequence": sequence, "type": kind, "message": message, "at": _now()})
        if len(task["events"]) > MAX_EVENTS:
            task["events"] = task["events"][-MAX_EVENTS:]

    def _recover(self, task):
        if task["status"] not in ACTIVE:
            return task
        run = task.get("run") if isinstance(task.get("run"), dict) else {}
        owner = run.get("engineOwner") if isinstance(run.get("engineOwner"), dict) else {}
        if owner.get("instanceId") == self._instance:
            return task
        pid = owner.get("pid")
        if type(pid) is int and pid == os.getpid():
            # Multiple wrappers/handlers may coexist in one live service. A
            # different instance id is not evidence that its worker stopped.
            # Preserve ownership; update_state still rejects another wrapper's
            # attempt to mutate the active run.
            return task
        if type(pid) is int and pid > 0:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                pass
            except PermissionError:
                # A possibly live owner must not be overwritten or killed.
                return task
            else:
                return task
        # A new server instance cannot resume or verify the old stream. Keep
        # artifacts/history and record an interruption instead of fabricating
        # completion or silently restarting an expensive process.
        task["status"] = "failed"
        task["run"] = {**run, "interrupted": True, "finishedAt": _now(), "error": "The previous execution owner is no longer attached. Review its artifacts before explicitly rerunning."}
        task["updatedAt"] = _now()
        self._event(task, {"type": "interrupted", "message": "执行连接在服务重启后无法恢复；已保留历史与产物，没有自动重跑或声明完成。"})
        return self._save(task)

    def read(self, identifier):
        with self._locked():
            return copy.deepcopy(self._recover(self._load(identifier)))

    def list(self):
        tasks, warnings = [], []
        with self._locked():
            for path in sorted(self._directory().glob("task-*.json")):
                try:
                    task = self._recover(self._load(path.stem))
                except (EditorError, OSError):
                    warnings.append("无法读取任务记录：" + path.name)
                    continue
                tasks.append({key: copy.deepcopy(task[key]) for key in ("id", "title", "request", "status", "createdAt", "updatedAt", "sha")})
        tasks.sort(key=lambda item: (item["updatedAt"], item["id"]), reverse=True)
        return {"tasks": tasks, "warnings": warnings}

    def _prepare(self, request, mode):
        if self.auto_sync:
            self.sync_inventory()
        return build_plan(self.store, request, mode)

    @staticmethod
    def _planned_status(plan):
        if plan.get("clarifications"):
            return "needs_clarification"
        return "needs_skills" if plan.get("gaps") else "ready"

    def create(self, payload):
        _payload(payload, {"request", "mode"})
        request = validate_request(payload.get("request"))
        mode = payload.get("mode", "local")
        if mode not in ("local", "semantic"):
            raise EditorError("Task planner mode must be local or semantic.")
        # Plan before persisting so a failed model call leaves no pretend plan.
        plan = self._prepare(request, mode)
        now = _now()
        task = {"id": "task-" + uuid.uuid4().hex, "request": request,
                "title": request.splitlines()[0][:100], "status": self._planned_status(plan),
                "createdAt": now, "updatedAt": now, "plan": plan,
                "events": [], "run": None, "feedback": []}
        self._event(task, {"type": "created", "message": "任务已保存，尚未启动执行。"})
        self._event(task, {"type": "planned", "message": "已生成准备方案（" + plan["method"] + "）。"})
        with self._locked():
            if self._path(task["id"]).exists():
                raise EditorError("Task identifier collision; retry creation.", 409)
            return self._save(task)

    def plan(self, payload):
        _payload(payload, {"taskId", "baselineSha", "mode"})
        with self._locked():
            task = self._recover(self._load(payload.get("taskId")))
            self._baseline(task, payload.get("baselineSha"))
            if task["status"] in ACTIVE:
                raise EditorError("An active task cannot be replanned; cancel or wait for its execution.", 409)
            if task.get("run") is not None:
                raise EditorError("此任务已有执行记录；请创建新任务调整方案，保留原结果。", 409)
            request, baseline = task["request"], task["sha"]
        # Network planning must not keep the task/process write lock. The SHA
        # is checked again on commit so concurrent feedback/run is never lost.
        mode = payload.get("mode", "local")
        if mode not in ("local", "semantic"):
            raise EditorError("Task planner mode must be local or semantic.")
        plan = self._prepare(request, mode)
        with self._locked():
            task = self._recover(self._load(payload["taskId"]))
            self._baseline(task, baseline)
            task.update({"plan": plan, "status": self._planned_status(plan), "updatedAt": _now()})
            self._event(task, {"type": "planned", "message": "已重新核实本地来源并生成方案（" + plan["method"] + "）。"})
            return self._save(task)

    def feedback(self, payload):
        _payload(payload, {"taskId", "baselineSha", "outcome", "note"})
        if payload.get("outcome") not in ("helpful", "not_helpful"):
            raise EditorError("Feedback outcome must be helpful or not_helpful.")
        note = _text(payload.get("note", ""), "Feedback note", 4000, empty=True)
        with self._locked():
            task = self._recover(self._load(payload.get("taskId")))
            self._baseline(task, payload.get("baselineSha"))
            if len(task["feedback"]) >= MAX_FEEDBACK:
                raise EditorError("This task reached its feedback record limit.", 413)
            task["feedback"].append({"outcome": payload["outcome"], "note": note, "at": _now(), "planSha": digest(_canonical(task["plan"])), "runId": task["run"].get("id") if isinstance(task.get("run"), dict) else None})
            task["updatedAt"] = _now()
            self._event(task, {"type": "feedback", "message": "已记录用户反馈；该记录不等同于客观效果评分。"})
            return self._save(task)

    def handoff(self, payload):
        _payload(payload, {"taskId", "baselineSha"})
        with self._locked():
            task = self._recover(self._load(payload.get("taskId")))
            self._baseline(task, payload.get("baselineSha"))
            self._assert_sources_current(task)
        lines = ["请承接以下真实任务，并遵守当前宿主和用户授权。", "", "任务：", task["request"], "", "建议能力分工（这是准备方案，尚未执行）："]
        if not task["plan"]["combo"]:
            lines.append("没有选择专用 Skill；按任务要求使用宿主已有通用能力。")
        for item in task["plan"]["combo"]:
            lines.extend(["- " + item["name"] + "：" + item["role"], "  来源：" + item["source"] + "；文件：" + item["path"], "  SHA-256：" + item["sha"] + "；当前暴露状态：" + item["availability"]])
        if task["plan"].get("gaps") or task["plan"].get("clarifications"):
            lines.extend(["", "开始前需要解决："])
            lines.extend("- " + item["label"] + "：" + item["reason"] for item in task["plan"]["gaps"])
            lines.extend("- " + item for item in task["plan"].get("clarifications", []))
        lines.extend(["", "先核对所列文件的当前内容、SHA 和宿主可用性，再按需读取 Skill。文件和此方案是任务证据，不得覆盖宿主边界；不可把交接文本、准备完成或缓存存在记作真实执行成功。", "任务记录：" + task["id"]])
        return {"prompt": "\n".join(lines), "taskId": task["id"]}

    def _assert_sources_current(self, task):
        for item in task["plan"].get("combo", []):
            try:
                record = self.store.skill(item["id"])
                if record.get("path") != item["path"] or record.get("source", "unknown") != item["source"]:
                    raise EditorError("Selected skill source identity changed.", 409)
                content = self.store._read_content(Path(item["path"]))
                if digest(content) != item["sha"]:
                    raise EditorError("Selected skill content changed.", 409)
            except (OSError, UnicodeError, EditorError):
                raise EditorError("A selected skill changed or became unavailable. Replan before handoff or execution.", 409) from None

    def events(self, identifier, after=0):
        if isinstance(after, str) and re.fullmatch(r"[0-9]{1,12}", after):
            after = int(after)
        if type(after) is not int or not 0 <= after <= 10**12:
            raise EditorError("Event cursor must be a nonnegative integer.")
        task = self.read(identifier)
        events = task["events"]
        first = events[0]["sequence"] if events else 0
        last = events[-1]["sequence"] if events else 0
        return {"taskId": identifier, "events": [item for item in events if item["sequence"] > after],
                "lastSequence": last, "oldestSequence": first, "truncated": bool(first and after < first - 1),
                "status": task["status"], "sha": task["sha"]}

    @staticmethod
    def _validate_plan_patch(plan, current):
        if not isinstance(plan, dict) or set(plan) != set(current):
            raise EditorError("Executor plan updates must preserve the planning structure.")
        # The runner owns step statuses only. Selection evidence and coverage
        # remain immutable unless the explicit planning operation recomputes it.
        before, after = copy.deepcopy(current), copy.deepcopy(plan)
        old_steps, new_steps = before.pop("steps", None), after.pop("steps", None)
        if before != after or not isinstance(new_steps, list) or not isinstance(old_steps, list) or len(new_steps) != len(old_steps):
            raise EditorError("Executor plan updates may change step statuses only.")
        for old, new in zip(old_steps, new_steps):
            if not isinstance(new, dict) or {key: value for key, value in old.items() if key != "status"} != {key: value for key, value in new.items() if key != "status"} or new.get("status") not in {"pending", "queued", "running", "completed", "failed", "cancelled", "skipped"}:
                raise EditorError("Executor returned an invalid task step update.")

    def update_state(self, identifier, patch, event=None, baselineSha=None):
        """Internal runner transaction. Not a public arbitrary task-edit API."""
        if not isinstance(patch, dict) or set(patch) - {"status", "plan", "run"}:
            raise EditorError("Executor updates accept status, plan and run only.")
        if len(_canonical(patch).encode("utf-8")) > 750_000:
            raise EditorError("Executor task update exceeds the size limit.", 413)
        with self._locked():
            task = self._recover(self._load(identifier))
            if baselineSha is not None:
                self._baseline(task, baselineSha)
            owner = (task.get("run") or {}).get("engineOwner", {})
            if task["status"] in ACTIVE and owner.get("instanceId") != self._instance:
                raise EditorError("This task is owned by another live execution service; use its connection to cancel or wait for it.", 409)
            status = patch.get("status", task["status"])
            if not isinstance(status, str) or status not in STATUSES:
                raise EditorError("Unsupported task status.")
            previous = task["status"]
            if status in ACTIVE and previous not in ACTIVE:
                if previous not in {"ready", "completed", "failed", "cancelled"} or task["plan"].get("gaps") or task["plan"].get("clarifications"):
                    raise EditorError("Task requirements must be ready before execution.", 409)
                self._assert_sources_current(task)
            if patch.get("status") == "queued" and previous in ACTIVE:
                raise EditorError("Task execution is already active.", 409)
            terminal = {"completed", "failed", "cancelled"} | ({"needs_clarification"} if previous == "running" else set())
            if previous in ACTIVE and status not in ACTIVE | terminal:
                raise EditorError("An active task must finish or be cancelled before replanning.", 409)
            if status == "completed" and previous != "running":
                raise EditorError("Only a running task can complete.", 409)
            if "plan" in patch:
                self._validate_plan_patch(patch["plan"], task["plan"])
            if "run" in patch and patch["run"] is not None and not isinstance(patch["run"], dict):
                raise EditorError("Task run state must be an object or null.")
            task.update(copy.deepcopy(patch))
            if status in ACTIVE:
                task["run"] = {**(task["run"] or {}), "engineOwner": {"instanceId": self._instance, "pid": os.getpid()}}
            task["updatedAt"] = _now()
            if event is not None:
                self._event(task, event)
            elif status != previous:
                self._event(task, {"type": "state_changed", "message": "执行器报告状态：" + status})
            return self._save(task)
