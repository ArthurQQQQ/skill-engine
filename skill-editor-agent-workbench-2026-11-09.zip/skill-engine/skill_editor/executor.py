"""Opt-in Codex execution routed exclusively through OpenRouter.

No model is contacted by construction, config, planning, or handoff. A run needs
operator configuration and a selected, current task version. Native JSONL events
are evidence of execution; a prepared prompt is never recorded as a completed run.
"""
from __future__ import annotations

import base64
import copy
from datetime import datetime, timezone
import fcntl
import json
import mimetypes
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import stat
import subprocess
import threading
import time
import uuid

from .core import EditorError, SkillStore
from .selection import MAX_EXECUTION_SKILLS


MAX_BUNDLE_BYTES = 32_000_000
MAX_RESULT_BYTES = 1_000_000
MAX_LINE_BYTES = 512_000
MAX_STREAM_BYTES = 8_000_000
MAX_NATIVE_EVENTS = 5000
ACTIVE = {"queued", "running"}
RESULT_SCHEMA = {"type": "object", "additionalProperties": False,
    "properties": {"status": {"type": "string", "enum": ["completed", "blocked", "failed"]},
                   "summary": {"type": "string", "maxLength": 12000},
                   "artifacts": {"type": "array", "maxItems": 40, "items": {"type": "string", "maxLength": 512}},
                   "steps": {"type": "array", "maxItems": 30, "items": {"type": "object", "additionalProperties": False,
                       "properties": {"id": {"type": "string"}, "status": {"type": "string", "enum": ["pending", "completed", "blocked", "failed", "skipped"]}, "note": {"type": "string", "maxLength": 1000}},
                       "required": ["id", "status", "note"]}}},
    "required": ["status", "summary", "artifacts", "steps"]}


def _now():
    return datetime.now(timezone.utc).isoformat()


def _redact(text):
    text = str(text)
    for key in ("OPENROUTER_API_KEY", "OPENAI_API_KEY", "CODEX_API_KEY", "GITHUB_TOKEN", "GH_TOKEN", "SKILLS_API_TOKEN"):
        value = os.environ.get(key, "")
        if len(value) >= 6:
            text = text.replace(value, "[redacted]")
    text = re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._~+/-]{12,}", r"\1[redacted]", text)
    text = re.sub(r"sk-(?:or-v1-)?[A-Za-z0-9_-]{16,}", "[redacted]", text)
    return text


class Executor:
    def __init__(self, engine):
        self.engine = engine
        self.store = engine.store
        self._lock = threading.RLock()
        self._jobs = {}
        self._closed = False

    def config(self):
        configured_binary = os.environ.get("SKILL_ENGINE_CODEX_BIN", "").strip()
        binary = configured_binary or shutil.which("codex")
        available = bool(binary and Path(binary).is_file() and os.access(binary, os.X_OK)
                         and not str(Path(binary).resolve()).startswith('/Volumes/'))
        key = bool(os.environ.get("OPENROUTER_API_KEY", "").strip())
        model = os.environ.get("OPENROUTER_MODEL", "").strip()
        valid_model = bool(re.fullmatch(r"[A-Za-z0-9~][A-Za-z0-9._~:-]*/[A-Za-z0-9][A-Za-z0-9._:~+/-]{0,160}", model))
        enabled = os.environ.get("SKILL_ENGINE_ALLOW_EXECUTION", "") == "1"
        configured = available and key and valid_model and enabled
        if not available:
            reason = "未找到 Codex CLI；请先安装或指定执行器路径。"
        elif not key or not valid_model:
            reason = "执行器未连接：请在服务进程配置 OpenRouter 密钥和模型。"
        elif not enabled:
            reason = "执行器已配置，尚未启用任务执行。"
        else:
            reason = "就绪；任务将在独立工作目录中执行。"
        return {"available": available, "configured": configured, "enabled": enabled,
                "provider": "OpenRouter", "harness": "Codex CLI", "model": model if valid_model else None,
                "reason": reason, "sandbox": "workspace-write", "maxConcurrentRuns": 1,
                "requiredConfiguration": ["OPENROUTER_API_KEY", "OPENROUTER_MODEL", "SKILL_ENGINE_ALLOW_EXECUTION=1"]}

    def _binary(self):
        return os.environ.get("SKILL_ENGINE_CODEX_BIN", "").strip() or shutil.which("codex")

    def _root(self):
        return SkillStore._physical_internal(self.store.project / ".state" / "engine" / "workspaces")

    def _lease(self):
        path = SkillStore._physical_internal(self.store.project / ".state" / "engine" / "run.lock")
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor = os.open(path, os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0), 0o600)
        try:
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise EditorError("执行锁不是安全的普通文件。", 409)
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise EditorError("本项目已有执行任务，请等待完成或到原服务取消。", 409) from None
            return descriptor
        except BaseException:
            os.close(descriptor)
            raise

    def _command(self, workspace, output):
        # CLI overrides apply to this process only; never rewrite user config or
        # allow its default provider to silently use direct OpenAI authentication.
        return [self._binary(), "exec", "--ignore-user-config", "--ephemeral", "--json",
                "--sandbox", "workspace-write", "--skip-git-repo-check", "--color", "never",
                "-C", str(workspace), "-m", os.environ["OPENROUTER_MODEL"].strip(),
                "-c", 'model_provider="skill_engine_openrouter"',
                "-c", 'model_providers.skill_engine_openrouter.name="OpenRouter"',
                "-c", 'model_providers.skill_engine_openrouter.base_url="https://openrouter.ai/api/v1"',
                "-c", 'model_providers.skill_engine_openrouter.env_key="OPENROUTER_API_KEY"',
                "-c", 'model_providers.skill_engine_openrouter.wire_api="responses"',
                "-c", "model_providers.skill_engine_openrouter.requires_openai_auth=false",
                "-c", 'approval_policy="never"', "--output-schema", str(workspace / "result-schema.json"),
                "-o", str(output), "-"]

    def _child_environment(self, workspace):
        # Retain the user's normal HOME without redirecting Codex state. Unrelated
        # credentials are not inherited by the task process.
        allowed = {"PATH", "HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "LC_CTYPE", "SHELL", "SYSTEMROOT"}
        env = {key: value for key, value in os.environ.items() if key in allowed}
        env["OPENROUTER_API_KEY"] = os.environ["OPENROUTER_API_KEY"]
        env["TMPDIR"] = str(workspace / "tmp")
        env["NO_COLOR"] = "1"
        return env

    def _selected(self, task):
        combo = (task.get("plan") or {}).get("combo", [])
        if not isinstance(combo, list) or len(combo) > MAX_EXECUTION_SKILLS:
            raise EditorError("任务组合格式无效，请重新规划。", 409)
        selected = []
        for item in combo:
            current = self.store.read(item.get("id", ""))
            expected = item.get("sha") or item.get("sha256")
            if not expected or current.get("sha") != expected:
                raise EditorError("所选技能已变化，请重新规划后再运行。", 409)
            selected.append(current)
        return selected

    def _prepare(self, task, selected, workspace):
        workspace.mkdir(parents=True, exist_ok=False)
        (workspace / "tmp").mkdir()
        skill_root = workspace / ".agents" / "skills"
        skill_root.mkdir(parents=True)
        total = 0
        used = set()
        loaded = []
        for record in selected:
            original = Path(record["skill"]["path"]).absolute()
            folder = original.parent.name
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", folder) or folder in used:
                raise EditorError("组合含有重名或不受支持的技能目录，请调整组合。", 409)
            used.add(folder)
            if original.is_symlink() or original.parent.resolve() != original.parent:
                raise EditorError("技能来源包含符号链接，未准备执行。", 409)
            destination = skill_root / folder
            count = 0
            directory_modes = []
            def unreadable(error):
                raise EditorError("技能资源目录不可完整读取，未准备执行。", 409) from error
            for current, directories, files in os.walk(original.parent, followlinks=False, onerror=unreadable):
                current = Path(current)
                current_info = current.lstat()
                if not stat.S_ISDIR(current_info.st_mode):
                    raise EditorError("技能资源目录在准备过程中变化。", 409)
                count += 1
                if count > 2000:
                    raise EditorError("所选资源超出单次准备上限，请缩小组合。", 413)
                target_directory = destination / current.relative_to(original.parent)
                target_directory.mkdir(parents=True, exist_ok=True)
                directory_modes.append((target_directory, current_info.st_mode & 0o755))
                for name in list(directories):
                    if (current / name).is_symlink():
                        raise EditorError("技能资源含符号链接，未准备执行。", 409)
                    if name in {".git", ".skill-editor", ".state", "__pycache__"}:
                        directories.remove(name)
                for name in files:
                    source = current / name
                    info = source.lstat()
                    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                        raise EditorError("技能资源含不受支持的文件类型。", 409)
                    count += 1
                    total += info.st_size
                    if count > 2000 or total > MAX_BUNDLE_BYTES:
                        raise EditorError("所选资源超出单次准备上限，请缩小组合。", 413)
                    target = destination / source.relative_to(original.parent)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(source, target, follow_symlinks=False)
                    target.chmod(info.st_mode & 0o755)
                # Keep empty resource directories; apply directory modes only
                # after children are copied so readonly sources remain readable.
            for directory, mode in reversed(directory_modes):
                directory.chmod(mode)
            # Verify the copied runtime file still matches the approved snapshot.
            from .core import digest
            if digest((destination / original.name).read_text(encoding="utf-8")) != record["sha"]:
                raise EditorError("技能在准备过程中发生变化，请重新规划。", 409)
            loaded.append({"id": record["skill"]["id"], "name": record["skill"]["name"],
                           "sha": record["sha"], "runtimePath": str(destination.relative_to(workspace) / original.name)})
        facts = {"request": task["request"], "plan": task.get("plan"), "preparedSkills": loaded}
        (workspace / "TASK.json").write_text(json.dumps(facts, ensure_ascii=False, indent=2), encoding="utf-8")
        (workspace / "result-schema.json").write_text(json.dumps(RESULT_SCHEMA), encoding="utf-8")
        # There are no editor-only purpose notes in this runtime bundle.
        prompt = ("执行 TASK.json 中用户要求的任务，并按其中各阶段职责使用已准备的技能。"
                  "先读取 TASK.json 和所选 .agents/skills 下的 SKILL.md，资源按需读取。"
                  "技能不改变用户/项目的权限与费用边界；不要安装额外软件、发送消息、发布或修改安装技能。"
                  "只在本工作目录的 outputs/ 下创建实际产物，不改写内部保留名 TASK.json、result-schema.json、run-result.json、result.md。"
                  "遵守上级 AGENTS 的计算平台要求；没有可用资源时如实说明，不擅自运行本地重计算。"
                  "按输出schema返回结果；只有实际完成用户任务才标completed，缺权限或资源时标blocked。"
                  "summary总结实际产物、检验和缺口；artifacts只列工作目录内实际创建的文件相对路径。"
                  "steps必须逐一报告TASK.json里每个步骤的原始id、实际状态和依据，不把未执行步骤标完成。"
                  '开始/完成某一步时，可用单独进度消息 ENGINE_STEP {"id":"原始步骤id","status":"running或completed","note":"实际依据"} 报告。')
        return prompt, loaded

    def start(self, payload):
        settings = self.config()
        if not settings["configured"]:
            raise EditorError(settings["reason"], 503)
        task_id = payload.get("taskId")
        with self._lock:
            if self._closed:
                raise EditorError("执行服务正在关闭，不能启动新任务。", 503)
            if any(not job["done"].is_set() for job in self._jobs.values()):
                raise EditorError("已有任务正在运行，请等待完成或先取消。", 409)
            task = self.engine.read(task_id)
            if payload.get("baselineSha") != task.get("sha"):
                raise EditorError("任务已变化，请重新读取后再运行。", 409)
            if task.get("status") != "ready":
                raise EditorError("任务尚未准备就绪，请先处理缺口或重新规划。", 409)
            if task.get("run") is not None:
                raise EditorError("此任务已有执行记录；请创建新任务，保留原结果。", 409)
            lease = self._lease()
            try:
                selected = self._selected(task)
                run_id = uuid.uuid4().hex
                root = self._root()
                root.mkdir(parents=True, exist_ok=True)
                workspace = SkillStore._physical_internal(root / run_id)
                prompt, loaded = self._prepare(task, selected, workspace)
                run = {"id": run_id, "provider": "OpenRouter", "harness": "Codex CLI", "model": settings["model"],
                       "workspace": str(workspace), "startedAt": None, "finishedAt": None,
                       "preparedSkills": loaded, "artifacts": [], "cancelRequested": False,
                       "activationEvidence": "Prepared files are not proof of native skill activation."}
                queued = self.engine.update_state(task_id, {"status": "queued", "run": run},
                    {"type": "queued", "message": "任务已准备，等待执行器启动。"}, baselineSha=task["sha"])
                job = {"cancel": threading.Event(), "done": threading.Event(), "process": None,
                       "workspace": workspace, "runId": run_id, "lease": lease}
                self._jobs[task_id] = job
                thread = threading.Thread(target=self._worker, args=(task_id, prompt, job), daemon=True, name="skill-engine-run")
                job["thread"] = thread
                thread.start()
                return queued
            except BaseException:
                os.close(lease)
                if task_id in self._jobs:
                    self._jobs[task_id]["done"].set()
                raise

    def _patch(self, task_id, status=None, event=None, step_updates=None, step_source='agent_reported', **fields):
        for _ in range(12):
            current = self.engine.read(task_id)
            job = self._jobs.get(task_id)
            if job and (current.get('run') or {}).get('id') != job['runId']:
                raise EditorError('执行记录已被替换，旧进程不能写入新任务。', 409)
            if current['status'] in {'completed', 'failed', 'cancelled', 'needs_clarification'}:
                return current  # A late cancellation/progress event never erases a result.
            run = {**(current.get("run") or {}), **fields}
            patch = {"run": run}
            if status:
                patch["status"] = status
            if step_updates:
                plan = copy.deepcopy(current['plan'])
                evidence = dict(run.get('stepEvidence') or {})
                valid_ids = {item['id'] for item in plan['steps']}
                for item in step_updates:
                    if item.get('id') not in valid_ids or item.get('status') not in {'pending','queued','running','completed','failed','cancelled','skipped','blocked'}:
                        raise EditorError('执行器返回了未知步骤或状态。', 502)
                    for step in plan['steps']:
                        if step['id'] == item['id']:
                            step['status'] = 'pending' if item['status']=='blocked' else item['status']
                    evidence[item['id']] = {'status': item['status'], 'note': _redact(item.get('note',''))[:1000], 'source': step_source, 'at': _now()}
                run['stepEvidence'] = evidence
                patch['plan'] = plan
            try:
                return self.engine.update_state(task_id, patch, event, baselineSha=current['sha'])
            except EditorError as exc:
                if exc.status != 409 or self.engine.read(task_id)['sha'] == current['sha']:
                    raise
        raise EditorError('任务状态连续变化，请重新读取。', 409)

    def _stopped(self, task_id, status, event, **fields):
        task = self.engine.read(task_id)
        steps = [{'id': step['id'], 'status': status, 'note': event['message']}
                 for step in (task.get('plan') or {}).get('steps', [])
                 if step.get('status') in {'queued', 'running'}]
        return self._patch(task_id, status, event, step_updates=steps,
                           step_source='executor_stop', **fields)

    @staticmethod
    def _stop(process):
        if process is None:
            return
        try:
            if os.name == "posix":
                os.killpg(process.pid, signal.SIGTERM)
            elif process.poll() is None:
                process.terminate()
        except ProcessLookupError:
            pass

    @staticmethod
    def _cleanup(process):
        Executor._stop(process)
        if os.name == 'posix':
            until = time.monotonic()+1
            while time.monotonic() < until:
                try:
                    os.killpg(process.pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(.05)
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=2)

    def _worker(self, task_id, prompt, job):
        process = None
        cleaned = False
        selector = selectors.DefaultSelector()
        try:
            if job["cancel"].is_set():
                self._patch(task_id, "cancelled", {"type": "cancelled", "message": "任务已取消，未启动执行器。"}, finishedAt=_now())
                return
            workspace = job["workspace"]
            output = workspace / "run-result.json"
            process = subprocess.Popen(self._command(workspace, output), cwd=workspace,
                env=self._child_environment(workspace), stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
            job["process"] = process
            self._patch(task_id, "running", {"type": "started", "message": "Codex 执行器已启动。"}, startedAt=_now())
            process.stdin.write(prompt.encode("utf-8"))
            process.stdin.close()
            selector.register(process.stdout, selectors.EVENT_READ)
            timeout = max(5, min(3600, int(os.environ.get("SKILL_ENGINE_RUN_TIMEOUT", "600"))))
            deadline = time.monotonic() + timeout
            buffer = b""
            last_message = ""
            completed = False
            error = ""
            usage = None
            received = native_events = progress_events = 0
            leader_exited_at = None
            while selector.get_map():
                if process.poll() is not None:
                    leader_exited_at = leader_exited_at or time.monotonic()
                    if time.monotonic()-leader_exited_at > .5:
                        break  # A descendant holding stdout cannot keep the job alive.
                if job["cancel"].is_set() or time.monotonic() > deadline:
                    self._stop(process)
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        if os.name == "posix":
                            os.killpg(process.pid, signal.SIGKILL)
                        else:
                            process.kill()
                        process.wait(timeout=3)
                    break
                for key, _ in selector.select(timeout=0.2):
                    chunk = os.read(key.fileobj.fileno(), 65536)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        continue
                    buffer += chunk
                    received += len(chunk)
                    if received > MAX_STREAM_BYTES:
                        raise EditorError('执行器累计输出超过本次任务上限。', 413)
                    if len(buffer) > MAX_LINE_BYTES:
                        raise EditorError("执行器输出超过单条事件上限。", 502)
                    while b"\n" in buffer:
                        line, buffer = buffer.split(b"\n", 1)
                        try:
                            event = json.loads(line)
                        except (ValueError, UnicodeError):
                            continue  # Never persist raw stderr or unparsed diagnostics.
                        if not isinstance(event, dict):
                            continue
                        native_events += 1
                        if native_events > MAX_NATIVE_EVENTS:
                            raise EditorError('执行器事件数量超过本次任务上限。', 413)
                        kind = event.get("type")
                        if kind == "turn.completed":
                            completed = True
                            usage = {k: v for k, v in (event.get("usage") or {}).items() if isinstance(v, (int, float))}
                        elif kind in {"turn.failed", "error"}:
                            raw = event.get("error") or event.get("message") or "执行器返回失败。"
                            error = _redact(raw.get("message", "执行器返回失败。") if isinstance(raw, dict) else raw)[:1500]
                        elif kind == "item.completed":
                            item = event.get("item") or {}
                            if item.get("type") == "agent_message":
                                message = _redact(item.get("text", ""))[:MAX_RESULT_BYTES]
                                if message.startswith('ENGINE_STEP '):
                                    try:
                                        step = json.loads(message[len('ENGINE_STEP '):])
                                        if not isinstance(step, dict):
                                            raise ValueError()
                                        self._patch(task_id, event={'type':'step_reported','message':'执行器报告步骤状态。'},step_updates=[step])
                                    except (ValueError, EditorError):
                                        pass
                                else:
                                    last_message = message
                            elif item.get("type") in {"command_execution", "file_change", "web_search", "mcp_tool_call"}:
                                titles = {"command_execution": "执行了一项命令", "file_change": "产生了文件变更", "web_search": "执行了一次搜索", "mcp_tool_call": "调用了一项工具"}
                                progress_events += 1
                                if progress_events <= 200:
                                    self._patch(task_id, event={"type": "progress", "message": titles[item["type"]]})
            code = process.wait(timeout=5)
            # The server must not inspect or write result paths while a runner
            # descendant can still replace those paths beneath it.
            self._cleanup(process)
            cleaned = True
            if job["cancel"].is_set():
                self._stopped(task_id, "cancelled", {"type": "cancelled", "message": "执行器已停止，已有工作文件已保留。"}, finishedAt=_now(), exitCode=code)
            elif time.monotonic() > deadline:
                self._stopped(task_id, "failed", {"type": "failed", "message": "任务超过执行时限，已有工作文件已保留。"}, finishedAt=_now(), exitCode=code)
            elif code != 0 or not completed or error:
                self._stopped(task_id, "failed", {"type": "failed", "message": error or "执行器未确认完成；已有文件已保留。"}, finishedAt=_now(), exitCode=code)
            else:
                if output.is_symlink() or (output.exists() and (not output.is_file() or output.stat().st_nlink != 1)):
                    raise EditorError("结果路径不是安全的普通文件。", 502)
                if output.exists():
                    if output.stat().st_size > MAX_RESULT_BYTES:
                        raise EditorError("结果文件超过显示上限，工作文件已保留。", 413)
                    result = _redact(output.read_text(encoding="utf-8"))
                else:
                    result = last_message
                try:
                    report = json.loads(result)
                except ValueError:
                    raise EditorError("执行器未返回约定的结果结构，无法确认任务状态。", 502) from None
                if (not isinstance(report, dict) or report.get("status") not in {"completed", "blocked", "failed"}
                    or not isinstance(report.get("summary"), str) or not 1 <= len(report["summary"].strip()) <= 12000
                    or not isinstance(report.get("artifacts"), list) or len(report["artifacts"]) > 40
                    or not all(isinstance(x, str) and len(x) <= 512 for x in report["artifacts"])
                    or not isinstance(report.get('steps'),list) or len(report['steps'])>30):
                    raise EditorError("执行器结果未通过格式核验。", 502)
                expected_steps = {step['id'] for step in self.engine.read(task_id)['plan']['steps']}
                actual_steps = report['steps']
                if (any(not isinstance(step,dict) or set(step)!={'id','status','note'} or step['status'] not in {'pending','completed','blocked','failed','skipped'} or not isinstance(step['note'],str) or len(step['note'])>1000 for step in actual_steps)
                    or len({step['id'] for step in actual_steps})!=len(actual_steps)
                    or {step['id'] for step in actual_steps}!=expected_steps):
                    raise EditorError('执行结果没有逐一核对任务步骤。', 502)
                if report['status']=='completed' and any(step['status'] not in {'completed','skipped'} for step in actual_steps):
                    raise EditorError('执行器声称完成，但仍有未完成的任务步骤。', 502)
                summary_path = workspace / "result.md"
                try:
                    descriptor = os.open(summary_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
                except FileExistsError:
                    raise EditorError("结果摘要路径已被占用，保留工作文件待检查。", 409) from None
                with os.fdopen(descriptor, 'w', encoding='utf-8') as handle:
                    handle.write(report['summary'])
                artifacts = self._collect_artifacts(workspace, ["result.md", *report["artifacts"]])
                state = {"completed": "completed", "blocked": "needs_clarification", "failed": "failed"}[report["status"]]
                self._patch(task_id, state, {"type": "result", "message": "执行器已返回结果。"},step_updates=actual_steps,
                            finishedAt=_now(), exitCode=code, usage=usage, summary=report["summary"],
                            outcomeEvidence="agent_reported", artifacts=artifacts)
        except Exception as exc:
            if process is not None and not cleaned:
                try:
                    self._cleanup(process)
                    cleaned = True
                except Exception:
                    pass
            message = str(exc) if isinstance(exc, EditorError) else "执行器启动或读取失败，工作文件已保留。"
            try:
                cancelled=job['cancel'].is_set()
                self._stopped(task_id, "cancelled" if cancelled else "failed", {"type": "cancelled" if cancelled else "failed", "message": '执行器已停止，工作文件已保留。' if cancelled else _redact(message)[:1500]}, finishedAt=_now())
            except Exception:
                pass
        finally:
            try:
                selector.close()
                if process is not None and not cleaned:
                    self._cleanup(process)
            finally:
                try:
                    if process is not None:
                        for pipe in (process.stdin, process.stdout):
                            if pipe and not pipe.closed:
                                pipe.close()
                finally:
                    os.close(job["lease"])
                    job["done"].set()

    def cancel(self, payload):
        identifier = payload.get("taskId")
        with self._lock:
            task = self.engine.read(identifier)
            job = self._jobs.get(identifier)
            if not job or job["done"].is_set():
                if task.get("status") in ACTIVE:
                    raise EditorError("该任务由另一执行服务管理，请在原服务中停止。", 409)
                return task
            job["cancel"].set()
            self._stop(job.get("process"))
            return self._patch(identifier, event={"type": "cancel_requested", "message": "已请求停止，等待执行器退出。"}, cancelRequested=True)

    @staticmethod
    def _collect_artifacts(workspace, names):
        import hashlib
        artifacts = []
        for name in dict.fromkeys(names):
            if len(artifacts) >= 40 or not name or Path(name).is_absolute() or '..' in Path(name).parts:
                continue
            if Path(name).parts[0] in {'.agents', '.git', '.state', '.skill-editor', 'tmp'} or name in {'TASK.json', 'result-schema.json', 'run-result.json'}:
                continue
            path = workspace / name
            if path.resolve() != path or not path.is_file() or path.stat().st_nlink != 1 or path.stat().st_size > MAX_RESULT_BYTES:
                continue
            content = path.read_bytes()
            artifacts.append({"name": name, "bytes": len(content), "kind": mimetypes.guess_type(name)[0] or "application/octet-stream",
                              "sha256": hashlib.sha256(content).hexdigest()})
        return artifacts

    def artifact(self, task_id, name):
        task = self.engine.read(task_id)
        run = task.get("run") or {}
        allowed = {item.get("name"): item for item in run.get("artifacts", [])}
        if name not in allowed:
            raise EditorError("没有该结果文件。", 404)
        root = self._root()
        workspace = SkillStore._physical_internal(Path(run.get("workspace", "")))
        if workspace.parent != root:
            raise EditorError("结果路径不在任务目录内。", 403)
        path = SkillStore._physical_internal(workspace / name)
        if not path.is_file() or path.stat().st_size > MAX_RESULT_BYTES:
            raise EditorError("结果文件不可读取。", 404)
        import hashlib
        content = path.read_bytes()
        if hashlib.sha256(content).hexdigest() != allowed[name].get("sha256"):
            raise EditorError("结果文件在记录后发生变化，请重新检查。", 409)
        kind = allowed[name].get("kind", "application/octet-stream")
        try:
            value = _redact(content.decode('utf-8'))
            encoding = 'utf-8'
        except UnicodeError:
            value = base64.b64encode(content).decode('ascii')
            encoding = 'base64'
        return {"name": name, "content": value, "kind": kind, "encoding": encoding}

    def close(self):
        with self._lock:
            self._closed = True
            jobs = list(self._jobs.values())
            for job in jobs:
                if not job["done"].is_set():
                    job["cancel"].set()
                    self._stop(job.get("process"))
        for job in jobs:
            job["done"].wait(timeout=8)
