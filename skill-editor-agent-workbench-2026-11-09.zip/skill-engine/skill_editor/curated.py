"""Reviewed directory metadata and non-executing installation checks.

Only application-owned profiles select probes. Upstream skill text stays data:
no instructions, dependency manifests, imports, commands or scripts are run.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
from importlib import metadata
import json
from pathlib import PurePosixPath
import posixpath
import re
import shutil
import sys
import urllib.parse

from .core import EditorError, SkillStore


_SHA = re.compile(r"^[0-9a-f]{40}$")
_REPO = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
_DECISIONS = {"candidate_for_evaluation", "candidate_core_only", "hold"}


def source_directory(source):
    path = source["path"]
    return "" if path == "SKILL.md" else path[:-len("/SKILL.md")]


def load_directory(project, *, required=True):
    path = SkillStore._physical_internal(project / "data/curated-skills.json")
    try:
        with path.open("rb") as handle:
            raw = handle.read(2_000_001)
    except FileNotFoundError:
        if not required:
            return None
        raise EditorError("The reviewed skill directory is unavailable; its seed file is missing.", 503) from None
    except OSError:
        raise EditorError("The reviewed skill directory could not be read; installation policy cannot be verified.", 503) from None
    try:
        if len(raw) > 2_000_000:
            raise ValueError()
        value = json.loads(raw)
        if not isinstance(value, dict) or value.get("schemaVersion") != 1 or not isinstance(value.get("researchedOn"), str):
            raise ValueError()
        for key in ("entries", "functionCategories", "useCases"):
            if not isinstance(value.get(key), list):
                raise ValueError()
        categories = {item["id"] for item in value["functionCategories"] if isinstance(item, dict) and isinstance(item.get("id"), str) and isinstance(item.get("label"), str)}
        uses = {item["id"] for item in value["useCases"] if isinstance(item, dict) and isinstance(item.get("id"), str) and isinstance(item.get("label"), str)}
        if len(categories) != len(value["functionCategories"]) or len(uses) != len(value["useCases"]):
            raise ValueError()
        ids = set()
        scopes = set()
        for item in value["entries"]:
            if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not item["id"] or item["id"] in ids:
                raise ValueError()
            ids.add(item["id"])
            source = item["source"]
            if not isinstance(source, dict) or not _REPO.fullmatch(source["repo"]) or not _SHA.fullmatch(source["ref"]) or not _SHA.fullmatch(source["blobSha"]):
                raise ValueError()
            path = source["path"]
            if not isinstance(path, str) or len(path) > 1000 or path.startswith("/") or "\\" in path or any(ord(c) < 32 for c in path) or any(part in ("", ".", "..", ".skill-editor", ".system") for part in path.split("/")) or path.split("/")[-1] != "SKILL.md":
                raise ValueError()
            scope = (source["repo"].lower().removesuffix(".git"), source_directory(source))
            if scope in scopes:
                raise ValueError()
            scopes.add(scope)
            if item.get("decision") not in _DECISIONS or item.get("category") not in categories:
                raise ValueError()
            if not isinstance(item.get("name"), str) or not isinstance(item.get("title"), str):
                raise ValueError()
            for key in ("useCases", "functionTags", "requirements", "runtimeReferences"):
                if not isinstance(item.get(key), list):
                    raise ValueError()
            if any(not isinstance(tag, str) or tag not in categories for tag in item["functionTags"]) or any(not isinstance(tag, str) or tag not in uses for tag in item["useCases"]):
                raise ValueError()
            if any(not isinstance(text, str) for text in item["requirements"] + item.get("optionalRequirements", [])):
                raise ValueError()
            if any(not isinstance(ref, dict) or not isinstance(ref.get("kind"), str) or not isinstance(ref.get("name", ref.get("path")), str) for ref in item["runtimeReferences"]):
                raise ValueError()
    except (ValueError, TypeError, KeyError, UnicodeError, AttributeError):
        raise EditorError("The reviewed skill directory is invalid; installation policy cannot be verified.", 503) from None
    return value


def directory_result(project, query="", category="", use_case=""):
    if any(not isinstance(value, str) or len(value) > 180 or any(ord(c) < 32 for c in value) for value in (query, category, use_case)):
        raise EditorError("Use a directory query and category/use-case identifiers up to 180 characters.")
    seed = load_directory(project)
    if category and category not in {item["id"] for item in seed["functionCategories"]}:
        raise EditorError("Choose a listed function category.")
    if use_case and use_case not in {item["id"] for item in seed["useCases"]}:
        raise EditorError("Choose a listed use case.")
    terms = query.strip().casefold().split()
    entries = []
    for entry in seed["entries"]:
        searchable = json.dumps(entry, ensure_ascii=False).casefold()
        if category and category not in entry["functionTags"] and category != entry["category"]:
            continue
        if use_case and use_case not in entry["useCases"]:
            continue
        if any(term not in searchable for term in terms):
            continue
        entries.append(deepcopy(entry))
    return {"entries": entries, "functionCategories": seed["functionCategories"], "useCases": seed["useCases"], "researchedOn": seed["researchedOn"], "total": len(entries), "counts": {"all": len(seed["entries"]), "candidates": sum(item["decision"] == "candidate_for_evaluation" for item in seed["entries"]), "coreOnly": sum(item["decision"] == "candidate_core_only" for item in seed["entries"]), "held": sum(item["decision"] == "hold" for item in seed["entries"])}}


def resolve_entry(project, identifier):
    if not isinstance(identifier, str) or not identifier or len(identifier) > 1100:
        raise EditorError("Select a reviewed directory entry.")
    seed = load_directory(project)
    for entry in seed["entries"]:
        if entry["id"] == identifier:
            return entry
    raise EditorError("The selected reviewed entry no longer exists.", 404)


def matching_entries(project, repo, path, files=None):
    """Exact scope, plus reviewed entries actually bundled by an ancestor scope."""
    seed = load_directory(project, required=False)
    if seed is None:
        return []
    repo = repo.lower().removesuffix(".git")
    result = []
    for entry in seed["entries"]:
        if entry["source"]["repo"].lower().removesuffix(".git") != repo:
            continue
        directory = source_directory(entry["source"])
        if directory == path:
            result.append(entry)
        elif files is not None:
            prefix = path + "/" if path else ""
            entry_path = entry["source"]["path"]
            if entry_path.startswith(prefix) and entry_path[len(prefix):] in files:
                result.append(entry)
    return result


def git_blob_sha(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode("ascii") + b"\0" + raw).hexdigest()


def license_evidence_path(source):
    """Accept only a pinned evidence path within the selected repository archive."""
    evidence = source.get("licenseEvidence", {}).get("evidence", {})
    if isinstance(evidence.get("license_path"), str):
        return evidence["license_path"]
    url = evidence.get("evidence_url") or evidence.get("url")
    if not isinstance(url, str):
        return None
    parsed = urllib.parse.urlsplit(url)
    parts = parsed.path.strip("/").split("/", 4)
    if parsed.scheme == "https" and parsed.netloc == "github.com" and not parsed.query and not parsed.fragment and len(parts) == 5 and "/".join(parts[:2]).lower() == source["repo"].lower() and parts[2:4] == ["blob", source["commit"]]:
        return urllib.parse.unquote(parts[4])
    return None


# Profiles are application policy, selected by reviewed identity, never by
# downloaded allowed-tools, compatibility declarations or package manifests.
_TOOLS = {
    "wrangler": ("node", "npm", "wrangler"), "terraform-style-guide": ("terraform",),
    "semgrep": ("semgrep", "bash", "git", "jq", "uv"),
    "differential-review": ("git",), "using-dbt-for-analytics-engineering": ("dbt",),
    "cloudflare": ("node", "npm"), "presentation-skill": ("node", "npm"),
    "scientific-visualization": ("uv",), "xlsx": ("soffice",),
}
_PACKAGES = {
    "webapp-testing": ("playwright",), "xlsx": ("openpyxl", "pandas", "markitdown"),
    "citation-management": ("requests",), "literature-review": ("requests",),
    "scientific-visualization": ("matplotlib", "Pillow", "pypdf", "numpy"),
    "presentation-skill": ("python-pptx", "Pillow", "lxml", "XlsxWriter"),
}
_PYTHON = {"webapp-testing": (3, 8), "semgrep": (3, 8), "documents": (3, 8), "presentation-skill": (3, 8), "xlsx": (3, 8), "citation-management": (3, 9), "literature-review": (3, 10), "exploratory-data-analysis": (3, 11), "scientific-visualization": (3, 11)}
_CONTEXT = {
    "wrangler": "Project configuration, CLI version and Cloudflare account permissions remain unverified.",
    "cloudflare": "Target Cloudflare product, project tools and account permissions remain unverified.",
    "terraform-style-guide": "Target project providers and validation environment remain unverified.",
    "using-dbt-for-analytics-engineering": "dbt project, warehouse connection and permissions remain unverified.",
    "property-based-testing": "The target language and its existing property-testing library remain unverified.",
    "webapp-testing": "Chromium/browser assets and access to the target application remain unverified.",
    "citation-management": "Access to academic network endpoints and their quotas remains unverified.",
    "literature-review": "Access to research sources and live DOI endpoints remains unverified.",
    "supabase-postgres-best-practices": "Guidance can be read locally; target database access and SQL validation remain unverified.",
}
_OPTIONAL_TOOLS = {"documents": ("soffice", "pdftoppm"), "presentation-skill": ("soffice", "pdftoppm"), "literature-review": ("pandoc", "xelatex"), "scientific-writing": ("python3",)}
_GUIDANCE = {"verification-before-completion", "frontend-design", "vercel-react-best-practices", "copywriting", "content-strategy", "product-marketing", "analytics", "obsidian-markdown", "scientific-writing", "supabase-postgres-best-practices", "terraform-style-guide", "property-based-testing", "writing-plans", "systematic-debugging", "differential-review"}


def _local_resource_gaps(files):
    """Follow the entry's explicit resource links; unrelated examples stay data."""
    missing = set()
    pending = ["SKILL.md"]
    visited = set()
    while pending:
        path = pending.pop()
        if path in visited:
            continue
        visited.add(path)
        try:
            content = files[path].decode("utf-8")
        except UnicodeError:
            continue
        # Examples inside fences do not declare package prerequisites.
        content = re.sub(r"(?m)^\s*(`{3,}|~{3,})[^\n]*\n[\s\S]*?^\s*\1\s*$", "", content)
        for match in re.finditer(r"!?\[[^\]\n]*\]\(<?([^\s)>]+)>?(?:\s+[^)\n]*)?\)", content):
            target = urllib.parse.unquote(match.group(1)).split("#", 1)[0].split("?", 1)[0]
            try:
                remote = bool(urllib.parse.urlsplit(target).scheme)
            except ValueError:
                # Broken remote URLs are not executable package prerequisites.
                continue
            if not target or remote or target.startswith(("/", "//")) or any(char in target for char in "{}<>*`"):
                continue
            resolved = posixpath.normpath(posixpath.join(str(PurePosixPath(path).parent), target))
            explicit = target.startswith(("./", "../", "scripts/", "references/", "assets/", "rules/", "templates/", "agents/", "commands/", "docs/"))
            if resolved in files and resolved.endswith(".md"):
                pending.append(resolved)
            if not explicit:
                continue
            if resolved.startswith("../") or resolved == ".." or (resolved not in files and not any(name.startswith(resolved.rstrip("/") + "/") for name in files)):
                missing.add(resolved)
    return sorted(missing)


def deployment(project, preview, files, *, installed=False):
    source = preview["source"]
    if preview.get("operation") == "rollback":
        return {"status": "installed_unverified" if installed else "ready_for_install", "installAllowed": not installed, "checks": [{"id": "restore", "label": "所选备份", "status": "present", "detail": "Restore only: selected backup content and current baseline remain protected by SHA checks. Current adoption policy does not prevent recovery of existing files.", "required": True}, {"id": "host", "label": "宿主发现", "status": "unknown", "detail": "Restoring files does not verify host discovery or runtime behavior.", "required": False}], "blockers": [], "hostStatus": "unverified", "effectivenessStatus": "untested", "environmentScope": "restore_only", "closureStatus": "historical_backup_not_revalidated", "nextAction": "Restore the selected backup files only, then separately review current prerequisites and host discovery."}
    if source.get("kind") == "local":
        gaps = _local_resource_gaps(files)
        blockers = ["个人包中的明确引用缺失：" + path for path in gaps]
        if preview.get("targetStatus") == "name_conflict":
            blockers.append("目标已有同名技能；本次采用不会覆盖现有内容。")
        checks = [
            {"id": "package", "label": "个人包快照", "status": "present", "detail": "所选个人目录的文件、模式及内容哈希已暂存；提交时重核原来源。", "required": True},
            {"id": "source-review", "label": "原来源与许可", "status": "unknown", "detail": "个人库存在只证明本机来源，不证明作者身份、再分发许可或任务质量。此操作不公开上传。", "required": False},
            {"id": "closure", "label": "组件与引用", "status": "blocked" if gaps else "unknown", "detail": "\n".join(blockers) if gaps else "未发现明确缺失的包内引用；动态依赖及运行环境尚未验证。", "required": True},
            {"id": "host", "label": "宿主发现", "status": "unknown", "detail": "采用文件后仍需由目标 Agent 核对发现、加载和运行。", "required": False},
        ]
        if preview.get("targetStatus") == "name_conflict":
            checks.append({"id": "target", "label": "目标目录", "status": "blocked", "detail": blockers[-1], "required": True})
        return {"status": "installed_unverified" if installed else "blocked" if blockers else "needs_setup", "installAllowed": not installed and not blockers,
                "checks": checks, "blockers": blockers, "hostStatus": "unverified", "effectivenessStatus": "untested", "environmentScope": "local_snapshot_only",
                "closureStatus": "blocked" if blockers else "local_static_references_only", "nextAction": "文件已采用；请在目标 Agent 中核对发现和实际任务。" if installed else "先处理明确缺项或同名冲突。" if blockers else "可采用所选个人包快照；宿主发现与运行前提仍待核对。"}
    if source.get("curatedId") or source.get("curatedScopeIds"):
        # A reviewed preview cannot lose its policy simply because the seed
        # disappears between preparation and the protected transaction.
        load_directory(project)
    entries = matching_entries(project, source["repo"], source["path"], files)
    exact = next((item for item in entries if source_directory(item["source"]) == source["path"]), None)
    checks = []
    blockers = []

    def check(identifier, label, status, detail, required=True):
        checks.append({"id": identifier, "label": label, "status": status, "detail": detail, "required": required})

    check("package", "完整所选目录", "present", "All selected files and their hashes are staged. No upstream code was run.")
    pin_matches = bool(exact and preview["name"] == exact["name"] and source["commit"] == exact["source"]["ref"] and git_blob_sha(files["SKILL.md"]) == exact["source"]["blobSha"])
    check("source-review", "固定来源资料", "present" if pin_matches else "unknown", "Selected commit and entry Git blob match the reviewed directory." if pin_matches else "This selected version has no matching reviewed commit and entry blob; dependencies and license scope remain unverified.")
    expected_ids = set(source.get("curatedScopeIds", []))
    if source.get("curatedId"):
        expected_ids.add(source["curatedId"])
    if expected_ids - {item["id"] for item in entries}:
        blockers.append("A reviewed component recorded in this preview is no longer in the trusted directory; inspect a fresh source before installation.")
    if source.get("reviewedPinMatched") and not pin_matches:
        blockers.append("The trusted entry identity or reviewed source pin changed after this preview; inspect a fresh reviewed version before installation.")
    if source.get("reviewedPinMatched") and exact and source.get("licenseEvidence", {}).get("evidence") != exact.get("license", {}):
        blockers.append("The reviewed license evidence changed after this preview; inspect a fresh reviewed version before installation.")
    for item in entries:
        if item["decision"] == "hold":
            blockers.append(item["name"] + ": adoption is on hold in the reviewed directory; resolve the recorded evidence gaps first.")
        elif item["decision"] == "candidate_core_only":
            blockers.append(item["name"] + ": only a restricted core branch was reviewed. This installer cannot isolate that branch from the complete package; its direct OpenAI API helper is outside the current authorization.")
        for ref in item["runtimeReferences"]:
            if ref.get("required") is False:
                continue
            component = ref.get("name", ref.get("path", "external component"))
            blockers.append(item["name"] + ": required " + ref["kind"] + " " + component + " is outside the selected skill deployment. Full component installation and host integration remain unresolved" + (" (" + ref["condition"] + ")" if isinstance(ref.get("condition"), str) else "") + ".")
    resource_gaps = _local_resource_gaps(files)
    for path in resource_gaps:
        blockers.append("Explicit package reference is unavailable in the selected directory: " + path)
    check("closure", "组件与引用", "blocked" if blockers else "present" if pin_matches else "unknown", "\n".join(blockers) if blockers else "Reviewed references have no required external components, and explicit local package links are present. Dynamic references and runtime behavior are untested." if pin_matches else "The selected subtree is complete; external component closure is unknown for an unreviewed version.")
    if preview.get("targetStatus") == "name_conflict":
        blockers.append("A personal skill with this name already exists; installing will not overwrite it.")
        check("target", "目标目录", "blocked", blockers[-1])

    # Paths, secret presence/values, subprocesses and module imports never enter
    # prerequisite evidence. These checks describe this backend only.
    if exact and pin_matches:
        name = exact["name"]
        minimum = _PYTHON.get(name)
        if minimum:
            check("python", "本机后端 Python", "present" if sys.version_info[:2] >= minimum else "missing", "Backend Python requires " + ".".join(map(str, minimum)) + "+; this says nothing about a remote runner.")
        for tool in _TOOLS.get(name, ()):
            check("tool:" + tool, "本机工具 · " + tool, "present" if shutil.which(tool) else "missing", "Executable presence only; version, operation and remote-runner availability were not tested.")
        for package in _PACKAGES.get(name, ()):
            try:
                metadata.version(package)
                status = "present"
            except (metadata.PackageNotFoundError, ModuleNotFoundError):
                status = "missing"
            except (ValueError, OSError):
                status = "unknown"
            check("package:" + package, "本机 Python 包 · " + package, status, "Distribution metadata only; no package was imported or tested.")
        for tool in _OPTIONAL_TOOLS.get(name, ()):
            check("optional-tool:" + tool, "可选本机工具 · " + tool, "present" if shutil.which(tool) else "missing", "Optional branch prerequisite; executable presence only.", False)
        if name in _CONTEXT:
            check("task-environment", "任务环境", "unknown", _CONTEXT[name])
        if not minimum and name not in _TOOLS and name not in _PACKAGES and name not in _GUIDANCE:
            check("runtime-profile", "运行依赖", "unknown", "This entry has no application-owned runtime check profile; read its reviewed requirements before use.")
        for index, requirement in enumerate(exact.get("optionalRequirements", [])):
            check("optional-branch:" + str(index), "可选能力", "unknown", requirement, False)
    check("host", "宿主发现", "unknown", "Current session exposure and host discovery have not been verified.", False)
    check("effectiveness", "任务效果", "unknown", "No task execution, smoke test or paired evaluation was performed.", False)
    allowed = not blockers
    needs_setup = any(item["required"] and item["status"] in ("missing", "unknown") for item in checks)
    status = "installed_unverified" if installed else "blocked" if blockers else "needs_setup" if needs_setup else "ready_for_install"
    return {"status": status, "installAllowed": allowed and not installed, "checks": checks, "blockers": blockers, "hostStatus": "unverified", "effectivenessStatus": "untested", "environmentScope": "local_backend_only", "closureStatus": "blocked" if blockers else "reviewed_static_references_only" if pin_matches else "unknown", "nextAction": "Verify host discovery, prepare the authorized execution environment and run a separately authorized task check." if installed else "Resolve the listed package or policy blockers before installation." if blockers else "Install files only; prepare the missing or unverified task prerequisites before use." if needs_setup else "Review and install the pinned complete directory, then verify host discovery and task behavior."}
