"""Trusted-directory and non-executing deployment fixtures; no live upstreams."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

from skill_editor.catalog import CatalogService
from skill_editor.core import EditorError, SkillStore


COMMIT = "a" * 40
SKILL = b"---\nname: frontend-design\ndescription: A fixture\n---\nUse the bundled references.\n"


def entry(*, decision="candidate_for_evaluation", references=None):
    return {
        "id": "anthropics/skills:skills/frontend-design", "name": "frontend-design",
        "title": "页面设计", "category": "design", "functionTags": ["design", "app"],
        "useCases": ["create"], "source": {
            "repo": "anthropics/skills", "path": "skills/frontend-design/SKILL.md",
            "ref": COMMIT, "blobSha": hashlib.sha1(b"blob " + str(len(SKILL)).encode() + b"\0" + SKILL).hexdigest(),
            "url": "https://github.com/anthropics/skills/blob/" + COMMIT + "/skills/frontend-design/SKILL.md",
        }, "license": {"spdx": "MIT"}, "requirements": [], "optionalRequirements": [],
        "decision": decision, "runtimeReferences": references or [], "closureStatus": "not_resolved",
        "evidence": {"sourceReviewed": True, "taskEffectivenessTestedHere": False},
    }


def archive(files):
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as handle:
        for name, raw in files.items():
            member = tarfile.TarInfo("repo/" + name)
            member.size = len(raw)
            handle.addfile(member, io.BytesIO(raw))
    return output.getvalue()


class CuratedTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.project = Path(self.temporary.name).resolve()
        self.personal = self.project / "personal"
        self.personal.mkdir()
        self.seed_path = self.project / "data/curated-skills.json"
        self.seed_path.parent.mkdir()
        self.items = [entry()]
        self.save_seed()
        self.store = SkillStore(self.project, self.personal, self.project / "plugins")
        self.catalog = CatalogService(self.store)
        self.files = {"skills/frontend-design/SKILL.md": SKILL, "skills/frontend-design/references/detail.md": b"Reference", "LICENSE": b"MIT"}
        self.network = patch.object(self.catalog, "_fetch", side_effect=self.fetch)
        self.network.start()
        self.refresh = patch.object(self.store, "refresh_inventory", return_value={"skills": []})
        self.refresh.start()

    def tearDown(self):
        self.network.stop()
        self.refresh.stop()
        self.temporary.cleanup()

    def save_seed(self):
        self.seed_path.write_text(json.dumps({
            "schemaVersion": 1, "researchedOn": "2026-11-08", "entries": self.items,
            "functionCategories": [{"id": "design", "label": "界面设计"}, {"id": "app", "label": "应用开发"}],
            "useCases": [{"id": "create", "label": "创建"}],
        }))

    def fetch(self, url, *, limit):
        if "codeload.github.com" in url:
            return archive(self.files)
        if "/commits/" in url:
            return json.dumps({"sha": COMMIT}).encode()
        return json.dumps({"default_branch": "main", "license": {"spdx_id": "MIT"}}).encode()

    def inspect(self, **extra):
        return self.catalog.inspect({"curatedId": self.items[0]["id"], "operation": "install", **extra})

    def test_directory_filters_function_tags_and_chinese_query_without_upstream(self):
        with patch.object(self.catalog, "_fetch", side_effect=AssertionError("directory must be offline")):
            result = self.catalog.curated("页面", "app", "create")
        self.assertEqual([item["id"] for item in result["entries"]], [self.items[0]["id"]])
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["researchedOn"], "2026-11-08")
        self.assertFalse(result["entries"][0]["evidence"]["taskEffectivenessTestedHere"])
        self.assertEqual(self.catalog.curated("absent")["entries"], [])

    def test_missing_or_malformed_catalog_is_explicit_and_does_not_trust_client_entry(self):
        self.seed_path.unlink()
        with self.assertRaises(EditorError) as caught:
            self.catalog.curated()
        self.assertEqual(caught.exception.status, 503)
        self.seed_path.write_text('{"schemaVersion":1,"entries":[]}')
        with self.assertRaises(EditorError):
            self.inspect(source=self.items[0]["source"])

    def test_inspect_uses_exact_trusted_pin_and_complete_subtree(self):
        preview = self.inspect(url="https://github.com/evil/repo", path="other", ref="main")
        self.assertEqual(preview["source"]["repo"], "anthropics/skills")
        self.assertEqual(preview["source"]["commit"], COMMIT)
        self.assertEqual({item["path"] for item in preview["files"]}, {"SKILL.md", "references/detail.md"})
        self.assertEqual(preview["deployment"]["status"], "ready_for_install")
        self.assertEqual(preview["deployment"]["hostStatus"], "unverified")
        self.assertFalse((self.personal / "frontend-design").exists())

    def test_curated_commit_resolution_and_git_blob_mismatch_never_prepare_install(self):
        with patch.object(self.catalog, "_api", side_effect=[{"default_branch": "main"}, {"sha": "b" * 40}]):
            with self.assertRaises(EditorError):
                self.inspect()
        self.files["skills/frontend-design/SKILL.md"] = SKILL + b"changed"
        with self.assertRaises(EditorError) as caught:
            self.inspect()
        self.assertEqual(caught.exception.status, 409)
        self.assertFalse((self.personal / "frontend-design").exists())

    def test_policy_and_cross_component_blocks_cannot_be_bypassed_by_payload(self):
        for decision, references in (
            ("hold", []), ("candidate_core_only", []),
            ("candidate_for_evaluation", [{"kind": "plugin_agent", "path": "agents/helper.md", "condition": "selected branch"}]),
        ):
            with self.subTest(decision=decision, references=references):
                self.items = [entry(decision=decision, references=references)]
                self.save_seed()
                preview = self.inspect(decision="candidate_for_evaluation", runtimeReferences=[])
                self.assertEqual(preview["deployment"]["status"], "blocked")
                with self.assertRaises(EditorError):
                    self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "deployment": {"installAllowed": True}, "allowIncomplete": True})
                arbitrary = self.catalog.inspect({"url": "https://github.com/anthropics/skills", "path": "skills/frontend-design", "ref": "main"})
                self.assertFalse(arbitrary["deployment"]["installAllowed"])
        self.assertFalse((self.personal / "frontend-design").exists())

    def test_preflight_recomputes_environment_without_rehashing_or_exposing_paths(self):
        self.items[0]["requirements"] = ["Python", "openpyxl"]
        self.items[0]["name"] = "xlsx"
        self.items[0]["id"] = "anthropics/skills:skills/xlsx"
        self.items[0]["source"]["path"] = "skills/xlsx/SKILL.md"
        raw = SKILL.replace(b"name: frontend-design", b"name: xlsx")
        self.items[0]["source"]["blobSha"] = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        self.files = {"skills/xlsx/SKILL.md": raw}
        self.save_seed()
        with patch("skill_editor.curated.metadata.version", side_effect=ModuleNotFoundError), patch("skill_editor.curated.shutil.which", return_value=None):
            preview = self.inspect()
            response = self.catalog.preflight({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(response["previewSha"], preview["previewSha"])
        self.assertEqual(response["deployment"]["status"], "needs_setup")
        self.assertTrue(response["deployment"]["installAllowed"])
        self.assertTrue(any(item["status"] == "missing" and item["required"] for item in response["deployment"]["checks"]))
        with patch("skill_editor.curated.metadata.version", return_value="1.0"), patch("skill_editor.curated.shutil.which", return_value="/secret/private/tool"):
            refreshed = self.catalog.preflight({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertNotIn("/secret/private", json.dumps(refreshed))
        with self.assertRaises(EditorError):
            self.catalog.preflight({"candidateId": preview["candidateId"], "previewSha": "changed"})

    def test_install_rechecks_changed_policy_and_reports_only_file_installation(self):
        preview = self.inspect()
        self.items[0]["decision"] = "hold"
        self.save_seed()
        with self.assertRaises(EditorError):
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.items[0]["decision"] = "candidate_for_evaluation"
        self.save_seed()
        result = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertTrue((self.personal / "frontend-design/references/detail.md").exists())
        self.assertEqual(result["deployment"]["status"], "installed_unverified")
        self.assertEqual(result["deployment"]["hostStatus"], "unverified")
        self.assertEqual(result["deployment"]["effectivenessStatus"], "untested")

    def test_prepared_reviewed_candidate_fails_closed_if_seed_disappears(self):
        preview = self.inspect()
        self.seed_path.unlink()
        with self.assertRaises(EditorError):
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertFalse((self.personal / "frontend-design").exists())

    def test_repo_case_git_suffix_and_explicit_root_cannot_bypass_held_scope(self):
        self.items[0]["decision"] = "hold"
        self.save_seed()
        direct = self.catalog.inspect({"url": "https://github.com/ANTHROPICS/SKILLS.git", "path": "skills/frontend-design/SKILL.md", "ref": COMMIT})
        self.assertFalse(direct["deployment"]["installAllowed"])
        self.files["SKILL.md"] = b"---\nname: collection\ndescription: Root entry\n---\nRoot\n"
        ancestor = self.catalog.inspect({"url": "https://github.com/anthropics/skills", "path": "", "ref": COMMIT})
        self.assertFalse(ancestor["deployment"]["installAllowed"])
        with self.assertRaises(EditorError):
            self.catalog.install({"candidateId": ancestor["candidateId"], "previewSha": ancestor["previewSha"]})
        self.assertFalse((self.personal / "collection").exists())

    def test_unreviewed_ref_does_not_inherit_review_or_lose_policy(self):
        with patch.object(self.catalog, "_api", side_effect=[{"default_branch": "main", "license": {"spdx_id": "Apache-2.0"}}, {"sha": "b" * 40}]):
            preview = self.catalog.inspect({"url": "https://github.com/anthropics/skills", "path": "skills/frontend-design", "ref": "main"})
        self.assertEqual(preview["deployment"]["status"], "needs_setup")
        self.assertFalse(preview["source"]["reviewedPinMatched"])
        self.assertNotIn("licenseEvidence", preview["source"])
        self.assertEqual(preview["source"]["licenseScope"], "repository_metadata_only")

    def test_entry_license_evidence_survives_install_and_backup_restore(self):
        self.items[0]["license"] = {"spdx": "Apache-2.0", "evidence_url": "https://github.com/anthropics/skills/blob/" + COMMIT + "/skills/frontend-design/LICENSE.txt"}
        self.files["skills/frontend-design/LICENSE.txt"] = b"Selected Apache license"
        self.files["NOTICE"] = b"Preserve upstream notice"
        self.save_seed()
        preview = self.inspect()
        self.assertEqual(preview["source"]["license"], "Apache-2.0")
        self.assertEqual(preview["source"]["repositoryLicense"], "MIT")
        installed = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        provenance = self.project / ".state/catalog/candidates" / preview["candidateId"] / "provenance"
        self.assertEqual((provenance / "evidence/skills/frontend-design/LICENSE.txt").read_bytes(), b"Selected Apache license")
        self.assertEqual((provenance / "NOTICE").read_bytes(), b"Preserve upstream notice")
        self.assertEqual(installed["source"]["provenance"]["candidateId"], preview["candidateId"])
        update = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        changed = self.catalog.install({"candidateId": update["candidateId"], "previewSha": update["previewSha"], "baselineSha": update["baselineSha"]})
        restore = self.catalog.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": changed["backupVersionId"]})
        self.seed_path.unlink()
        restore_check = self.catalog.preflight({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"]})
        self.assertTrue(restore_check["deployment"]["installAllowed"])
        self.assertEqual(restore_check["deployment"]["environmentScope"], "restore_only")
        result = self.catalog.rollback({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"], "managedId": installed["managedId"], "versionId": changed["backupVersionId"], "baselineSha": restore["baselineSha"]})
        self.assertEqual(result["source"]["licenseEvidence"]["commit"], COMMIT)
        self.assertEqual(result["source"]["licenseScope"], "reviewed_entry_at_selected_commit")
        self.assertEqual(result["source"]["provenance"]["candidateId"], preview["candidateId"])
        self.assertEqual(result["deployment"]["status"], "installed_unverified")

    def test_tampered_preserved_license_provenance_blocks_adoption(self):
        preview = self.inspect()
        evidence = self.project / ".state/catalog/candidates" / preview["candidateId"] / "provenance/LICENSE"
        evidence.write_bytes(b"changed license")
        with self.assertRaises(EditorError) as caught:
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(caught.exception.status, 409)
        self.assertFalse((self.personal / "frontend-design").exists())

    def test_preflight_rejects_a_tampered_resource_tree(self):
        preview = self.inspect()
        candidate = self.project / ".state/catalog/candidates" / preview["candidateId"]
        (candidate / "tree/references/detail.md").write_bytes(b"replaced")
        with self.assertRaises(EditorError) as caught:
            self.catalog.preflight({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(caught.exception.status, 409)

    def test_changed_trusted_pin_or_identity_rejects_an_old_reviewed_preview(self):
        for change in ("ref", "blobSha", "id", "scope", "removed"):
            with self.subTest(change=change):
                self.items = [entry()]
                self.save_seed()
                preview = self.inspect()
                if change in ("ref", "blobSha"):
                    self.items[0]["source"][change] = "b" * 40
                elif change == "id":
                    self.items[0]["id"] = "renamed-entry"
                elif change == "scope":
                    self.items[0]["source"]["path"] = "skills/moved/SKILL.md"
                else:
                    self.items = []
                self.save_seed()
                preflight = self.catalog.preflight({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
                self.assertFalse(preflight["deployment"]["installAllowed"])
                with self.assertRaises(EditorError):
                    self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertFalse((self.personal / "frontend-design").exists())

    def test_curated_entry_name_must_match_observed_frontmatter(self):
        self.items[0]["name"] = "other-skill"
        self.save_seed()
        with self.assertRaises(EditorError) as caught:
            self.inspect()
        self.assertEqual(caught.exception.status, 409)

    def test_curated_tracking_detects_new_commit_without_relabeling_it_reviewed(self):
        upstream = {"commit": COMMIT, "files": dict(self.files)}

        def fetch(url, *, limit):
            if "codeload.github.com" in url:
                return archive(upstream["files"])
            if "/commits/" in url:
                ref = url.rsplit("/", 1)[-1]
                return json.dumps({"sha": upstream["commit"] if ref == "main" else COMMIT}).encode()
            return json.dumps({"default_branch": "main", "license": {"spdx_id": "MIT"}}).encode()

        with patch.object(self.catalog, "_fetch", side_effect=fetch):
            preview = self.inspect()
            self.assertEqual(preview["source"]["ref"], COMMIT)
            self.assertEqual(preview["source"]["trackingRef"], "main")
            installed = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
            upstream["commit"] = "b" * 40
            revised = SKILL + b"New upstream workflow.\n"
            upstream["files"]["skills/frontend-design/SKILL.md"] = revised
            update_info = self.catalog.updates()["installs"][0]
            self.assertTrue(update_info["hasUpdate"])
            self.assertEqual(update_info["latestCommit"], "b" * 40)
            update = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
            self.assertEqual(update["source"]["ref"], COMMIT)
            self.assertEqual(update["source"]["trackingRef"], "main")
            self.assertEqual(update["source"]["resolvedRef"], "main")
            self.assertEqual(update["source"]["commit"], "b" * 40)
            self.assertFalse(update["source"]["reviewedPinMatched"])
            self.assertEqual(update["deployment"]["status"], "needs_setup")
            self.assertNotIn("licenseEvidence", update["source"])
            self.items[0]["decision"] = "hold"
            self.save_seed()
            checked = self.catalog.preflight({"candidateId": update["candidateId"], "previewSha": update["previewSha"]})
            self.assertFalse(checked["deployment"]["installAllowed"])
            self.items[0]["decision"] = "candidate_for_evaluation"
            self.save_seed()
            updated = self.catalog.install({"candidateId": update["candidateId"], "previewSha": update["previewSha"], "baselineSha": update["baselineSha"]})
            self.assertEqual((self.personal / "frontend-design/SKILL.md").read_bytes(), revised)
            restore = self.catalog.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
            reverted = self.catalog.rollback({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"], "managedId": installed["managedId"], "versionId": updated["backupVersionId"], "baselineSha": restore["baselineSha"]})
            self.assertEqual((self.personal / "frontend-design/SKILL.md").read_bytes(), SKILL)
            self.assertEqual(reverted["source"]["ref"], COMMIT)
            self.assertEqual(reverted["source"]["commit"], COMMIT)
            self.assertEqual(reverted["source"]["trackingRef"], "main")
            self.assertTrue(reverted["source"]["reviewedPinMatched"])

    def test_unavailable_default_branch_leaves_curated_pin_untracked(self):
        with patch.object(self.catalog, "_api", side_effect=[{"license": {"spdx_id": "MIT"}}, {"sha": COMMIT}]):
            preview = self.inspect()
        self.assertEqual(preview["source"]["ref"], COMMIT)
        self.assertNotIn("trackingRef", preview["source"])

    def test_explicit_generic_pin_does_not_gain_curated_branch_tracking(self):
        preview = self.catalog.inspect({"url": "https://github.com/anthropics/skills", "path": "skills/frontend-design", "ref": COMMIT})
        self.assertNotIn("trackingRef", preview["source"])

    def test_changed_reviewed_license_evidence_invalidates_prepared_preview(self):
        preview = self.inspect()
        self.items[0]["license"] = {"spdx": "Apache-2.0"}
        self.save_seed()
        result = self.catalog.preflight({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertFalse(result["deployment"]["installAllowed"])
        with self.assertRaises(EditorError):
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})

    def test_unreferenced_docs_and_fenced_examples_do_not_block_package(self):
        raw = SKILL + b"```markdown\n[example](scripts/not-a-runtime-dependency.py)\n```\n[broken remote](http://[)\n"
        self.files["skills/frontend-design/SKILL.md"] = raw
        self.files["skills/frontend-design/evals/README.md"] = b"[example](../../examples/missing.py)"
        self.items[0]["source"]["blobSha"] = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        self.save_seed()
        preview = self.inspect()
        self.assertTrue(preview["deployment"]["installAllowed"])

    def test_referenced_runtime_document_is_checked_transitively(self):
        raw = SKILL + b"Read [runtime guide](references/detail.md).\n"
        self.files["skills/frontend-design/SKILL.md"] = raw
        self.files["skills/frontend-design/references/detail.md"] = b"[required script](../scripts/missing.py)"
        self.items[0]["source"]["blobSha"] = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        self.save_seed()
        preview = self.inspect()
        self.assertFalse(preview["deployment"]["installAllowed"])

    def test_missing_explicit_bundled_resource_blocks_install(self):
        self.files["skills/frontend-design/SKILL.md"] = SKILL + b"Read [required helper](scripts/missing.py).\n"
        self.items[0]["source"]["blobSha"] = hashlib.sha1(b"blob " + str(len(self.files["skills/frontend-design/SKILL.md"])).encode() + b"\0" + self.files["skills/frontend-design/SKILL.md"]).hexdigest()
        self.save_seed()
        preview = self.inspect()
        self.assertFalse(preview["deployment"]["installAllowed"])
        self.assertTrue(any("scripts/missing.py" in detail for detail in preview["deployment"]["blockers"]))


if __name__ == "__main__":
    unittest.main()
