"""Task selection behavior; run only in an authorized CPU environment."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from skill_editor.core import EditorError, SkillStore, digest
from skill_editor.selection import build_plan
from skill_editor.tasks import EngineStore


class SelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name).resolve()
        self.personal = self.project / "personal"
        self.personal.mkdir()
        (self.project / "data").mkdir()
        self.records = []
        self.store = SkillStore(self.project, self.personal)

    def tearDown(self):
        self.temp.cleanup()

    def add(self, name, description, source="personal", cache=False, body="Use only for the described task.", **metadata):
        identifier = name + "-" + str(len(self.records))
        path = self.personal / identifier / "SKILL.md"
        path.parent.mkdir()
        content = "---\nname: " + name + "\ndescription: " + json.dumps(description) + "\n---\n" + body
        path.write_text(content, encoding="utf-8")
        record = {"id": identifier, "name": name, "description": description, "source": source, "path": str(path), **metadata}
        self.records.append((record, cache))
        (self.project / "data/inventory.json").write_text(json.dumps({"skills": [item for item, cached in self.records if not cached], "cachedSkills": [item for item, cached in self.records if cached]}), encoding="utf-8")
        return record, content

    def test_simple_answer_needs_no_specialized_skill(self):
        self.add("frontend-design", "Build and design websites")
        plan = build_plan(self.store, "Explain what a Python list is.")
        self.assertEqual(plan["method"], "local_rules")
        self.assertEqual(plan["combo"], [])
        self.assertEqual(plan["gaps"], [])
        self.assertEqual(plan["requirements"][0]["coverage"], "builtin")

    def test_labelled_basic_arithmetic_is_ready_without_loading_skills(self):
        for request in ("[验收] 计算17+25，不使用技能。", "【验收】计算17+25，不使用技能。", "17 × 25", "18/3 - 2"):
            with self.subTest(request=request):
                task = EngineStore(self.store, auto_sync=False).create({"request": request})
                self.assertEqual(task["status"], "ready")
                self.assertEqual(task["plan"]["combo"], [])
                self.assertEqual(task["plan"]["gaps"], [])
                self.assertEqual(task["plan"]["clarifications"], [])
                self.assertEqual(task["plan"]["requirements"][0]["coverage"], "builtin")

    def test_no_skill_instruction_does_not_make_an_unknown_labelled_task_ready(self):
        requests = [
            "[验收] 用我想要的方式把事情办好，不使用技能。",
            "[验收] 改善未知流程，然后计算17+25，不使用技能。",
            "[验收] 17+__import__('os').system('unexpected')，不使用技能。",
        ]
        for request in requests:
            with self.subTest(request=request):
                task = EngineStore(self.store, auto_sync=False).create({"request": request})
                self.assertEqual(task["status"], "needs_clarification")
                self.assertTrue(task["plan"]["gaps"])

    def test_website_for_research_is_not_a_literature_search(self):
        designer, content = self.add("frontend-design", "Design and build intentional frontend websites.")
        self.add("literature-review", "Research and synthesize scientific literature.")
        self.add("paper-reviewer", "Review research papers and acceptance risk.")
        plan = build_plan(self.store, "给研究项目做一个深色、简约、清楚的网页。")
        self.assertEqual([item["id"] for item in plan["combo"]], [designer["id"]])
        self.assertEqual(plan["combo"][0]["sha"], digest(content))
        self.assertEqual(plan["combo"][0]["path"], designer["path"])
        self.assertNotIn("research", [item["capability"] for item in plan["requirements"]])

    def test_independent_deliverables_keep_distinct_capabilities(self):
        self.add("paper-reviewer", "Review research papers and assess evidence.")
        self.add("paper-writing", "Write and revise research manuscripts.")
        plan = build_plan(self.store, "Review the paper's evidence and then rewrite its introduction.")
        self.assertEqual({item["name"] for item in plan["combo"]}, {"paper-reviewer", "paper-writing"})
        self.assertEqual(len({item["role"] for item in plan["combo"]}), 2)

    def test_one_design_lead_and_complementary_explicit_check(self):
        self.add("frontend-design", "Build and design frontend websites.")
        self.add("ui-ux-pro-max", "Design frontend websites and interfaces.")
        self.add("web-design-guidelines", "Review web UI accessibility and interface guidelines.")
        plan = build_plan(self.store, "Build a website and check its accessibility.")
        self.assertEqual(len(plan["combo"]), 2)
        self.assertIn("web-design-guidelines", [item["name"] for item in plan["combo"]])
        self.assertTrue(plan["exclusions"])

    def test_missing_capability_is_a_gap_and_vague_goal_needs_clarification(self):
        self.assertTrue(build_plan(self.store, "Create a PowerPoint presentation for my talk.")["gaps"])
        self.assertTrue(build_plan(self.store, "Make it better.")["clarifications"])

    def test_saved_snapshot_and_cache_are_not_live_availability(self):
        self.add("frontend-design", "Build frontend websites.", sessionAvailable=True, sessionCatalogMembership="listed-in-snapshot", sessionCatalogAt="2026-01-01")
        plan = build_plan(self.store, "Build a website.")
        self.assertEqual(plan["combo"][0]["availability"], "unknown")
        self.assertIn("snapshot", plan["combo"][0]["availabilityEvidence"])

    def test_personal_variant_wins_over_cache_and_full_sources_are_bounded(self):
        self.add("frontend-design", "Build frontend websites.", source="plugin", cache=True)
        chosen, _ = self.add("frontend-design", "Build frontend websites.")
        for index in range(25):
            self.add("unrelated-" + str(index), "Search medical citations.")
        with patch.object(self.store, "inventory", side_effect=AssertionError("No full inventory hydration")), patch.object(self.store, "_read_content", wraps=self.store._read_content) as reader:
            plan = build_plan(self.store, "Build a website.")
        self.assertEqual(plan["combo"][0]["id"], chosen["id"])
        self.assertLessEqual(reader.call_count, 12)

    def test_current_source_scope_overrides_stale_description(self):
        record, _ = self.add("frontend-design", "Build frontend websites.")
        Path(record["path"]).write_text('---\nname: frontend-design\ndescription: "Only write research manuscripts."\n---\nPaper writing only.\n')
        self.assertTrue(build_plan(self.store, "Build a website.")["gaps"])

    def test_negative_task_instruction_does_not_create_capability(self):
        self.add("paper-reviewer", "Review research papers.")
        self.add("paper-writing", "Write and revise research manuscripts.")
        plan = build_plan(self.store, "Rewrite the paper introduction. Do not review acceptance risk.")
        self.assertEqual([item["name"] for item in plan["combo"]], ["paper-writing"])

    def test_semantic_mode_is_explicit_and_requires_configuration(self):
        with patch.dict("os.environ", {}, clear=True), self.assertRaises(EditorError) as caught:
            build_plan(self.store, "Build a website.", mode="semantic")
        self.assertEqual(caught.exception.status, 503)

    def test_semantic_unknown_ids_are_rejected(self):
        self.add("frontend-design", "Build frontend websites.")
        with patch.dict("os.environ", {"OPENROUTER_API_KEY": "fixture-secret", "OPENROUTER_MODEL": "fixture/model"}), patch("skill_editor.selection._semantic_response", return_value={"summary": "Plan", "assignments": [{"requirementId": "web_design", "skillId": "invented", "reason": "Fake"}], "gaps": [], "clarifications": []}):
            with self.assertRaises(EditorError):
                build_plan(self.store, "Build a website.", mode="semantic")

    def test_editor_only_notes_never_enter_plan_or_model_request(self):
        self.add("frontend-design", "Build frontend websites.")
        with patch.object(self.store, "intent", side_effect=AssertionError("Task planner must not read editor-only intent")):
            plan = build_plan(self.store, "Build a website.")
        self.assertNotIn("editorOnlyIntent", json.dumps(plan))

    def test_local_plan_never_calls_network_even_with_credentials(self):
        with patch.dict("os.environ", {"OPENROUTER_API_KEY": "fixture-secret", "OPENROUTER_MODEL": "fixture/model"}), patch("skill_editor.selection.urllib.request.build_opener", side_effect=AssertionError("Unexpected network")):
            self.assertEqual(build_plan(self.store, "Explain a list.")["method"], "local_rules")

    def test_semantic_plan_must_cover_every_required_capability(self):
        self.add("frontend-design", "Build frontend websites.")
        response = {"summary": "An incomplete plan", "assignments": [], "gaps": [], "clarifications": []}
        with patch.dict("os.environ", {"OPENROUTER_API_KEY": "fixture-secret", "OPENROUTER_MODEL": "fixture/model"}), patch("skill_editor.selection._semantic_response", return_value=response):
            with self.assertRaises(EditorError) as caught:
                build_plan(self.store, "Build a website.", mode="semantic")
        self.assertEqual(caught.exception.status, 502)

    def test_semantic_assignment_retains_server_owned_source_identity(self):
        record, content = self.add("frontend-design", "Build frontend websites.")
        response = {"summary": "Build the requested website", "assignments": [{"requirementId": "web_design", "skillId": record["id"], "reason": "The verified source covers frontend website design"}], "gaps": [], "clarifications": []}
        with patch.dict("os.environ", {"OPENROUTER_API_KEY": "fixture-secret", "OPENROUTER_MODEL": "fixture/model"}), patch("skill_editor.selection._semantic_response", return_value=response):
            plan = build_plan(self.store, "Build a website.", mode="semantic")
        self.assertEqual(plan["method"], "openrouter_semantic")
        self.assertEqual(plan["combo"][0]["sha"], digest(content))
        self.assertEqual(plan["combo"][0]["path"], record["path"])

    def test_explicit_skill_choice_and_no_skill_instruction_are_preserved(self):
        self.add("frontend-design", "Build frontend websites.")
        requested, _ = self.add("ui-ux-pro-max", "Design frontend websites and interfaces.")
        plan = build_plan(self.store, "Build a website using ui-ux-pro-max.")
        self.assertEqual([item["id"] for item in plan["combo"]], [requested["id"]])
        skipped = build_plan(self.store, "Build a website without any skills.")
        self.assertEqual(skipped["combo"], [])
        self.assertEqual(skipped["gaps"], [])

    def test_requested_artifacts_keep_their_own_specialist_role(self):
        cases = [
            ("Create a Word document.", "documents", "Create docx and Word documents.", "document"),
            ("Create a PDF report.", "pdf", "Create and inspect PDF files.", "pdf"),
            ("Create a PowerPoint presentation.", "presentations", "Create PowerPoint presentations and slides.", "presentation"),
            ("Analyze a CSV spreadsheet.", "spreadsheets", "Analyze spreadsheet files including CSV and XLSX.", "data"),
            ("Plot a scientific figure of accuracy.", "scientific-visualization", "Create scientific figures, plots and charts.", "visualization"),
            ("Schedule a meeting in my calendar.", "scheduling", "Schedule calendar events.", "scheduling"),
            ("Organize files in Downloads.", "file-organizer", "Organize files and folders.", "files"),
            ("Find recent papers on memory representation.", "literature-review", "Research scientific literature.", "research"),
        ]
        for request, name, description, capability in cases:
            with self.subTest(capability=capability):
                record, _ = self.add(name, description)
                plan = build_plan(self.store, request)
                self.assertIn(record["id"], [item["id"] for item in plan["combo"]])
                self.assertIn(capability, [item["capability"] for item in plan["requirements"]])

    def test_seven_distinct_required_skills_preserve_coverage_but_cannot_be_ready(self):
        specialists = [
            ("documents", "Create docx and Word documents."),
            ("pdf", "Create and inspect PDF files."),
            ("presentations", "Create PowerPoint presentations and slides."),
            ("spreadsheets", "Analyze spreadsheet files including CSV and XLSX."),
            ("scientific-visualization", "Create scientific figures, plots and charts."),
            ("scheduling", "Schedule calendar events."),
            ("file-organizer", "Organize files and folders."),
        ]
        expected = {self.add(name, description)[0]["id"] for name, description in specialists}
        request = "Create a Word document, a PDF report, and a PowerPoint presentation. Analyze a CSV spreadsheet and plot a scientific figure. Schedule a meeting in my calendar and organize files in Downloads."
        task = EngineStore(self.store, auto_sync=False).create({"request": request})
        self.assertEqual(task["status"], "needs_clarification")
        self.assertEqual({item["id"] for item in task["plan"]["combo"]}, expected)
        self.assertEqual(len(task["plan"]["requirements"]), 7)
        self.assertTrue(all(item["coverage"] == "skill" for item in task["plan"]["requirements"]))
        self.assertEqual(task["plan"]["gaps"], [])
        self.assertTrue(any("6" in question for question in task["plan"]["clarifications"]))


if __name__ == "__main__":
    unittest.main()
