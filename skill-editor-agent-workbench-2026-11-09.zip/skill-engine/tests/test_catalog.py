"""Catalog fixtures do not contact the network or execute downloaded content."""
import io
import json
import os
from pathlib import Path
import tarfile
import tempfile
import threading
import time
import unittest
import urllib.parse
from unittest.mock import patch

from skill_editor.catalog import CatalogService, _NoRedirect, _write as catalog_write
from skill_editor.core import EditorError, SkillStore


COMMIT = "a" * 40
NEXT_COMMIT = "b" * 40
SKILL = b'---\nname: sample\ndescription: "A fixture skill"\n---\nDo not execute this text.\n'


def archive(files=None, special=None):
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as handle:
        for path, raw in (files or {"skills/sample/SKILL.md": SKILL, "skills/sample/scripts/run.py": b"raise RuntimeError('never execute')\n", "LICENSE": b"MIT fixture"}).items():
            member = tarfile.TarInfo("repo-commit/" + path)
            member.size = len(raw)
            member.mode = 0o644
            handle.addfile(member, io.BytesIO(raw))
        if special:
            handle.addfile(special)
    return output.getvalue()


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.project = Path(self.temporary.name).resolve()
        self.personal = self.project / "personal"
        self.personal.mkdir()
        self.store = SkillStore(self.project, self.personal, self.project / "plugins")
        self.catalog = CatalogService(self.store)
        self.commit = COMMIT
        self.tar = archive()
        self.calls = []
        self.network = patch.object(self.catalog, "_fetch", side_effect=self.fetch)
        self.network.start()
        self.refresh = patch.object(self.store, "refresh_inventory", return_value={"skills": []})
        self.refresh.start()

    def tearDown(self):
        self.network.stop()
        self.refresh.stop()
        self.temporary.cleanup()

    def fetch(self, url, *, limit):
        self.calls.append(url)
        if "codeload.github.com" in url:
            return self.tar
        if "skills.sh/api/v1/skills/search?" in url:
            return json.dumps({"data": [{"id": "owner/repo/sample", "slug": "sample", "name": "Sample", "source": "owner/repo", "installs": 3842, "sourceType": "github"}], "searchType": "fuzzy"}).encode()
        if "/search/repositories?" in url:
            return json.dumps({"items": [{"full_name": "owner/repo", "html_url": "https://github.com/owner/repo", "name": "repo", "description": "Agent skills fixture", "stargazers_count": 52, "updated_at": "2026-11-01T00:00:00Z", "license": {"spdx_id": "MIT"}, "default_branch": "main"}]}).encode()
        if "/commits/" in url:
            return json.dumps({"sha": self.commit}).encode()
        return json.dumps({"default_branch": "main", "license": {"spdx_id": "MIT"}}).encode()

    def preview(self, **extra):
        return self.catalog.inspect({"url": "https://github.com/owner/repo", "path": "skills/sample", **extra})

    def install(self):
        preview = self.preview()
        return self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})

    def local_source(self, *, source="personal", editable=True, relative="library-sample", identifier="personal-sample"):
        package = self.personal / relative
        package.mkdir(parents=True)
        (package / "SKILL.md").write_bytes(SKILL)
        (package / "scripts").mkdir(mode=0o750)
        (package / "scripts/run.py").write_bytes(b"raise RuntimeError('never execute')\n")
        (package / "scripts/run.py").chmod(0o751)
        (package / "assets").mkdir(mode=0o700)
        (package / "assets/data.bin").write_bytes(b"\x00\xfffixture")
        (package / "empty").mkdir(mode=0o711)
        package.chmod(0o750)
        self.store.inventory_path.parent.mkdir(exist_ok=True)
        self.store.inventory_path.write_text(json.dumps({"skills": [{"id": identifier, "source": source, "editable": editable, "path": str(package / "SKILL.md")}]}))
        return package

    def local_catalog(self):
        target = self.project / "agent-skills"
        catalog = CatalogService(self.store, target_root=target, state_namespace="local-agent")
        return catalog, target

    @staticmethod
    def adopt_local(catalog, preview):
        return catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "baselineSha": preview["baselineSha"]})

    def test_local_adoption_preserves_resources_modes_and_original_library(self):
        package = self.local_source()
        catalog, target = self.local_catalog()
        before = {path.relative_to(package).as_posix(): (path.read_bytes() if path.is_file() else None, path.stat().st_mode & 0o777) for path in package.rglob("*")}
        with patch.object(catalog, "_fetch", side_effect=AssertionError("Local adoption must not access the network")):
            preview = catalog.inspect_local({"skillId": "personal-sample"})
            self.assertEqual(preview["operation"], "install")
            self.assertEqual(preview["source"]["kind"], "local")
            self.assertEqual(preview["source"]["label"], "个人技能库")
            self.assertEqual(preview["source"]["skillId"], "personal-sample")
            self.assertEqual(preview["source"]["path"], str(package))
            self.assertEqual(preview["source"]["revision"], preview["treeSha"])
            self.assertTrue({"repo", "commit", "url", "ref"}.isdisjoint(preview["source"]))
            installed = self.adopt_local(catalog, preview)
        self.assertTrue(installed["installed"])
        self.assertEqual((target / "sample/assets/data.bin").read_bytes(), b"\x00\xfffixture")
        self.assertEqual((target / "sample/scripts/run.py").stat().st_mode & 0o777, 0o751)
        self.assertEqual((target / "sample/scripts").stat().st_mode & 0o777, 0o750)
        self.assertEqual((target / "sample/empty").stat().st_mode & 0o777, 0o711)
        self.assertEqual((target / "sample").stat().st_mode & 0o777, 0o750)
        self.assertEqual({path.relative_to(package).as_posix(): (path.read_bytes() if path.is_file() else None, path.stat().st_mode & 0o777) for path in package.rglob("*")}, before)

    def test_local_source_changes_block_preflight_and_adoption(self):
        package = self.local_source()
        catalog, target = self.local_catalog()
        preview = catalog.inspect_local({"skillId": "personal-sample"})
        (package / "assets/data.bin").write_bytes(b"changed source resource")
        for action in (catalog.preflight, catalog.install):
            with self.subTest(action=action.__name__), self.assertRaises(EditorError) as caught:
                action({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
            self.assertEqual(caught.exception.status, 409)
        self.assertFalse((target / "sample").exists())

    def test_replaced_local_source_identity_cannot_reuse_a_prepared_preview(self):
        package = self.local_source()
        catalog, target = self.local_catalog()
        preview = catalog.inspect_local({"skillId": "personal-sample"})
        preserved = self.personal / "preserved-original"
        package.rename(preserved)
        replacement = self.local_source()
        self.assertEqual(replacement, package)
        with self.assertRaises(EditorError) as caught:
            self.adopt_local(catalog, preview)
        self.assertEqual(caught.exception.status, 409)
        self.assertFalse((target / "sample").exists())

    def test_repointed_inventory_id_cannot_reuse_a_prepared_local_preview(self):
        self.local_source()
        catalog, target = self.local_catalog()
        preview = catalog.inspect_local({"skillId": "personal-sample"})
        self.local_source(relative="other-library-sample")
        with self.assertRaises(EditorError) as caught:
            catalog.preflight({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(caught.exception.status, 409)
        self.assertFalse((target / "sample").exists())

    def test_local_revision_detects_mode_and_empty_directory_changes(self):
        package = self.local_source()
        catalog, _ = self.local_catalog()
        first = catalog.inspect_local({"skillId": "personal-sample"})
        (package / "scripts/run.py").chmod(0o700)
        mode_changed = catalog.inspect_local({"skillId": "personal-sample"})
        self.assertNotEqual(first["source"]["revision"], mode_changed["source"]["revision"])
        (package / "another-empty").mkdir()
        directory_changed = catalog.inspect_local({"skillId": "personal-sample"})
        self.assertNotEqual(mode_changed["source"]["revision"], directory_changed["source"]["revision"])

    def test_local_adoption_rejects_system_plugin_and_nested_personal_inventory_entries(self):
        catalog, target = self.local_catalog()
        for source, editable, relative in (("system", False, ".system/system-sample"), ("plugin", False, "plugin-sample"), ("personal", True, "nested/sample")):
            with self.subTest(source=source, relative=relative):
                self.local_source(source=source, editable=editable, relative=relative)
                with self.assertRaises(EditorError) as caught:
                    catalog.inspect_local({"skillId": "personal-sample"})
                self.assertEqual(caught.exception.status, 403)
        self.assertFalse(target.exists())

    def test_local_adoption_never_overwrites_an_existing_target_name(self):
        self.local_source()
        catalog, target = self.local_catalog()
        (target / "sample").mkdir(parents=True)
        (target / "sample/SKILL.md").write_bytes(b"existing Agent configuration")
        preview = catalog.inspect_local({"skillId": "personal-sample"})
        self.assertEqual(preview["targetStatus"], "name_conflict")
        with self.assertRaises(EditorError):
            self.adopt_local(catalog, preview)
        self.assertEqual((target / "sample/SKILL.md").read_bytes(), b"existing Agent configuration")

    def test_local_update_discovery_and_rollback_use_local_revisions_without_network(self):
        package = self.local_source()
        catalog, target = self.local_catalog()
        with patch.object(catalog, "_fetch", side_effect=AssertionError("Local versions must not access GitHub")):
            first = catalog.inspect_local({"skillId": "personal-sample"})
            installed = self.adopt_local(catalog, first)
            current = catalog.updates()["installs"][0]
            self.assertEqual(current["status"], "current")
            self.assertEqual(current["currentRevision"], first["source"]["revision"])
            self.assertIsNone(current["currentCommit"])
            (package / "SKILL.md").write_bytes(SKILL + b"Updated local library instructions.\n")
            (package / "scripts/run.py").chmod(0o700)
            update_status = catalog.updates()["installs"][0]
            self.assertEqual(update_status["status"], "update_available")
            self.assertTrue(update_status["hasUpdate"])
            self.assertNotEqual(update_status["latestRevision"], first["source"]["revision"])
            update = catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
            updated = self.adopt_local(catalog, update)
            self.assertEqual((target / "sample/SKILL.md").read_bytes(), SKILL + b"Updated local library instructions.\n")
            self.assertEqual((target / "sample/scripts/run.py").stat().st_mode & 0o777, 0o700)
            restore = catalog.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
            catalog.rollback({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"], "managedId": installed["managedId"], "versionId": updated["backupVersionId"], "baselineSha": restore["baselineSha"]})
        self.assertEqual((target / "sample/SKILL.md").read_bytes(), SKILL)
        self.assertEqual((target / "sample/scripts/run.py").stat().st_mode & 0o777, 0o751)
        self.assertEqual((package / "SKILL.md").read_bytes(), SKILL + b"Updated local library instructions.\n")

    def test_missing_local_source_is_unavailable_but_backup_can_still_be_restored(self):
        package = self.local_source()
        catalog, target = self.local_catalog()
        first = catalog.inspect_local({"skillId": "personal-sample"})
        installed = self.adopt_local(catalog, first)
        (package / "SKILL.md").write_bytes(SKILL + b"Updated local source.\n")
        update = catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        updated = self.adopt_local(catalog, update)
        package.rename(self.personal / "source-no-longer-at-recorded-path")
        with patch.object(catalog, "_fetch", side_effect=AssertionError("Missing local source must not trigger GitHub")):
            status = catalog.updates()["installs"][0]
            self.assertEqual(status["status"], "unavailable")
            self.assertIsNone(status["hasUpdate"])
            self.assertIn("preserv", status["warning"].lower())
            with self.assertRaises(EditorError):
                catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
            restore = catalog.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
            catalog.preflight({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"]})
            catalog.rollback({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"], "managedId": installed["managedId"], "versionId": updated["backupVersionId"], "baselineSha": restore["baselineSha"]})
        self.assertEqual((target / "sample/SKILL.md").read_bytes(), SKILL)

    def test_local_editor_intents_never_enter_a_runtime_candidate(self):
        package = self.local_source()
        private = package / ".skill-editor/intents"
        private.mkdir(parents=True)
        (private / "purpose.md").write_text("private editor purpose")
        catalog, target = self.local_catalog()
        with self.assertRaises(EditorError) as caught:
            catalog.inspect_local({"skillId": "personal-sample"})
        self.assertEqual(caught.exception.status, 403)
        self.assertEqual(list(catalog.candidates.iterdir()), [])
        self.assertFalse(target.exists())

    def test_repository_popularity_is_labelled_and_search_is_cached(self):
        result = self.catalog.search("markdown skills")
        self.assertEqual(result["results"][0]["stars"], 52)
        self.assertEqual(result["results"][0]["starsScope"], "repository")
        self.assertNotIn("quality", result["results"][0])
        self.assertTrue(self.catalog.search("markdown skills")["cached"])
        self.assertEqual(len(self.calls), 1)

    def test_agent_target_has_independent_candidates_and_managed_versions(self):
        target = self.project / "claude-skills"
        scoped = CatalogService(self.store, target_root=target, state_namespace="claude-code")
        with patch.object(scoped, "_fetch", side_effect=self.fetch):
            preview = scoped.inspect({"url": "https://github.com/owner/repo", "path": "skills/sample"})
            self.assertEqual(preview["targetPath"], str(target / "sample"))
            with self.assertRaises(EditorError):
                self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
            result = scoped.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
            self.assertTrue(result["installed"])
            self.assertEqual((target / "sample/SKILL.md").read_bytes(), SKILL)
            self.assertFalse((self.personal / "sample").exists())
            self.assertEqual(self.catalog.updates()["installs"], [])
            self.assertEqual(len(scoped.updates()["installs"]), 1)
            self.assertEqual(scoped.config()["installRoot"], str(target))

    def test_agent_target_preserves_existing_unmanaged_directory(self):
        target = self.project / "claude-skills"
        (target / "sample").mkdir(parents=True)
        (target / "sample/SKILL.md").write_text("personal custom instructions")
        scoped = CatalogService(self.store, target_root=target, state_namespace="claude-code")
        with patch.object(scoped, "_fetch", side_effect=self.fetch):
            preview = scoped.inspect({"url": "https://github.com/owner/repo", "path": "skills/sample"})
            self.assertEqual(preview["targetStatus"], "name_conflict")
            with self.assertRaises(EditorError):
                scoped.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual((target / "sample/SKILL.md").read_text(), "personal custom instructions")

    def test_agent_update_and_restore_keep_target_history_separate(self):
        target = self.project / "cursor-skills"
        scoped = CatalogService(self.store, target_root=target, state_namespace="cursor")
        changed = SKILL + b"\nUpdated fixture instructions.\n"
        with patch.object(scoped, "_fetch", side_effect=self.fetch):
            first = scoped.inspect({"url": "https://github.com/owner/repo", "path": "skills/sample"})
            installed = scoped.install({"candidateId": first["candidateId"], "previewSha": first["previewSha"]})
            self.commit = NEXT_COMMIT
            self.tar = archive({"skills/sample/SKILL.md": changed, "skills/sample/scripts/run.py": b"# new fixture\n", "LICENSE": b"MIT fixture"})
            update = scoped.inspect({"operation": "update", "managedId": installed["managedId"]})
            updated = scoped.install({"candidateId": update["candidateId"], "previewSha": update["previewSha"], "baselineSha": update["baselineSha"]})
            self.assertEqual((target / "sample/SKILL.md").read_bytes(), changed)
            restored = scoped.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
            scoped.rollback({"candidateId": restored["candidateId"], "previewSha": restored["previewSha"], "baselineSha": restored["baselineSha"], "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
        self.assertEqual((target / "sample/SKILL.md").read_bytes(), SKILL)
        self.assertFalse((self.personal / "sample").exists())
        self.assertEqual(self.catalog.updates()["installs"], [])

    def test_agent_target_requires_separate_state_and_rejects_unsafe_namespace(self):
        for namespace in (None, "../catalog", "", "claude/code"):
            with self.subTest(namespace=namespace), self.assertRaises(EditorError):
                CatalogService(self.store, target_root=self.project / "target", state_namespace=namespace)

    def test_default_catalog_keeps_original_state_and_target(self):
        self.assertEqual(self.catalog.root, self.project / ".state/catalog")
        self.assertEqual(self.catalog.config()["installRoot"], str(self.personal))

    def test_agent_namespace_cannot_recover_or_install_into_a_different_root(self):
        first = self.project / "first-target"
        second = self.project / "second-target"
        scoped = CatalogService(self.store, target_root=first, state_namespace="claude-code")
        with patch.object(scoped, "_fetch", side_effect=self.fetch):
            scoped.inspect({"url": "https://github.com/owner/repo", "path": "skills/sample"})
        with self.assertRaises(EditorError) as caught:
            CatalogService(self.store, target_root=second, state_namespace="claude-code")
        self.assertEqual(caught.exception.status, 409)
        self.assertFalse(second.exists())

    def test_prepared_candidate_is_bound_to_its_original_target_path(self):
        preview = self.preview()
        self.catalog.install_root = self.project / "other-target"
        with self.assertRaises(EditorError) as caught:
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(caught.exception.status, 409)
        self.assertFalse((self.project / "other-target/sample").exists())

    def test_agent_target_creation_never_follows_a_replaced_parent(self):
        parent = self.project / "agent-parent"
        parent.mkdir()
        outside = self.project / "outside"
        outside.mkdir()
        scoped = CatalogService(self.store, target_root=parent / "skills", state_namespace="claude-code")
        with patch.object(scoped, "_fetch", side_effect=self.fetch):
            preview = scoped.inspect({"url": "https://github.com/owner/repo", "path": "skills/sample"})
        original_mkdir = os.mkdir
        replaced = False

        def replace_parent(path, *args, **kwargs):
            nonlocal replaced
            if path == "skills" and kwargs.get("dir_fd") is not None and not replaced:
                replaced = True
                parent.rename(self.project / "saved-agent-parent")
                parent.symlink_to(outside, target_is_directory=True)
            return original_mkdir(path, *args, **kwargs)

        with patch("skill_editor.catalog.os.mkdir", side_effect=replace_parent), self.assertRaises(EditorError):
            scoped.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertTrue(replaced)
        self.assertFalse((outside / "skills").exists())

    def test_github_search_scopes_skill_metadata_and_omits_generic_frontend_repositories(self):
        fixtures = {"items": [
            {"full_name": "marmelab/react-admin", "name": "react-admin", "description": "A frontend framework for building applications", "stargazers_count": 25000},
            {"full_name": "publisher/frontend-design-skills", "name": "frontend-design-skills", "description": "Agent skills for frontend design", "stargazers_count": 12},
        ]}
        with patch.object(self.catalog, "_api", return_value=fixtures) as search_api:
            result = self.catalog.search("frontend-design")
        params = urllib.parse.parse_qs(urllib.parse.urlsplit(search_api.call_args.args[0]).query)
        self.assertEqual(params["q"], ["frontend-design skills in:name,description"])
        self.assertEqual([item["repo"] for item in result["results"]], ["publisher/frontend-design-skills"])
        self.assertEqual(result["effectiveQuery"], params["q"][0])
        self.assertEqual(result["scope"]["fields"], ["name", "description"])
        self.assertFalse(result["scope"]["skillPresenceVerified"])
        self.assertEqual(result["results"][0]["candidateKind"], "repository")

    def test_scoped_github_search_does_not_reuse_old_unscoped_cache(self):
        from skill_editor.catalog import _canonical, _digest
        legacy_cache = self.project / ".state/catalog/search" / (_digest(_canonical(["github", "frontend-design", "stars"])) + ".json")
        legacy_cache.write_text(json.dumps({"cachedAt": time.time(), "result": {"results": [{"repo": "marmelab/react-admin"}], "query": "frontend-design"}}))
        result = self.catalog.search("frontend-design")
        self.assertFalse(result["cached"])
        self.assertTrue(self.calls)
        self.assertIn("in:name,description", result["effectiveQuery"])

    def test_skills_api_without_config_is_honestly_unavailable(self):
        with patch.dict("os.environ", {}, clear=True):
            self.assertFalse(self.catalog.config()["sources"]["skills"]["available"])
            with self.assertRaises(EditorError) as caught:
                self.catalog.search("markdown", source="skills")
        self.assertEqual(caught.exception.status, 503)
        self.assertEqual(self.calls, [])

    def test_formal_skills_search_labels_skill_installs_and_does_not_invent_path(self):
        with patch.dict("os.environ", {"VERCEL_OIDC_TOKEN": "fixture-opaque-token"}, clear=True):
            self.assertTrue(self.catalog.config()["sources"]["skills"]["available"])
            result = self.catalog.search("sample", source="skills")
        skill = result["results"][0]
        self.assertEqual(skill["installs"], 3842)
        self.assertEqual(skill["installsScope"], "skill")
        self.assertIsNone(skill["stars"])
        self.assertIsNone(skill["path"])
        self.assertEqual(skill["slugHint"], "sample")
        self.assertIn("/api/v1/skills/search?", self.calls[0])
        self.assertNotIn("fixture-opaque-token", json.dumps(result))

    def test_collection_requires_actual_skill_path(self):
        self.tar = archive({"one/SKILL.md": SKILL, "two/SKILL.md": SKILL})
        result = self.catalog.inspect({"url": "https://github.com/owner/repo"})
        self.assertEqual(result["status"], "selection_required")
        self.assertEqual(result["paths"], ["one/SKILL.md", "two/SKILL.md"])
        self.assertFalse((self.personal / "sample").exists())

    def test_root_skill_plus_collection_is_not_implicitly_installed_whole(self):
        self.tar = archive({"SKILL.md": SKILL, "one/SKILL.md": SKILL})
        result = self.catalog.inspect({"url": "https://github.com/owner/repo"})
        self.assertEqual(result["status"], "selection_required")
        self.assertEqual(result["paths"], ["SKILL.md", "one/SKILL.md"])

    def test_complete_subtree_is_pinned_and_inspection_never_installs(self):
        preview = self.preview()
        self.assertEqual(preview["source"]["commit"], COMMIT)
        self.assertEqual(preview["source"]["path"], "skills/sample")
        self.assertEqual({item["path"] for item in preview["files"]}, {"SKILL.md", "scripts/run.py"})
        self.assertIn(COMMIT, self.calls[-1])
        self.assertFalse((self.personal / "sample").exists())
        self.assertIn("requirements", preview)

    def test_arbitrary_github_package_is_installable_data_with_unknown_readiness(self):
        preview = self.preview()
        self.assertEqual(preview["deployment"]["status"], "needs_setup")
        self.assertTrue(preview["deployment"]["installAllowed"])
        self.assertEqual(preview["deployment"]["closureStatus"], "unknown")
        preflight = self.catalog.preflight({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(preflight["deployment"]["effectivenessStatus"], "untested")
        installed = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(installed["deployment"]["status"], "installed_unverified")
        self.assertEqual(installed["deployment"]["hostStatus"], "unverified")

    def test_ref_with_slash_is_resolved_as_one_exact_ref(self):
        preview = self.preview(ref="release/one")
        self.assertEqual(preview["source"]["ref"], "release/one")
        self.assertTrue(any("/commits/release%2Fone" in url for url in self.calls))

    def test_tree_url_requires_explicit_branch_ref_and_supports_slash_ref(self):
        with self.assertRaises(EditorError):
            self.catalog.inspect({"url": "https://github.com/owner/repo/tree/release/one/skills/sample"})
        preview = self.catalog.inspect({"url": "https://github.com/owner/repo/tree/release/one/skills/sample", "ref": "release/one"})
        self.assertEqual(preview["source"]["ref"], "release/one")
        self.assertEqual(preview["source"]["path"], "skills/sample")

    def test_install_copies_resources_and_preserves_external_provenance(self):
        result = self.install()
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), SKILL)
        self.assertTrue((self.personal / "sample/scripts/run.py").is_file())
        self.assertFalse((self.personal / "sample/.skill-editor").exists())
        self.assertTrue(result["sync"]["ok"])
        managed = self.catalog.updates()["installs"][0]
        self.assertEqual(managed["source"]["license"], "MIT")
        self.assertTrue(list((self.project / ".state/catalog/candidates").glob("*/provenance/LICENSE")))

    def test_same_name_is_not_overwritten(self):
        (self.personal / "sample").mkdir()
        (self.personal / "sample/SKILL.md").write_bytes(b"personal content")
        preview = self.preview()
        with self.assertRaises(EditorError) as caught:
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(caught.exception.status, 409)
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), b"personal content")

    def test_preview_hash_and_candidate_content_are_both_checked(self):
        preview = self.preview()
        with self.assertRaises(EditorError):
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": "wrong"})
        candidate = self.project / ".state/catalog/candidates" / preview["candidateId"] / "tree/SKILL.md"
        candidate.write_bytes(SKILL + b"changed")
        with self.assertRaises(EditorError) as caught:
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertEqual(caught.exception.status, 409)
        self.assertFalse((self.personal / "sample").exists())

    def test_update_is_selected_full_version_with_stale_guard_and_rollback(self):
        installed = self.install()
        self.commit = NEXT_COMMIT
        revised = SKILL + b"New workflow\n"
        self.tar = archive({"skills/sample/SKILL.md": revised, "skills/sample/reference.txt": b"new reference"})
        updates = self.catalog.updates()["installs"][0]
        self.assertTrue(updates["hasUpdate"])
        preview = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        self.assertIn("New workflow", preview["diff"])
        updated = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "baselineSha": preview["baselineSha"]})
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), revised)
        self.assertFalse((self.personal / "sample/scripts/run.py").exists())
        versions = self.catalog.updates()["installs"][0]["versions"]
        restore = self.catalog.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": versions[0]["versionId"]})
        self.assertIn("New workflow", restore["diff"])
        reverted = self.catalog.rollback({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"], "managedId": installed["managedId"], "versionId": versions[0]["versionId"], "baselineSha": updated["currentSha"]})
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), SKILL)
        self.assertTrue((self.personal / "sample/scripts/run.py").is_file())
        self.assertTrue(reverted["backupVersionId"])
        self.assertEqual(len(self.catalog.updates()["installs"][0]["versions"]), 2)

    def test_local_resource_edit_blocks_prepared_update_and_stale_rollback(self):
        installed = self.install()
        preview = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        path = self.personal / "sample/scripts/run.py"
        path.write_bytes(b"local resource")
        with self.assertRaises(EditorError) as caught:
            self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "baselineSha": preview["baselineSha"]})
        self.assertEqual(caught.exception.status, 409)
        self.assertEqual(path.read_bytes(), b"local resource")
        with self.assertRaises(EditorError):
            self.catalog.rollback({"managedId": installed["managedId"], "versionId": "missing", "baselineSha": installed["currentSha"]})

    def test_stale_selected_rollback_preserves_current_resource(self):
        installed = self.install()
        self.commit = NEXT_COMMIT
        self.tar = archive({"skills/sample/SKILL.md": SKILL + b"new workflow\n"})
        preview = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        updated = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "baselineSha": preview["baselineSha"]})
        restore = self.catalog.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
        current = self.personal / "sample/SKILL.md"
        current.write_bytes(SKILL + b"new personal change\n")
        with self.assertRaises(EditorError) as caught:
            self.catalog.rollback({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"], "managedId": installed["managedId"], "versionId": updated["backupVersionId"], "baselineSha": restore["baselineSha"]})
        self.assertEqual(caught.exception.status, 409)
        self.assertEqual(current.read_bytes(), SKILL + b"new personal change\n")

    def test_backup_and_rollback_preserve_executable_mode_and_empty_directories(self):
        installed = self.install()
        script = self.personal / "sample/scripts/run.py"
        script.chmod(0o755)
        (self.personal / "sample/empty").mkdir(mode=0o700)
        preview = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        updated = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "baselineSha": preview["baselineSha"]})
        restore = self.catalog.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
        self.catalog.rollback({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"], "managedId": installed["managedId"], "versionId": updated["backupVersionId"], "baselineSha": restore["baselineSha"]})
        self.assertEqual(script.stat().st_mode & 0o777, 0o755)
        self.assertTrue((self.personal / "sample/empty").is_dir())

    def test_locally_modified_update_preview_reports_changes_explicitly(self):
        installed = self.install()
        (self.personal / "sample/SKILL.md").write_bytes(SKILL + b"Arthur's customization\n")
        preview = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        self.assertEqual(preview["targetStatus"], "locally_modified")
        self.assertTrue(any("local" in warning.lower() for warning in preview["warnings"]))

    def test_index_failure_reports_successful_write_without_claiming_sync(self):
        self.store.refresh_inventory.side_effect = EditorError("fixture inventory unavailable")
        result = self.install()
        self.assertTrue(result["installed"])
        self.assertFalse(result["sync"]["ok"])
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), SKILL)

    def test_traversal_and_editor_intents_are_rejected(self):
        for path in ("../outside", "/absolute", "skills/../sample", ".system/sample"):
            with self.subTest(path=path), self.assertRaises(EditorError):
                self.preview(path=path)
        self.tar = archive({"skills/sample/SKILL.md": SKILL, "skills/sample/.skill-editor/intents/private.md": b"editor private"})
        with self.assertRaises(EditorError):
            self.preview()

    def test_archive_traversal_symlinks_hardlinks_and_special_entries_rejected(self):
        for kind in (tarfile.SYMTYPE, tarfile.LNKTYPE, tarfile.FIFOTYPE):
            member = tarfile.TarInfo("repo-commit/skills/sample/evil")
            member.type = kind
            member.linkname = "../../outside"
            self.tar = archive(special=member)
            with self.subTest(kind=kind), self.assertRaises(EditorError):
                self.preview()
        self.tar = archive({"../outside": b"bad", "skills/sample/SKILL.md": SKILL})
        with self.assertRaises(EditorError):
            self.preview()

    def test_explicit_subtree_skips_unrelated_links_without_copying_or_following_them(self):
        for kind in (tarfile.SYMTYPE, tarfile.LNKTYPE):
            member = tarfile.TarInfo("repo-commit/CLAUDE.md")
            member.type = kind
            member.linkname = "AGENTS.md"
            self.tar = archive(special=member)
            with self.subTest(kind=kind):
                preview = self.preview()
                self.assertEqual({item["path"] for item in preview["files"]}, {"SKILL.md", "scripts/run.py"})
                skipped = preview["source"]["skippedArchiveLinks"]
                self.assertEqual([entry["path"] for entry in skipped], ["CLAUDE.md"])
                self.assertTrue(any("link" in warning.lower() and "outside" in warning.lower() for warning in preview["warnings"]))
                staged = self.project / ".state/catalog/candidates" / preview["candidateId"] / "tree"
                self.assertFalse((staged / "CLAUDE.md").exists())
                self.assertEqual((staged / "SKILL.md").read_bytes(), SKILL)
        self.assertFalse((self.personal / "sample").exists())

    def test_links_inside_selected_subtree_or_its_ancestors_are_rejected(self):
        for kind in (tarfile.SYMTYPE, tarfile.LNKTYPE):
            for path in ("skills/sample/linked.md", "skills/sample", "skills"):
                member = tarfile.TarInfo("repo-commit/" + path)
                member.type = kind
                member.linkname = "unrelated"
                self.tar = archive(special=member)
                with self.subTest(kind=kind, path=path), self.assertRaises(EditorError) as caught:
                    self.preview()
                self.assertEqual(caught.exception.status, 403)

    def test_explicit_root_install_still_rejects_all_links(self):
        member = tarfile.TarInfo("repo-commit/CLAUDE.md")
        member.type = tarfile.SYMTYPE
        member.linkname = "AGENTS.md"
        self.tar = archive({"SKILL.md": SKILL}, special=member)
        with self.assertRaises(EditorError) as caught:
            self.catalog.inspect({"url": "https://github.com/owner/repo", "path": "SKILL.md"})
        self.assertEqual(caught.exception.status, 403)

    def test_unspecified_path_with_links_requires_actual_regular_skill_selection(self):
        member = tarfile.TarInfo("repo-commit/CLAUDE.md")
        member.type = tarfile.SYMTYPE
        member.linkname = "AGENTS.md"
        self.tar = archive({"SKILL.md": SKILL}, special=member)
        result = self.catalog.inspect({"url": "https://github.com/owner/repo"})
        self.assertEqual(result["status"], "selection_required")
        self.assertEqual(result["paths"], ["SKILL.md"])
        self.assertNotIn("candidateId", result)

    def test_unrelated_links_do_not_relax_traversal_or_other_special_entry_checks(self):
        traversal = tarfile.TarInfo("repo-commit/../CLAUDE.md")
        traversal.type = tarfile.SYMTYPE
        traversal.linkname = "AGENTS.md"
        self.tar = archive(special=traversal)
        with self.assertRaises(EditorError) as caught:
            self.preview()
        self.assertEqual(caught.exception.status, 403)
        special = tarfile.TarInfo("repo-commit/unrelated.fifo")
        special.type = tarfile.FIFOTYPE
        self.tar = archive(special=special)
        with self.assertRaises(EditorError) as caught:
            self.preview()
        self.assertEqual(caught.exception.status, 403)

    def test_case_colliding_archive_ancestors_are_rejected(self):
        self.tar = archive({"skills/sample/SKILL.md": SKILL, "skills/sample/Reference/a.txt": b"a", "skills/sample/reference/b.txt": b"b"})
        with self.assertRaises(EditorError):
            self.preview()

    def test_oversized_expansion_and_member_count_are_bounded(self):
        with patch("skill_editor.catalog.MAX_TOTAL", 100), patch("skill_editor.catalog.MAX_FILES", 1):
            with self.assertRaises(EditorError) as caught:
                self.preview()
        self.assertEqual(caught.exception.status, 413)

    def test_oversized_files_and_unsafe_targets_rejected(self):
        self.tar = archive({"skills/sample/SKILL.md": SKILL, "skills/sample/huge": b"x" * 2_000_001})
        with self.assertRaises(EditorError) as caught:
            self.preview()
        self.assertEqual(caught.exception.status, 413)
        self.tar = archive()
        other = self.project / "other"
        other.mkdir()
        self.personal.rmdir()
        self.personal.symlink_to(other, target_is_directory=True)
        with self.assertRaises(EditorError):
            self.preview()

    def test_non_github_credential_and_query_urls_rejected_before_network(self):
        for url in ("http://github.com/owner/repo", "https://user:secret@github.com/owner/repo", "https://github.com.evil/owner/repo", "https://github.com/owner/repo?token=secret"):
            with self.subTest(url=url), self.assertRaises(EditorError):
                self.catalog.inspect({"url": url})
        self.assertEqual(self.calls, [])

    def test_redirects_are_rejected_without_forwarding_credentials(self):
        from urllib.request import Request
        with self.assertRaises(EditorError):
            _NoRedirect().redirect_request(Request("https://api.github.com/repos/o/r", headers={"Authorization": "Bearer secret"}), None, 302, "Moved", {}, "https://evil.example/steal")

    def test_real_adapter_scopes_authorization_to_each_official_host(self):
        self.network.stop()
        for host, expected in (("api.github.com", "Bearer github-fixture"), ("codeload.github.com", None), ("skills.sh", "Bearer oidc-fixture")):
            url = "https://" + host + "/fixture"
            with patch.dict("os.environ", {"GITHUB_TOKEN": "github-fixture", "VERCEL_OIDC_TOKEN": "oidc-fixture"}, clear=True), patch("skill_editor.catalog.urllib.request.build_opener") as factory:
                response = factory.return_value.open.return_value.__enter__.return_value
                response.geturl.return_value = url
                response.headers = {"Content-Length": "2"}
                response.read.return_value = b"{}"
                self.assertEqual(self.catalog._fetch(url, limit=100), b"{}")
                request = factory.return_value.open.call_args.args[0]
                self.assertEqual(request.get_header("Authorization"), expected)

    def test_concurrent_new_installs_cannot_replace_same_name(self):
        previews = [self.preview(), self.preview()]
        gate = threading.Barrier(2)
        outcomes = []
        def adopt(preview):
            gate.wait(timeout=5)
            try:
                self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
                outcomes.append("installed")
            except EditorError as error:
                outcomes.append(error.status)
        threads = [threading.Thread(target=adopt, args=(preview,)) for preview in previews]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=10)
        self.assertCountEqual(outcomes, ["installed", 409])
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), SKILL)

    def test_interrupted_capture_is_restored_on_restart_without_deleting_staged_data(self):
        installed = self.install()
        transaction_id = "c" * 32
        transaction = self.project / ".state/catalog/transactions" / transaction_id
        transaction.mkdir()
        os.rename(self.personal / "sample", transaction / "current")
        (transaction / "stage").mkdir()
        (transaction / "stage/unique.txt").write_text("unique staged data")
        (transaction / "transaction.json").write_text(json.dumps({"name": "sample", "managedId": installed["managedId"], "operation": "update", "baselineSha": installed["currentSha"], "expectedSha": "not-adopted", "status": "prepared"}))
        recovered = CatalogService(self.store)
        self.assertEqual(recovered.config()["recoveryWarnings"], [])
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), SKILL)
        self.assertEqual((transaction / "stage/unique.txt").read_text(), "unique staged data")

    def test_failed_final_journal_then_update_rollback_restart_keeps_committed_install(self):
        def fail_only_final_journal(path, raw):
            if path.name == "transaction.json" and json.loads(raw).get("status") == "committed":
                raise OSError("fixture final journal write failure")
            return catalog_write(path, raw)
        with patch("skill_editor.catalog._write", side_effect=fail_only_final_journal):
            installed = self.install()
        self.assertTrue(installed["installed"])
        self.assertFalse(installed["transaction"]["journalSynced"])
        original_transaction = installed["transaction"]["id"]
        journal_path = self.project / ".state/catalog/transactions" / original_transaction / "transaction.json"
        self.assertEqual(json.loads(journal_path.read_bytes())["status"], "prepared")
        self.commit = NEXT_COMMIT
        self.tar = archive({"skills/sample/SKILL.md": SKILL + b"updated workflow\n"})
        preview = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        updated = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "baselineSha": preview["baselineSha"]})
        restore = self.catalog.inspect({"operation": "rollback", "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
        self.catalog.rollback({"candidateId": restore["candidateId"], "previewSha": restore["previewSha"], "managedId": installed["managedId"], "versionId": updated["backupVersionId"], "baselineSha": restore["baselineSha"]})
        recovered = CatalogService(self.store)
        self.assertEqual(recovered.config()["recoveryWarnings"], [])
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), SKILL)
        manifest = json.loads((self.project / ".state/catalog/managed.json").read_bytes())
        self.assertIn(original_transaction, manifest["installs"][installed["managedId"]]["committedTransactionIds"])
        self.assertEqual(json.loads(journal_path.read_bytes())["status"], "committed")

    def test_crash_after_new_install_reservation_moves_proven_empty_directory_outside_runtime(self):
        preview = self.preview()
        real_rename = os.rename
        def crash_before_stage_adoption(source, destination, **options):
            if source == "stage" and destination == "sample":
                raise SystemExit("fixture process interruption")
            return real_rename(source, destination, **options)
        with patch("skill_editor.catalog.os.rename", side_effect=crash_before_stage_adoption):
            with self.assertRaises(SystemExit):
                self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        reserved = self.personal / "sample"
        original_identity = (reserved.stat().st_dev, reserved.stat().st_ino)
        self.assertEqual(list(reserved.iterdir()), [])
        recovered = CatalogService(self.store)
        self.assertEqual(recovered.config()["recoveryWarnings"], [])
        self.assertFalse(reserved.exists())
        preserved = list((self.project / ".state/catalog/transactions").glob("*/reservation-recovered-*"))
        self.assertEqual(len(preserved), 1)
        self.assertEqual((preserved[0].stat().st_dev, preserved[0].stat().st_ino), original_identity)
        # Recovery frees the name without deleting either the staged skill or reservation.
        installed = self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]})
        self.assertTrue(installed["installed"])

    def test_unproven_empty_reservation_stays_unresolved_instead_of_silently_recovered(self):
        transaction_id = "d" * 32
        transaction = self.project / ".state/catalog/transactions" / transaction_id
        transaction.mkdir()
        reserved = self.personal / "sample"
        reserved.mkdir()
        (transaction / "transaction.json").write_text(json.dumps({"name": "sample", "managedId": "e" * 32, "operation": "install", "baselineSha": None, "expectedSha": "not-adopted", "reservation": {"device": reserved.stat().st_dev, "inode": reserved.stat().st_ino + 1}, "status": "prepared"}))
        recovered = CatalogService(self.store)
        self.assertTrue(recovered.config()["recoveryWarnings"])
        self.assertTrue(reserved.is_dir())
        self.assertEqual(json.loads((transaction / "transaction.json").read_bytes())["status"], "prepared")

    def test_manifest_commit_failure_restores_previous_tree_and_keeps_backup(self):
        installed = self.install()
        self.commit = NEXT_COMMIT
        self.tar = archive({"skills/sample/SKILL.md": SKILL + b"changed"})
        preview = self.catalog.inspect({"operation": "update", "managedId": installed["managedId"]})
        with patch.object(self.catalog, "_save_managed", side_effect=OSError("fixture disk failure")):
            with self.assertRaises(EditorError):
                self.catalog.install({"candidateId": preview["candidateId"], "previewSha": preview["previewSha"], "baselineSha": preview["baselineSha"]})
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), SKILL)
        self.assertTrue(list((self.project / ".state/catalog/backups").glob("*/tree/SKILL.md")))


if __name__ == "__main__":
    unittest.main()
