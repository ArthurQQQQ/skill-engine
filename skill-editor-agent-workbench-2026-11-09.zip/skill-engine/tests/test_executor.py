"""Isolated execution contract tests. Fake CLI only; no model calls."""
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from skill_editor.core import EditorError, SkillStore, digest
from skill_editor.executor import Executor
from skill_editor.tasks import EngineStore


class ExecutorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name).resolve()
        self.personal = self.project / 'personal'
        self.source = self.personal / 'frontend-design' / 'SKILL.md'
        self.source.parent.mkdir(parents=True)
        self.text = '---\nname: frontend-design\ndescription: Design and build clear frontend websites and interfaces.\n---\nDesign the requested interface.\n'
        self.source.write_text(self.text)
        (self.project / 'data').mkdir()
        (self.project / 'data/inventory.json').write_text(json.dumps({'skills': [{
            'id': 'frontend-design', 'name': 'frontend-design', 'description': 'Design and build clear frontend websites and interfaces.',
            'path': str(self.source), 'source': 'personal', 'editable': True, 'sha256': digest(self.text),
        }]}))
        self.store = SkillStore(self.project, self.personal, self.project / 'plugins')
        self.engine = EngineStore(self.store)
        self.executor = Executor(self.engine)
        self.binary = self.project / 'fake-codex'
        self.env = patch.dict(os.environ, {'PATH': os.environ.get('PATH', os.defpath),
            'SKILL_ENGINE_CODEX_BIN': str(self.binary), 'OPENROUTER_API_KEY': 'test-openrouter-key-not-real',
            'OPENROUTER_MODEL': 'example/model', 'SKILL_ENGINE_ALLOW_EXECUTION': '1'}, clear=True)
        self.env.start()
        self._fake()

    def tearDown(self):
        self.executor.close()
        self.env.stop()
        self.temp.cleanup()

    def _fake(self, status='completed', slow=False, structured=True):
        report = {'status': status, 'summary': 'Fake agent result; no model was used.',
                  'artifacts': ['outputs/example.txt'] if status == 'completed' else []}
        lines = [f'#!{sys.executable}', 'import json,sys,time', 'from pathlib import Path',
                 "sys.stdin.read()", "Path('outputs').mkdir(exist_ok=True)",
                 "Path('outputs/example.txt').write_text('verified fixture artifact')",
                 "print(json.dumps({'type':'turn.started'}),flush=True)",
                 "task=json.loads(Path('TASK.json').read_text())",
                 'report='+repr(report),
                 "report['steps']=[{'id':step['id'],'status':"+repr('completed' if status=='completed' else 'blocked')+",'note':'fixture evidence'} for step in task['plan']['steps']]",
                 "print(json.dumps({'type':'item.completed','item':{'type':'agent_message','text':'ENGINE_STEP '+json.dumps({'id':task['plan']['steps'][0]['id'],'status':'running','note':'fixture started'})}}),flush=True)"]
        if slow:
            lines.append('time.sleep(30)')
        lines += [('message=json.dumps(report)' if structured else "message='A turn ended without structured task evidence.'"),
                  "print(json.dumps({'type':'item.completed','item':{'type':'agent_message','text':message}}),flush=True)",
                  "print(json.dumps({'type':'turn.completed','usage':{'input_tokens':1,'output_tokens':1}}),flush=True)"]
        self.binary.write_text('\n'.join(lines) + '\n')
        self.binary.chmod(0o755)

    def task(self):
        task = self.engine.create({'request': '设计一个深色网页'})
        self.assertEqual(task['status'], 'ready')
        return task

    def wait_done(self, task):
        job = self.executor._jobs[task['id']]
        self.assertTrue(job['done'].wait(timeout=5), 'fake executor did not terminate')
        return self.engine.read(task['id'])

    def test_configuration_is_explicit_and_never_discloses_secret(self):
        settings = self.executor.config()
        self.assertTrue(settings['configured'])
        self.assertNotIn('test-openrouter-key-not-real', json.dumps(settings))
        with patch.dict(os.environ, {'SKILL_ENGINE_ALLOW_EXECUTION': '0'}):
            self.assertFalse(self.executor.config()['configured'])
        with patch.dict(os.environ, {'OPENROUTER_MODEL': 'not-a-model-secret'}):
            self.assertIsNone(self.executor.config()['model'])

    def test_closed_executor_rejects_new_run_without_starting_process(self):
        task=self.task()
        self.executor.close()
        with patch('skill_editor.executor.subprocess.Popen',side_effect=AssertionError('closed runner attempted launch')) as launch:
            with self.assertRaises(EditorError) as caught:
                self.executor.start({'taskId':task['id'],'baselineSha':task['sha']})
            self.assertEqual(caught.exception.status,503)
            launch.assert_not_called()
        self.assertEqual(self.engine.read(task['id'])['status'],'ready')

    def test_command_forces_openrouter_without_openai_fallback(self):
        command = self.executor._command(self.project, self.project/'run-result.json')
        self.assertIn('--ignore-user-config', command)
        self.assertIn('--ephemeral', command)
        self.assertIn('workspace-write', command)
        self.assertIn('model_providers.skill_engine_openrouter.base_url="https://openrouter.ai/api/v1"', command)
        self.assertNotIn('--dangerously-bypass-approvals-and-sandbox', command)
        self.assertNotIn('test-openrouter-key-not-real', ' '.join(command))
        with patch.dict(os.environ, {'OPENAI_API_KEY': 'unrelated-secret', 'GITHUB_TOKEN': 'unrelated-github'}):
            env = self.executor._child_environment(self.project)
        self.assertNotIn('OPENAI_API_KEY', env)
        self.assertNotIn('GITHUB_TOKEN', env)

    def test_no_configuration_or_stale_task_never_starts(self):
        task = self.task()
        with patch.dict(os.environ, {'SKILL_ENGINE_ALLOW_EXECUTION': '0'}), patch('skill_editor.executor.subprocess.Popen') as launch:
            with self.assertRaises(EditorError) as caught:
                self.executor.start({'taskId': task['id'], 'baselineSha': task['sha']})
            self.assertEqual(caught.exception.status, 503)
            launch.assert_not_called()
        with patch('skill_editor.executor.subprocess.Popen') as launch:
            with self.assertRaises(EditorError):
                self.executor.start({'taskId': task['id'], 'baselineSha': '0'*64})
            launch.assert_not_called()
        self.assertEqual(self.engine.read(task['id'])['sha'], task['sha'])

    def test_changed_selected_skill_is_rejected_before_launch(self):
        task = self.task()
        self.source.write_text(self.text+'Changed after planning.\n')
        with patch('skill_editor.executor.subprocess.Popen') as launch:
            with self.assertRaises(EditorError) as caught:
                self.executor.start({'taskId': task['id'], 'baselineSha': task['sha']})
            self.assertEqual(caught.exception.status, 409)
            launch.assert_not_called()

    def test_fake_process_returns_real_artifacts_and_preserves_installed_skill(self):
        intent = self.source.parent / '.skill-editor/intents/private.md'
        intent.parent.mkdir(parents=True)
        intent.write_text('PRIVATE_EDITOR_INTENT')
        (self.source.parent/'resources/empty').mkdir(parents=True)
        task = self.task()
        self.executor.start({'taskId': task['id'], 'baselineSha': task['sha']})
        result = self.wait_done(task)
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(result['run']['provider'], 'OpenRouter')
        self.assertEqual(result['run']['outcomeEvidence'], 'agent_reported')
        self.assertTrue(all(step['status']=='completed' for step in result['plan']['steps']))
        self.assertTrue(result['run']['stepEvidence'])
        self.assertIn('step_reported',[event['type'] for event in result['events']])
        names = {a['name'] for a in result['run']['artifacts']}
        self.assertEqual(names, {'result.md', 'outputs/example.txt'})
        artifact = self.executor.artifact(task['id'], 'outputs/example.txt')
        self.assertEqual(artifact['content'], 'verified fixture artifact')
        self.assertEqual(artifact['encoding'], 'utf-8')
        runtime = Path(result['run']['workspace'])/'.agents/skills/frontend-design'
        self.assertFalse((runtime/'.skill-editor').exists())
        self.assertTrue((runtime/'resources/empty').is_dir())
        self.assertEqual((runtime/'SKILL.md').read_text(), self.text)
        self.assertEqual(self.source.read_text(), self.text)
        self.assertNotIn('PRIVATE_EDITOR_INTENT', (Path(result['run']['workspace'])/'TASK.json').read_text())
        with self.assertRaises(EditorError):
            self.executor.artifact(task['id'], '../TASK.json')
        (Path(result['run']['workspace'])/'outputs/example.txt').write_text('changed')
        with self.assertRaises(EditorError) as caught:
            self.executor.artifact(task['id'], 'outputs/example.txt')
        self.assertEqual(caught.exception.status, 409)

    def test_native_turn_end_alone_does_not_claim_task_success(self):
        self._fake(structured=False)
        task = self.task()
        self.executor.start({'taskId': task['id'], 'baselineSha': task['sha']})
        self.assertEqual(self.wait_done(task)['status'], 'failed')

    def test_agent_blocked_outcome_is_not_success(self):
        self._fake(status='blocked')
        task = self.task()
        self.executor.start({'taskId': task['id'], 'baselineSha': task['sha']})
        result = self.wait_done(task)
        self.assertEqual(result['status'], 'needs_clarification')
        self.assertIsNotNone(result['run']['finishedAt'])

    def test_reserved_summary_symlink_never_overwrites_external_file(self):
        outside=self.project/'outside-summary.txt'
        outside.write_text('preserve this fixture')
        original=self.binary.read_text()
        self.binary.write_text(original.replace('sys.stdin.read()',f"Path('result.md').symlink_to({str(outside)!r})\nsys.stdin.read()"))
        task=self.task()
        self.executor.start({'taskId':task['id'],'baselineSha':task['sha']})
        self.assertEqual(self.wait_done(task)['status'],'failed')
        self.assertEqual(outside.read_text(),'preserve this fixture')

    def test_single_active_run_and_cancel_only_own_process(self):
        self._fake(slow=True)
        task = self.task()
        second = self.task()
        self.executor.start({'taskId': task['id'], 'baselineSha': task['sha']})
        with self.assertRaises(EditorError) as caught:
            self.executor.start({'taskId': second['id'], 'baselineSha': second['sha']})
        self.assertEqual(caught.exception.status, 409)
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            current=self.engine.read(task['id'])
            if any(step['status']=='running' for step in current['plan']['steps']):
                break
            time.sleep(.02)
        self.assertTrue(any(step['status']=='running' for step in current['plan']['steps']))
        self.executor.cancel({'taskId': task['id']})
        result=self.wait_done(task)
        self.assertEqual(result['status'], 'cancelled')
        self.assertFalse(any(step['status'] in {'running','queued'} for step in result['plan']['steps']))
        self.assertIn('executor_stop',{e['source'] for e in result['run']['stepEvidence'].values()})
        self.assertEqual(self.engine.read(second['id'])['status'], 'ready')

    def test_symlinked_resource_is_not_bundled(self):
        outside = self.project/'private.txt'
        outside.write_text('not a skill resource')
        (self.source.parent/'leak.txt').symlink_to(outside)
        task = self.task()
        with patch('skill_editor.executor.subprocess.Popen') as launch:
            with self.assertRaises(EditorError):
                self.executor.start({'taskId': task['id'], 'baselineSha': task['sha']})
            launch.assert_not_called()

    def test_late_cancel_cannot_erase_concurrent_result(self):
        task=self.task()
        task=self.engine.update_state(task['id'],{'status':'queued','run':{'id':'run-fixture'}},baselineSha=task['sha'])
        task=self.engine.update_state(task['id'],{'status':'running'})
        done=threading.Event();done.set()
        self.executor._jobs[task['id']]={'runId':'run-fixture','done':done}
        original=self.engine.update_state
        collided=False
        def compete(identifier,patch,event=None,baselineSha=None):
            nonlocal collided
            if not collided:
                collided=True
                original(identifier,{'status':'completed','run':{**self.engine.read(identifier)['run'],'summary':'keep this','artifacts':[{'name':'keep.md'}]}})
            return original(identifier,patch,event,baselineSha=baselineSha)
        with patch.object(self.engine,'update_state',side_effect=compete):
            result=self.executor._patch(task['id'],event={'type':'cancel_requested','message':'cancel'},cancelRequested=True)
        self.assertEqual(result['status'],'completed')
        self.assertEqual(result['run']['summary'],'keep this')
        self.assertEqual(result['run']['artifacts'],[{'name':'keep.md'}])

    def test_aggregate_stream_budget_stops_even_short_valid_lines(self):
        task=self.task()
        with patch('skill_editor.executor.MAX_STREAM_BYTES',100):
            self.executor.start({'taskId':task['id'],'baselineSha':task['sha']})
            result=self.wait_done(task)
        self.assertEqual(result['status'],'failed')
        self.assertIn('累计输出',result['events'][-1]['message'])

    def test_other_executor_cannot_start_or_cancel_an_owned_run(self):
        self._fake(slow=True)
        task=self.task()
        second=self.task()
        self.executor.start({'taskId':task['id'],'baselineSha':task['sha']})
        other=Executor(self.engine)
        try:
            with self.assertRaises(EditorError) as caught:
                other.start({'taskId':second['id'],'baselineSha':second['sha']})
            self.assertEqual(caught.exception.status,409)
            with self.assertRaises(EditorError) as caught:
                other.cancel({'taskId':task['id']})
            self.assertEqual(caught.exception.status,409)
            self.assertIn(self.engine.read(task['id'])['status'],{'queued','running'})
        finally:
            other.close()
        self.executor.cancel({'taskId':task['id']})
        self.wait_done(task)
        self._fake()
        other=Executor(self.engine)
        try:
            other.start({'taskId':second['id'],'baselineSha':second['sha']})
            self.assertTrue(other._jobs[second['id']]['done'].wait(5))
            self.assertEqual(self.engine.read(second['id'])['status'],'completed')
        finally:
            other.close()

    @unittest.skipUnless(os.name=='posix','owned process groups require POSIX')
    def test_descendant_is_stopped_after_leader_exits(self):
        # The child inherits stdout after its parent exits and resists SIGTERM.
        # Its heartbeat must stop before the executor releases its run lease.
        self._fake()
        original=self.binary.read_text()
        child_code=("import signal,time;from pathlib import Path;"
                    "signal.signal(signal.SIGTERM,signal.SIG_IGN);"
                    "p=Path('heartbeat');\nwhile True:p.write_text(str(time.time()));time.sleep(.05)")
        injection=("import subprocess\n"
                   f"child=subprocess.Popen([{sys.executable!r},'-c',{child_code!r}])\n"
                   "Path('child-pid').write_text(str(child.pid))\n"
                   "time.sleep(.2)\n")
        self.binary.write_text(original.replace("sys.stdin.read()",injection+"sys.stdin.read()"))
        task=self.task()
        child_pid=None
        collect=self.executor._collect_artifacts
        def checkpoint(workspace,names):
            before=(workspace/'heartbeat').stat().st_mtime_ns
            time.sleep(.2)
            self.assertEqual((workspace/'heartbeat').stat().st_mtime_ns,before,
                             'runner descendant is still writing during result collection')
            return collect(workspace,names)
        try:
            with patch.object(self.executor,'_collect_artifacts',side_effect=checkpoint):
                self.executor.start({'taskId':task['id'],'baselineSha':task['sha']})
                result=self.wait_done(task)
            workspace=Path(result['run']['workspace'])
            child_pid=int((workspace/'child-pid').read_text())
            self.assertEqual(result['status'],'completed')
            heartbeat=(workspace/'heartbeat').stat().st_mtime_ns
            time.sleep(.2)
            self.assertEqual((workspace/'heartbeat').stat().st_mtime_ns,heartbeat)
        finally:
            if child_pid:
                try:os.kill(child_pid,signal.SIGKILL)
                except ProcessLookupError:pass


if __name__ == '__main__':
    unittest.main()
