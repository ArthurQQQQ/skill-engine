"""HTTP adoption targets, isolated home and fake upstream; never a real Agent."""
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
import io
import json
from pathlib import Path
import tarfile
import tempfile
import threading
import unittest
from unittest.mock import patch

from skill_editor.agents import AgentService
from skill_editor.catalog import CatalogService
from skill_editor.core import SkillStore, digest
from skill_editor.server import make_handler


REMOTE = b'---\nname: sample\ndescription: Remote fixture.\n---\nDo not run this file.\n'
PERSONAL = '---\nname: mine\ndescription: Personal fixture.\n---\nPreserve original.\n'


def upstream_archive(content):
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        for name, data, mode in [("skills/sample/SKILL.md", content, 0o644), ("skills/sample/scripts/run.sh", b"# fixture only\n", 0o755), ("LICENSE", b"MIT fixture", 0o644)]:
            item = tarfile.TarInfo("repo/" + name)
            item.size, item.mode = len(data), mode
            archive.addfile(item, io.BytesIO(data))
    return output.getvalue()


class AgentCatalogHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name).resolve()
        self.home = self.project / "home"
        self.personal = self.home / "personal-skills"
        self.original = self.personal / "mine/SKILL.md"
        self.original.parent.mkdir(parents=True)
        self.original.write_text(PERSONAL)
        (self.project / "data").mkdir()
        (self.project / "data/inventory.json").write_text(json.dumps({"skills": [{"id": "mine", "name": "mine", "path": str(self.original), "source": "personal", "editable": True, "sha256": digest(PERSONAL)}]}))
        self.inventory_before = (self.project / "data/inventory.json").read_bytes()
        self.store = SkillStore(self.project, self.personal, self.project / "plugins")
        self.revision = "a" * 40
        self.remote = REMOTE
        self.calls = []

        def fetch(_catalog, url, *, limit):
            self.calls.append(url)
            if "codeload.github.com" in url:
                return upstream_archive(self.remote)
            if "/commits/" in url:
                return json.dumps({"sha": self.revision}).encode()
            return json.dumps({"default_branch": "main", "license": {"spdx_id": "MIT"}}).encode()

        self.network = patch.object(CatalogService, "_fetch", new=fetch)
        self.network.start()
        self.refresh = patch.object(self.store, "refresh_inventory", return_value={"scope": {}, "scanWarnings": []})
        self.refresh.start()
        with patch("skill_editor.server.AgentService", side_effect=lambda store: AgentService(store, home=self.home)):
            self.handler = make_handler(self.store)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), self.handler)
        self.worker = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.worker.start()

    def tearDown(self):
        self.handler.shutdown_engine()
        self.server.shutdown()
        self.server.server_close()
        self.worker.join(timeout=2)
        self.refresh.stop()
        self.network.stop()
        self.temp.cleanup()

    def request(self, method, path, payload=None):
        connection = HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        try:
            body = json.dumps(payload) if payload is not None else None
            connection.request(method, path, body, {"Content-Type": "application/json"} if body is not None else {})
            response = connection.getresponse()
            return response.status, json.loads(response.read())
        finally:
            connection.close()

    def preview(self, agent_id=None):
        payload = {"url": "https://github.com/publisher/repo", "path": "skills/sample"}
        if agent_id is not None:
            payload["agentId"] = agent_id
        status, result = self.request("POST", "/api/catalog/inspect", payload)
        self.assertEqual(status, 200, result)
        return result

    def adopt(self, preview, agent_id=None, route="install"):
        payload = {"candidateId": preview["candidateId"], "previewSha": preview["previewSha"]}
        if agent_id is not None:
            payload["agentId"] = agent_id
        for key in ("baselineSha", "managedId", "versionId"):
            if preview.get(key) is not None:
                payload[key] = preview[key]
        return self.request("POST", "/api/catalog/" + route, payload)

    def test_four_host_routes_write_only_their_fixed_targets(self):
        targets = {"codex": ".agents/skills", "claude-code": ".claude/skills", "cursor": ".cursor/skills", "opencode": ".config/opencode/skills"}
        for agent_id, relative in targets.items():
            with self.subTest(agent_id=agent_id):
                preview = self.preview(agent_id)
                self.assertEqual(preview["targetPath"], str(self.home / relative / "sample"))
                status, result = self.adopt(preview, agent_id)
                self.assertEqual(status, 200, result)
                self.assertTrue(result["installed"])
                self.assertEqual(result["target"]["agentId"], agent_id)
                self.assertEqual(result["target"]["runtimeStatus"], "unverified")
                self.assertEqual((self.home / relative / "sample/SKILL.md").read_bytes(), REMOTE)
        self.assertFalse((self.personal / "sample").exists())
        self.assertEqual(self.original.read_text(), PERSONAL)
        self.assertEqual((self.project / "data/inventory.json").read_bytes(), self.inventory_before)

    def test_missing_agent_id_preserves_legacy_personal_target(self):
        preview = self.preview()
        status, result = self.adopt(preview)
        self.assertEqual(status, 200, result)
        self.assertEqual((self.personal / "sample/SKILL.md").read_bytes(), REMOTE)
        self.assertNotIn("target", result)

    def test_candidate_cannot_cross_host_route_and_bad_host_never_fetches(self):
        preview = self.preview("codex")
        status, _ = self.adopt(preview, "cursor")
        self.assertIn(status, (400, 404, 409))
        self.assertFalse((self.home / ".cursor/skills/sample").exists())
        self.calls.clear()
        status, _ = self.request("POST", "/api/catalog/inspect", {"agentId": "../../elsewhere", "url": "https://github.com/publisher/repo"})
        self.assertEqual(status, 400)
        self.assertEqual(self.calls, [])

    def test_host_update_and_restore_keep_scope_through_http(self):
        first = self.preview("claude-code")
        status, installed = self.adopt(first, "claude-code")
        self.assertEqual(status, 200, installed)
        self.revision, self.remote = "b" * 40, REMOTE + b"\nNew version.\n"
        status, update = self.request("POST", "/api/catalog/inspect", {"agentId": "claude-code", "operation": "update", "managedId": installed["managedId"]})
        self.assertEqual(status, 200, update)
        status, updated = self.adopt(update, "claude-code")
        self.assertEqual(status, 200, updated)
        status, restore = self.request("POST", "/api/catalog/inspect", {"agentId": "claude-code", "operation": "rollback", "managedId": installed["managedId"], "versionId": updated["backupVersionId"]})
        self.assertEqual(status, 200, restore)
        status, restored = self.adopt(restore, "claude-code", "rollback")
        self.assertEqual(status, 200, restored)
        self.assertEqual((self.home / ".claude/skills/sample/SKILL.md").read_bytes(), REMOTE)
        self.assertEqual(self.original.read_text(), PERSONAL)

    def test_personal_library_joins_the_same_preview_and_adoption_routes(self):
        status, preview = self.request("POST", "/api/catalog/local/inspect", {"skillId": "mine", "agentId": "cursor"})
        self.assertEqual(status, 200, preview)
        self.assertEqual(preview["source"]["kind"], "local")
        status, result = self.adopt(preview, "cursor")
        self.assertEqual(status, 200, result)
        self.assertEqual((self.home / ".cursor/skills/mine/SKILL.md").read_text(), PERSONAL)
        self.assertEqual(self.original.read_text(), PERSONAL)
        self.assertEqual(self.calls, [])

