"""Task-first HTTP integration; isolated roots, network/processes mocked."""
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from skill_editor.core import SkillStore, digest
from skill_editor.server import make_handler


class EngineEndpointTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name).resolve()
        personal = self.project/'personal'
        source = personal/'frontend-design/SKILL.md'
        source.parent.mkdir(parents=True)
        text = '---\nname: frontend-design\ndescription: Build clear frontend websites.\n---\nPreserve task scope.\n'
        source.write_text(text)
        (self.project/'data').mkdir()
        (self.project/'data/inventory.json').write_text(json.dumps({'skills':[{
            'id':'frontend-design','name':'frontend-design','path':str(source),'source':'personal',
            'editable':True,'description':'Build clear frontend websites.','sha256':digest(text),
        }]}))
        (self.project/'web/flow-lab').mkdir(parents=True)
        (self.project/'web/flow-lab/index.html').write_text('TASK ENGINE HOME')
        (self.project/'web/index.html').write_text('MAINTENANCE EDITOR')
        self.store = SkillStore(self.project,personal,self.project/'plugins')
        self.handler = make_handler(self.store)
        self.server = ThreadingHTTPServer(('127.0.0.1',0),self.handler)
        self.worker = threading.Thread(target=self.server.serve_forever,daemon=True)
        self.worker.start()

    def tearDown(self):
        self.handler.shutdown_engine()
        self.server.shutdown()
        self.server.server_close()
        self.worker.join(timeout=2)
        self.temp.cleanup()

    def request(self,method,path,payload=None,**headers):
        connection=HTTPConnection('127.0.0.1',self.server.server_port,timeout=3)
        body=json.dumps(payload) if payload is not None else None
        request_headers={'Content-Type':'application/json',**headers} if payload is not None else headers
        try:
            connection.request(method,path,body,request_headers)
            response=connection.getresponse()
            raw=response.read()
            return response.status,json.loads(raw) if response.getheader('Content-Type','').startswith('application/json') else raw.decode()
        finally:
            connection.close()

    def create(self):
        status,task=self.request('POST','/api/tasks',{'request':'设计一个深色网页'})
        self.assertEqual(status,201,task)
        self.assertEqual(task['status'],'ready')
        return task

    def test_root_is_task_home_and_maintenance_remains_accessible(self):
        self.assertEqual(self.request('GET','/'),(200,'TASK ENGINE HOME'))
        self.assertEqual(self.request('GET','/maintenance'),(200,'MAINTENANCE EDITOR'))
        self.assertEqual(self.request('GET','/maintenance/'),(308,''))
        self.assertEqual(self.request('GET','/flow-lab/index.html'),(200,'TASK ENGINE HOME'))

    def test_shutdown_blocks_late_service_initialization(self):
        self.handler.shutdown_engine()
        with patch('skill_editor.server.Executor') as executor:
            self.assertEqual(self.request('GET','/api/engine/config')[0],503)
            executor.assert_not_called()

    def test_task_roundtrip_events_feedback_and_stale_guard(self):
        task=self.create()
        status,listing=self.request('GET','/api/tasks')
        self.assertEqual(status,200)
        self.assertEqual(listing['tasks'][0]['id'],task['id'])
        status,events=self.request('GET','/api/task/events?id='+task['id']+'&after=0')
        self.assertEqual(status,200)
        self.assertTrue(events['events'])
        status,handoff=self.request('POST','/api/task/handoff',{'taskId':task['id'],'baselineSha':task['sha']})
        self.assertEqual(status,200)
        self.assertIn('尚未执行',handoff['prompt'])
        status,updated=self.request('POST','/api/task/feedback',{'taskId':task['id'],'baselineSha':task['sha'],'outcome':'helpful'})
        self.assertEqual(status,200)
        status,_=self.request('POST','/api/task/plan',{'taskId':task['id'],'baselineSha':task['sha']})
        self.assertEqual(status,409)
        self.assertNotEqual(updated['sha'],task['sha'])

    def test_unconfigured_runner_has_no_process_and_no_fake_success(self):
        task=self.create()
        with patch.dict(os.environ,{},clear=True),patch('skill_editor.executor.subprocess.Popen') as launch:
            status,config=self.request('GET','/api/engine/config')
            self.assertEqual(status,200)
            self.assertFalse(config['executor']['configured'])
            status,_=self.request('POST','/api/task/run',{'taskId':task['id'],'baselineSha':task['sha']})
            self.assertEqual(status,503)
            launch.assert_not_called()
        self.assertEqual(self.request('GET','/api/task?id='+task['id'])[1]['status'],'ready')

    def test_cross_site_and_bad_host_cannot_create_run_or_install(self):
        for path,payload in [('/api/tasks',{'request':'设计网页'}),('/api/task/run',{'taskId':'x'}),('/api/catalog/install',{'candidateId':'x'})]:
            self.assertEqual(self.request('POST',path,payload,Origin='https://untrusted.example')[0],403)
        self.assertEqual(self.request('GET','/api/tasks',Host='untrusted.example')[0],403)

    def test_catalog_route_uses_adapter_without_uncontrolled_network(self):
        result={'source':'github','results':[{'repo':'example/skills','stars':3,'starsScope':'repository'}]}
        with patch('skill_editor.server.CatalogService.search',return_value=result) as search:
            status,data=self.request('GET','/api/catalog?q=web&source=github&sort=stars')
            self.assertEqual(status,200)
            self.assertEqual(data,result)
            search.assert_called_once_with('web',source='github',sort='stars')
        self.assertEqual(self.request('GET','/api/task/events?id=x&after=invalid')[0],400)

    def test_curated_directory_routes_filters_without_public_search(self):
        result={'entries':[],'functionCategories':[],'useCases':[],'total':0,'counts':{}}
        with patch('skill_editor.server.CatalogService.curated',return_value=result) as curated, \
             patch('skill_editor.server.CatalogService.search') as public_search:
            status,data=self.request('GET','/api/catalog/curated?q=web&category=design&use=review')
            self.assertEqual((status,data),(200,result))
            curated.assert_called_once_with('web',category='design',use_case='review')
            public_search.assert_not_called()

    def test_preflight_roundtrip_preserves_selected_candidate_identity(self):
        payload={'candidateId':'a'*32,'previewSha':'b'*64}
        result={**payload,'deployment':{'status':'needs_setup','installAllowed':True,'checks':[],
                                      'hostStatus':'unverified','effectivenessStatus':'untested'}}
        with patch('skill_editor.server.CatalogService.preflight',return_value=result) as preflight:
            self.assertEqual(self.request('POST','/api/catalog/preflight',payload),(200,result))
            preflight.assert_called_once_with(payload)

    def test_preflight_and_curated_routes_reject_cross_origin(self):
        with patch('skill_editor.server.CatalogService.preflight') as preflight:
            self.assertEqual(self.request('POST','/api/catalog/preflight',{},Origin='https://untrusted.example')[0],403)
            preflight.assert_not_called()
        self.assertEqual(self.request('GET','/api/catalog/curated',Host='untrusted.example')[0],403)


if __name__=='__main__':
    unittest.main()
