"""Independent persisted tasks; no execution or model traffic in these fixtures."""
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from skill_editor.core import EditorError, SkillStore
from skill_editor.tasks import EngineStore


class EngineStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name).resolve()
        self.store = SkillStore(self.project, self.project / "personal")
        self.engine = EngineStore(self.store, auto_sync=False)

    def tearDown(self):
        self.temp.cleanup()

    def create(self):
        return self.engine.create({"request": "Explain a Python list."})

    def test_create_persists_independent_real_plan_and_monotonic_events(self):
        task = self.create()
        other = self.create()
        self.assertNotEqual(task["id"], other["id"])
        self.assertEqual(task["status"], "ready")
        self.assertEqual(task["plan"]["method"], "local_rules")
        self.assertIsNone(task["run"])
        self.assertTrue((self.project / ".state/engine/tasks" / (task["id"] + ".json")).is_file())
        self.assertEqual(self.engine.read(task["id"])["sha"], task["sha"])
        events = self.engine.events(task["id"], 0)["events"]
        self.assertEqual([item["sequence"] for item in events], list(range(1, len(events) + 1)))
        self.assertTrue(all(item["type"] != "completed" for item in events))

    def test_request_and_mode_validation_do_not_write(self):
        for payload in ({}, {"request": " "}, {"request": "x" * 12001}, {"request": "a\x00"}, {"request": "x", "mode": "fake"}, {"request": "x", "status": "completed"}):
            with self.subTest(payload=str(payload)[:60]), self.assertRaises(EditorError):
                self.engine.create(payload)
        self.assertEqual(self.engine.list()["tasks"], [])

    def test_replanning_and_feedback_reject_stale_sha(self):
        task = self.create()
        updated = self.engine.feedback({"taskId": task["id"], "baselineSha": task["sha"], "outcome": "helpful", "note": "Useful plan"})
        self.assertEqual(updated["feedback"][0]["outcome"], "helpful")
        for method, payload in ((self.engine.plan, {}), (self.engine.feedback, {"outcome": "not_helpful"}), (self.engine.handoff, {})):
            with self.assertRaises(EditorError) as caught:
                method({"taskId": task["id"], "baselineSha": task["sha"], **payload})
            self.assertEqual(caught.exception.status, 409)

    def test_no_implicit_sync_and_injected_sync_is_observable(self):
        with patch.object(self.store, "refresh_inventory", side_effect=AssertionError("Unexpected scan")):
            self.create()
        synced = []
        engine = EngineStore(self.store, auto_sync=True, sync_inventory=lambda: synced.append(True))
        engine.create({"request": "Explain a list."})
        self.assertEqual(synced, [True])

    def test_handoff_is_text_and_does_not_fake_execution(self):
        task = self.create()
        handoff = self.engine.handoff({"taskId": task["id"], "baselineSha": task["sha"]})
        self.assertEqual(handoff["taskId"], task["id"])
        self.assertIn(task["request"], handoff["prompt"])
        self.assertEqual(self.engine.read(task["id"])["status"], "ready")
        self.assertIsNone(self.engine.read(task["id"])["run"])

    def test_concurrent_fresh_sha_claim_has_one_winner(self):
        task = self.create()
        barrier = threading.Barrier(2)
        results = []
        def claim():
            barrier.wait()
            try:
                self.engine.update_state(task["id"], {"status": "queued", "run": {"id": "fixture-run"}}, {"type": "queued", "message": "Execution requested"}, baselineSha=task["sha"])
                results.append("claimed")
            except EditorError as exc:
                results.append(exc.status)
        workers = [threading.Thread(target=claim) for _ in range(2)]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join()
        self.assertEqual(sorted(str(item) for item in results), ["409", "claimed"])

    def test_restart_marks_dead_prior_process_run_failed_without_completing_steps(self):
        task = self.create()
        # A new wrapper in the same live process is not a restart. Persist a
        # prior-process owner and explicitly simulate its absence instead.
        with patch("skill_editor.tasks.os.getpid", return_value=987654321):
            running = self.engine.update_state(task["id"], {"status": "running", "run": {"id": "old-run"}}, {"type": "started", "message": "Real fixture process started"}, baselineSha=task["sha"])
        restarted = EngineStore(self.store, auto_sync=False)
        with patch("skill_editor.tasks.os.kill", side_effect=ProcessLookupError):
            recovered = restarted.read(task["id"])
        self.assertEqual(recovered["status"], "failed")
        self.assertNotEqual(recovered["sha"], running["sha"])
        self.assertEqual(recovered["events"][-1]["type"], "interrupted")
        self.assertNotIn("completed", [step["status"] for step in recovered["plan"]["steps"]])

    def test_another_store_in_same_live_process_preserves_active_owner_and_cannot_mutate_it(self):
        task = self.create()
        running = self.engine.update_state(task["id"], {"status": "running", "run": {"id": "live-run"}}, {"type": "started", "message": "Fixture executor started"}, baselineSha=task["sha"])
        observer = EngineStore(self.store, auto_sync=False)
        with patch("skill_editor.tasks.os.kill", side_effect=AssertionError("Same-process ownership needs no probe")):
            observed = observer.read(task["id"])
            listed = observer.list()
        self.assertEqual(observed["status"], "running")
        self.assertEqual(observed["sha"], running["sha"])
        self.assertEqual(observed["events"], running["events"])
        self.assertEqual(listed["tasks"][0]["status"], "running")
        with self.assertRaises(EditorError) as caught:
            observer.update_state(task["id"], {"status": "failed"}, {"type": "failed", "message": "Observer may not take over"}, baselineSha=running["sha"])
        self.assertEqual(caught.exception.status, 409)
        completed = self.engine.update_state(task["id"], {"status": "completed"}, {"type": "completed", "message": "Owning fixture executor completed"}, baselineSha=running["sha"])
        self.assertEqual(completed["status"], "completed")

    def test_active_task_cannot_replan_or_be_claimed_twice(self):
        task = self.create()
        queued = self.engine.update_state(task["id"], {"status": "queued"}, {"type": "queued", "message": "Requested"}, baselineSha=task["sha"])
        with self.assertRaises(EditorError):
            self.engine.plan({"taskId": task["id"], "baselineSha": queued["sha"]})
        with self.assertRaises(EditorError):
            self.engine.update_state(task["id"], {"status": "queued"}, baselineSha=queued["sha"])

    def test_queued_owner_can_record_cancellation_without_requeueing(self):
        task = self.create()
        queued = self.engine.update_state(task["id"], {"status": "queued"}, baselineSha=task["sha"])
        updated = self.engine.update_state(task["id"], {"run": {**queued["run"], "cancelRequested": True}},
                                           {"type": "cancel_requested", "message": "Fixture cancellation requested"}, baselineSha=queued["sha"])
        self.assertEqual(updated["status"], "queued")
        self.assertTrue(updated["run"]["cancelRequested"])
        with self.assertRaises(EditorError) as caught:
            self.engine.update_state(task["id"], {"status": "queued"}, baselineSha=updated["sha"])
        self.assertEqual(caught.exception.status, 409)

    def test_task_ids_symlinks_and_unsafe_patch_fields_are_rejected(self):
        task = self.create()
        with self.assertRaises(EditorError):
            self.engine.read("../../outside")
        with self.assertRaises(EditorError):
            self.engine.update_state(task["id"], {"request": "Replaced request"})
        path = self.project / ".state/engine/tasks" / (task["id"] + ".json")
        other = self.project / "other.json"
        path.rename(other)
        path.symlink_to(other)
        with self.assertRaises(EditorError):
            self.engine.read(task["id"])
        self.assertTrue(self.engine.list()["warnings"])

    def test_atomic_replace_failure_preserves_previous_task(self):
        task = self.create()
        path = self.project / ".state/engine/tasks" / (task["id"] + ".json")
        before = path.read_bytes()
        original = os.replace
        def fail(source, target):
            if Path(target) == path:
                raise OSError("fixture commit failure")
            return original(source, target)
        with patch("skill_editor.tasks.os.replace", side_effect=fail), self.assertRaises(OSError):
            self.engine.feedback({"taskId": task["id"], "baselineSha": task["sha"], "outcome": "helpful"})
        self.assertEqual(path.read_bytes(), before)

    def test_config_exposes_boolean_availability_without_secrets(self):
        with patch.dict("os.environ", {"OPENROUTER_API_KEY": "hidden-token", "OPENROUTER_MODEL": "private-model"}):
            config = self.engine.config()
        self.assertTrue(config["semanticPlannerAvailable"])
        self.assertTrue(all(isinstance(value, bool) for value in config.values()))
        self.assertNotIn("hidden-token", json.dumps(config))

    def test_handoff_and_start_reject_changed_selected_source(self):
        path = self.project / "personal/frontend-design/SKILL.md"
        path.parent.mkdir(parents=True)
        path.write_text('---\nname: frontend-design\ndescription: "Build frontend websites."\n---\nDesign pages.\n')
        (self.project / "data").mkdir()
        (self.project / "data/inventory.json").write_text(json.dumps({"skills": [{"id": "designer", "name": "frontend-design", "path": str(path), "source": "personal", "description": "Build frontend websites."}]}))
        task = self.engine.create({"request": "Build a website."})
        path.write_text(path.read_text() + "External change.\n")
        with self.assertRaises(EditorError) as caught:
            self.engine.handoff({"taskId": task["id"], "baselineSha": task["sha"]})
        self.assertEqual(caught.exception.status, 409)
        with self.assertRaises(EditorError):
            self.engine.update_state(task["id"], {"status": "queued"}, baselineSha=task["sha"])

    def test_real_running_executor_can_report_blocked_for_clarification(self):
        task = self.create()
        running = self.engine.update_state(task["id"], {"status": "running", "run": {"id": "fixture-run"}}, {"type": "started", "message": "Fixture executor started"}, baselineSha=task["sha"])
        blocked = self.engine.update_state(task["id"], {"status": "needs_clarification", "run": {**running["run"], "summary": "Need the missing source document", "finishedAt": "fixture-finish"}}, {"type": "blocked", "message": "Executor needs a missing source document"}, baselineSha=running["sha"])
        self.assertEqual(blocked["status"], "needs_clarification")
        self.assertEqual(blocked["events"][-1]["type"], "blocked")
        self.assertNotIn("completed", [event["type"] for event in blocked["events"]])

    def test_replanning_finished_run_preserves_original_results_and_sha(self):
        for status in ("completed", "failed", "cancelled", "needs_clarification"):
            with self.subTest(status=status):
                task = self.create()
                running = self.engine.update_state(task["id"], {"status": "running", "run": {"id": "fixture-run"}}, {"type": "started", "message": "Fixture executor started"}, baselineSha=task["sha"])
                run = {**running["run"], "summary": "Preserved original execution result", "finishedAt": "fixture-finish", "artifacts": [{"name": "original.txt", "sha256": "a" * 64}]}
                finished = self.engine.update_state(task["id"], {"status": status, "run": run}, {"type": "result", "message": "Fixture executor returned"}, baselineSha=running["sha"])
                path = self.project / ".state/engine/tasks" / (task["id"] + ".json")
                before = path.read_bytes()
                with patch.object(self.engine, "_prepare", side_effect=AssertionError("Rejected replanning must not scan or call a model")), self.assertRaises(EditorError) as caught:
                    self.engine.plan({"taskId": task["id"], "baselineSha": finished["sha"]})
                self.assertEqual(caught.exception.status, 409)
                self.assertIn("此任务已有执行记录", str(caught.exception))
                preserved = self.engine.read(task["id"])
                self.assertEqual(preserved["sha"], finished["sha"])
                self.assertEqual(preserved["run"], run)
                self.assertEqual(preserved["plan"], finished["plan"])
                self.assertEqual(preserved["status"], status)
                self.assertEqual(path.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
