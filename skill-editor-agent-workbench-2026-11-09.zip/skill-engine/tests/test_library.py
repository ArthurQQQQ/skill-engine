"""Browsable library regression tests; all skill files are isolated fixtures."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from skill_editor.core import EditorError, SkillStore


class LibraryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name).resolve()
        self.personal = self.project / "personal"
        self.cache = self.project / "plugins"
        self.personal.mkdir()
        self.cache.mkdir()
        (self.project / "data").mkdir()
        self.inventory_path = self.project / "data/inventory.json"
        self.store = SkillStore(self.project, self.personal, self.cache)

    def tearDown(self):
        self.temp.cleanup()

    def write_skill(self, root, folder, name="example", description="Original", body="Protected workflow"):
        path = root / folder / "SKILL.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        content = f'---\nname: {name}\ndescription: "{description}"\n---\n{body}\n'
        path.write_text(content, encoding="utf-8")
        return path

    def record(self, path, identifier, source="plugin", **extra):
        content = path.read_text(encoding="utf-8")
        return {
            "id": identifier, "name": path.parent.name,
            "description": "Original", "path": str(path), "source": source,
            "editable": source == "personal", "content": content,
            "sha256": hashlib.sha256(content.encode("utf-8")).hexdigest(),
            "frontmatter": {"description": "Original"}, **extra,
        }

    def save(self, skills=None, cached=None):
        self.inventory_path.write_text(json.dumps({
            "skills": skills or [], "cachedSkills": cached or [], "counts": {},
            "sessionCatalog": {"capturedAt": "2026-11-01", "isLive": False,
                               "source": "Historical fixture catalog", "entries": []},
        }), encoding="utf-8")

    def test_newly_refreshed_plugin_is_browsable_without_claiming_session_availability(self):
        personal = self.write_skill(self.personal, "local")
        plugin = self.write_skill(self.cache, "package/1.0/skills/new-tool", name="new-tool")
        self.save([self.record(personal, "local", source="personal", sessionAvailable=True)])

        result = self.store.refresh_inventory()

        self.assertEqual(len(result["skills"]), 1)
        self.assertEqual(len(result["cachedSkills"]), 1)
        self.assertEqual(len(result["librarySkills"]), 2)
        cached = next(item for item in result["librarySkills"] if item["path"] == str(plugin))
        self.assertEqual(cached["inventoryRole"], "cache-only")
        self.assertFalse(cached["editable"])
        self.assertIsNone(cached["sessionAvailable"])
        self.assertEqual(result["sessionCatalog"]["entries"], [])
        detail = self.store.read(cached["id"])
        self.assertEqual(detail["content"], plugin.read_text(encoding="utf-8"))
        self.assertEqual(detail["skill"]["inventoryRole"], "cache-only")
        with self.assertRaises(EditorError) as caught:
            self.store.preview(cached["id"], "Changed")
        self.assertEqual(caught.exception.status, 403)

    def test_same_source_and_path_is_one_library_record_with_main_metadata(self):
        path = self.write_skill(self.cache, "package/1.0/skills/tool")
        self.save(
            [self.record(path, "catalog-tool", sessionAvailable=True, origin="main")],
            [self.record(path, "cache-alias", sessionAvailable=False, origin="cache")],
        )

        result = self.store.inventory(include_analysis=False)

        self.assertEqual(len(result["librarySkills"]), 1)
        item = result["librarySkills"][0]
        self.assertEqual(item["id"], "catalog-tool")
        self.assertEqual(item["origin"], "main")
        self.assertTrue(item["sessionAvailable"])
        self.assertNotEqual(item.get("inventoryRole"), "cache-only")
        self.assertEqual(len(result["skills"]), 1)
        self.assertEqual(len(result["cachedSkills"]), 1)
        self.assertEqual(result["cachedSkills"][0]["id"], "cache-alias")
        self.assertEqual(self.store.read("catalog-tool")["skill"]["id"], "catalog-tool")

    def test_same_id_at_different_paths_rejects_inventory_and_ambiguous_reads(self):
        first = self.write_skill(self.cache, "package/1.0/skills/tool")
        second = self.write_skill(self.cache, "package/2.0/skills/tool")
        self.save(cached=[self.record(first, "reused-id"), self.record(second, "reused-id")])

        with self.assertRaises(EditorError) as invalid_inventory:
            self.store.inventory(include_analysis=False)
        self.assertEqual(invalid_inventory.exception.status, 409)
        with self.assertRaises(EditorError) as caught:
            self.store.read("reused-id")
        self.assertEqual(caught.exception.status, 404)

    def test_same_path_with_different_sources_is_not_deduplicated(self):
        path = self.write_skill(self.personal, "local")
        self.save([self.record(path, "personal-id", source="personal")],
                  [self.record(path, "plugin-id", source="plugin")])

        result = self.store.inventory(include_analysis=False)

        self.assertEqual(len(result["librarySkills"]), 2)
        self.assertEqual({item["id"] for item in result["librarySkills"]}, {"personal-id", "plugin-id"})

    def test_cached_record_and_detail_use_current_content_and_hash_without_analysis(self):
        path = self.write_skill(self.cache, "package/1.0/skills/tool")
        self.save(cached=[self.record(path, "cached-tool")])
        current = '---\nname: example\ndescription: "Changed externally"\n---\nFresh workflow\n'
        path.write_text(current, encoding="utf-8")
        expected_sha = hashlib.sha256(current.encode("utf-8")).hexdigest()

        with patch("skill_editor.relationships.build_relationships", side_effect=AssertionError("Metadata must skip analysis")), patch("skill_editor.core.conservative_findings", side_effect=AssertionError("Metadata must skip findings")):
            result = self.store.inventory(include_analysis=False)

        self.assertEqual(result["skills"], [])
        for item in (result["cachedSkills"][0], result["librarySkills"][0]):
            self.assertEqual(item["content"], current)
            self.assertEqual(item["sha256"], expected_sha)
            self.assertEqual(item["bytes"], len(current.encode("utf-8")))
            self.assertEqual(item["description"], "Changed externally")
            self.assertEqual(item["frontmatter"]["description"], "Changed externally")
            self.assertEqual(item["body"], "Fresh workflow\n")
            self.assertEqual(item["fileStatus"], "present")
        detail = self.store.read("cached-tool")
        self.assertEqual(detail["content"], current)
        self.assertEqual(detail["sha"], expected_sha)

    def test_missing_cached_record_stays_visible_but_cannot_validate_relationship_evidence(self):
        main = self.write_skill(self.personal, "main", name="main", body="Main evidence")
        cached = self.write_skill(self.cache, "package/1.0/skills/tool", body="Cached evidence")
        self.save([self.record(main, "main", source="personal")],
                  [self.record(cached, "cached-tool")])
        (self.project / "data/relationships.json").write_text(json.dumps({"relationships": [{
            "id": "reviewed", "sourceId": "main", "targetId": "cached-tool",
            "type": "complementarity", "summary": "Fixture review",
            "evidence": [{"skillId": "main", "quote": "Main evidence"},
                         {"skillId": "cached-tool", "quote": "Cached evidence"}],
        }]}), encoding="utf-8")
        present = self.store.inventory()
        self.assertEqual(next(edge for edge in present["relationships"] if edge["id"] == "reviewed")["status"], "current")
        cached.unlink()

        missing = self.store.inventory()

        self.assertEqual(len(missing["librarySkills"]), 2)
        self.assertEqual(missing["cachedSkills"][0]["fileStatus"], "missing")
        item = next(item for item in missing["librarySkills"] if item["id"] == "cached-tool")
        self.assertEqual(item["fileStatus"], "missing")
        self.assertFalse(item["editable"])
        edge = next(edge for edge in missing["relationships"] if edge["id"] == "reviewed")
        self.assertEqual(edge["status"], "unavailable")
        self.assertEqual(next(evidence for evidence in edge["evidence"] if evidence["skillId"] == "cached-tool")["status"], "unavailable")
        with self.assertRaises(EditorError) as caught:
            self.store.read("cached-tool")
        self.assertEqual(caught.exception.status, 404)

    def test_cache_only_personal_metadata_cannot_grant_write_access(self):
        path = self.write_skill(self.personal, "cached-personal")
        self.save(cached=[self.record(path, "cache-personal", source="personal", editable=True)])

        item = self.store.read("cache-personal")["skill"]

        self.assertEqual(item["inventoryRole"], "cache-only")
        self.assertFalse(item["editable"])
        with self.assertRaises(EditorError) as caught:
            self.store.preview("cache-personal", "Changed")
        self.assertEqual(caught.exception.status, 403)
        self.assertIn('description: "Original"', path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
