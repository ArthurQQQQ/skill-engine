"""Read-only host discovery fixtures. Run only on an authorized CPU environment."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from skill_editor.agents import AgentService
from skill_editor.core import EditorError, SkillStore


class AgentServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name).resolve()
        self.home = self.project / "home"
        self.home.mkdir()
        self.personal = self.home / ".codex/skills"
        self.store = SkillStore(self.project, self.personal, self.home / ".codex/plugins/cache")
        self.service = AgentService(self.store, home=self.home)
        # An isolated fixture never reports binaries from the test machine.
        self.system_bins = patch("skill_editor.agents.SYSTEM_BINARY_DIRS", ())
        self.system_bins.start()

    def tearDown(self):
        self.system_bins.stop()
        self.temp.cleanup()

    def snapshot(self):
        return self.service.snapshot()

    def agent(self, identifier, snapshot=None):
        return next(item for item in (snapshot or self.snapshot())["agents"] if item["id"] == identifier)

    def root(self, agent, relative):
        return next(item for item in agent["roots"] if item["path"] == str(self.home / relative))

    def skill(self, relative, body="Never execute or read this skill text"):
        path = self.home / relative / "SKILL.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body, encoding="utf-8")
        return path

    def executable(self, relative):
        path = self.home / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("#!/bin/sh\nexit 91\n", encoding="utf-8")
        path.chmod(0o700)
        return path

    def test_missing_roots_are_unknown_counts_and_runtime_is_always_unverified(self):
        result = self.snapshot()
        self.assertEqual([item["id"] for item in result["agents"]], ["codex", "claude-code", "cursor", "opencode"])
        self.assertTrue(result["checkedAt"])
        self.assertIsNone(result["library"]["personalCount"])
        for agent in result["agents"]:
            self.assertFalse(agent["detected"])
            self.assertFalse(agent["executableDetected"])
            self.assertFalse(agent["configurationDetected"])
            self.assertEqual(agent["status"], "not_detected")
            self.assertIsNone(agent["skillCount"])
            for key in ("runtimeStatus", "connectionStatus", "loadingStatus"):
                self.assertEqual(agent[key], "unverified")
            for root in agent["roots"]:
                self.assertEqual(root["status"], "missing")
                self.assertFalse(root["exists"])
                self.assertIsNone(root["count"])
                self.assertFalse(root["countComplete"])

    def test_empty_configuration_directory_does_not_claim_cli_installed(self):
        (self.home / ".claude").mkdir()
        agent = self.agent("claude-code")
        self.assertTrue(agent["detected"])
        self.assertTrue(agent["configurationDetected"])
        self.assertFalse(agent["executableDetected"])
        self.assertEqual(agent["status"], "detected")
        evidence = next(item for item in agent["evidence"] if item["kind"] == "configuration_directory")
        self.assertEqual(evidence["status"], "present")
        self.assertIn("目录", evidence["message"])
        self.assertNotIn("installed", agent)

    def test_executable_evidence_is_separate_and_never_runs_anything(self):
        binary = self.executable(".local/bin/claude")
        with patch("subprocess.run", side_effect=AssertionError("No commands")), \
             patch("subprocess.Popen", side_effect=AssertionError("No commands")), \
             patch("os.system", side_effect=AssertionError("No commands")), \
             patch("urllib.request.urlopen", side_effect=AssertionError("No network")):
            agent = self.agent("claude-code")
        self.assertTrue(agent["executableDetected"])
        self.assertFalse(agent["configurationDetected"])
        evidence = next(item for item in agent["evidence"] if item["path"] == str(binary))
        self.assertEqual(evidence["status"], "present")
        self.assertEqual(agent["runtimeStatus"], "unverified")

    def test_non_executable_file_or_directory_cannot_be_cli_evidence(self):
        binary = self.executable(".local/bin/codex")
        binary.chmod(0o600)
        directory = self.home / ".local/bin/claude"
        directory.mkdir()
        for identifier in ("codex", "claude-code"):
            agent = self.agent(identifier)
            self.assertFalse(agent["executableDetected"])
            self.assertEqual(agent["status"], "not_detected")
            self.assertTrue(any(item["status"] == "not_executable" for item in agent["evidence"]))

    def test_only_direct_regular_skill_files_count_without_reading_text(self):
        first = self.skill(".claude/skills/one")
        second = self.skill(".claude/skills/two")
        self.skill(".claude/skills/one/references/not-a-skill")
        self.skill(".claude/skills/.system/internal")
        (self.home / ".claude/skills/SKILL.md").write_text("Not a skill directory", encoding="utf-8")
        with patch.object(Path, "read_text", side_effect=AssertionError("No text reads")), \
             patch.object(Path, "read_bytes", side_effect=AssertionError("No content reads")), \
             patch.object(self.store, "inventory", side_effect=AssertionError("No inventory reads")), \
             patch.object(self.store, "refresh_inventory", side_effect=AssertionError("No inventory changes")):
            agent = self.agent("claude-code")
        root = self.root(agent, ".claude/skills")
        self.assertEqual(root["count"], 2)
        self.assertTrue(root["countComplete"])
        self.assertEqual(agent["skillCount"], 2)
        self.assertTrue(agent["countComplete"])
        self.assertEqual(first.read_text(), second.read_text())

    def test_existing_empty_directory_is_zero_and_missing_directory_is_not_zero(self):
        (self.home / ".claude/skills").mkdir(parents=True)
        claude = self.agent("claude-code")
        cursor = self.agent("cursor")
        self.assertEqual(self.root(claude, ".claude/skills")["count"], 0)
        self.assertIsNone(self.root(cursor, ".cursor/skills")["count"])

    def test_shared_roots_are_labelled_and_do_not_detect_an_agent(self):
        self.skill(".agents/skills/shared")
        result = self.snapshot()
        for identifier in ("codex", "cursor", "opencode"):
            agent = self.agent(identifier, result)
            root = self.root(agent, ".agents/skills")
            self.assertTrue(root["shared"])
            self.assertEqual(root["relationship"], "shared")
            self.assertEqual(root["supportStatus"], "documented")
            self.assertEqual(root["count"], 1)
            self.assertFalse(agent["detected"])
        self.assertFalse(any(root["shared"] for root in self.agent("claude-code", result)["roots"]))

    def test_symlink_roots_ancestors_skills_files_and_binaries_are_skipped(self):
        outside = self.project / "outside"
        outside.mkdir()
        secret = outside / "SKILL.md"
        secret.write_text("Do not read", encoding="utf-8")
        root = self.home / ".claude/skills"
        root.mkdir(parents=True)
        (root / "linked-directory").symlink_to(outside, target_is_directory=True)
        (root / "linked-file").mkdir()
        (root / "linked-file/SKILL.md").symlink_to(secret)
        (self.home / ".cursor").symlink_to(outside, target_is_directory=True)
        (self.home / ".local/bin").mkdir(parents=True)
        (self.home / ".local/bin/claude").symlink_to(secret)
        result = self.snapshot()
        claude = self.agent("claude-code", result)
        root_result = self.root(claude, ".claude/skills")
        self.assertEqual(root_result["count"], 0)
        self.assertFalse(root_result["countComplete"])
        self.assertEqual(len(root_result["warnings"]), 2)
        self.assertTrue(all(item["status"] == "symlink_skipped" for item in root_result["warnings"]))
        self.assertFalse(claude["executableDetected"])
        cursor = self.agent("cursor", result)
        self.assertEqual(self.root(cursor, ".cursor/skills")["status"], "symlink_skipped")
        self.assertFalse(cursor["configurationDetected"])
        self.assertEqual(cursor["status"], "unavailable")

    def test_external_home_is_rejected_before_any_filesystem_access(self):
        external_home = Path("/Volumes/fixture/home")
        external_store = SkillStore(self.project, external_home / ".codex/skills")
        service = AgentService(external_store, home=external_home)
        with patch("skill_editor.agents.os.open", side_effect=AssertionError("External paths must not be opened")), \
             patch("skill_editor.agents.os.scandir", side_effect=AssertionError("External paths must not be scanned")):
            result = service.snapshot()
        for agent in result["agents"]:
            self.assertEqual(agent["status"], "unavailable")
            self.assertTrue(all(root["status"] == "external_skipped" for root in agent["roots"]))
            self.assertFalse(agent["installation"]["available"])

    def test_access_errors_are_explicit_and_never_zero(self):
        self.skill(".claude/skills/one")
        with patch("skill_editor.agents.os.scandir", side_effect=PermissionError("fixture denied")):
            agent = self.agent("claude-code")
        root = self.root(agent, ".claude/skills")
        self.assertEqual(root["status"], "unavailable")
        self.assertIsNone(root["count"])
        self.assertFalse(root["countComplete"])
        self.assertIn("PermissionError", root["error"])

    def test_unreadable_configuration_marks_detection_incomplete(self):
        (self.home / ".claude").mkdir()
        real_open = os.open
        def deny_configuration(path, flags, *args, **kwargs):
            if path == ".claude":
                raise PermissionError("fixture denied")
            return real_open(path, flags, *args, **kwargs)
        with patch("skill_editor.agents.os.open", side_effect=deny_configuration):
            agent = self.agent("claude-code")
        self.assertFalse(agent["detected"])
        self.assertFalse(agent["detectionComplete"])
        self.assertEqual(agent["status"], "unavailable")
        configuration = next(item for item in agent["evidence"] if item["kind"] == "configuration_directory")
        self.assertIsNone(configuration["exists"])
        self.assertIn("PermissionError", configuration["error"])

    def test_replaced_skill_directory_is_opened_with_nofollow(self):
        self.skill(".claude/skills/replaced")
        outside = self.project / "outside"
        outside.mkdir()
        (outside / "SKILL.md").write_text("Never follow", encoding="utf-8")
        directory = self.home / ".claude/skills/replaced"
        real_open = os.open
        def replace_before_open(path, flags, *args, **kwargs):
            if path == "replaced":
                self.assertTrue(flags & os.O_NOFOLLOW)
                (directory / "SKILL.md").unlink()
                directory.rmdir()
                directory.symlink_to(outside, target_is_directory=True)
            return real_open(path, flags, *args, **kwargs)
        with patch("skill_editor.agents.os.open", side_effect=replace_before_open):
            root = self.root(self.agent("claude-code"), ".claude/skills")
        self.assertEqual(root["count"], 0)
        self.assertFalse(root["countComplete"])
        self.assertTrue(root["warnings"])

    def test_global_entry_budget_is_bounded_and_reused_roots_are_not_rescanned(self):
        self.skill(".agents/skills/one")
        self.skill(".agents/skills/two")
        self.skill(".agents/skills/three")
        with patch("skill_editor.agents.MAX_SKILL_ENTRIES", 2):
            result = self.snapshot()
        self.assertLessEqual(result["limits"]["inspectedSkillEntries"], 2)
        for identifier in ("codex", "cursor", "opencode"):
            root = self.root(self.agent(identifier, result), ".agents/skills")
            self.assertEqual(root["status"], "limit_reached")
            self.assertEqual(root["count"], 2)
            self.assertFalse(root["countComplete"])

    def test_inventory_credentials_and_other_home_directories_are_never_opened_or_changed(self):
        self.skill(".codex/skills/one")
        data = self.project / "data/inventory.json"
        data.parent.mkdir()
        original = b'{"skills":[],"private":"fixture"}\n'
        data.write_bytes(original)
        credential = self.home / ".claude/.credentials.json"
        credential.parent.mkdir(exist_ok=True)
        credential.write_text("fixture secret", encoding="utf-8")
        real_open = os.open
        def directory_open(path, flags, *args, **kwargs):
            self.assertTrue(flags & os.O_DIRECTORY, "Only directory descriptors may be opened")
            return real_open(path, flags, *args, **kwargs)
        with patch("skill_editor.agents.os.open", side_effect=directory_open), \
             patch.object(Path, "read_text", side_effect=AssertionError("No file reads")), \
             patch.object(Path, "read_bytes", side_effect=AssertionError("No file reads")), \
             patch.object(self.store, "inventory", side_effect=AssertionError("No inventory reads")), \
             patch.object(self.store, "refresh_inventory", side_effect=AssertionError("No refresh")):
            result = self.snapshot()
        self.assertEqual(result["library"]["personalCount"], 1)
        self.assertEqual(data.read_bytes(), original)
        self.assertEqual(credential.read_text(), "fixture secret")
        self.assertFalse((self.project / ".state").exists())

    def test_personal_library_is_separate_from_documented_codex_shared_root(self):
        self.skill(".codex/skills/local")
        self.skill(".codex/skills/.system/not-personal")
        result = self.snapshot()
        self.assertEqual(result["library"]["path"], str(self.personal))
        self.assertEqual(result["library"]["personalCount"], 1)
        self.assertTrue(result["library"]["countComplete"])
        codex = self.agent("codex", result)
        library = self.root(codex, ".codex/skills")
        self.assertEqual(library["supportStatus"], "unverified")
        self.assertEqual(library["loadingStatus"], "unverified")
        self.assertIsNone(self.root(codex, ".agents/skills")["count"])

    def test_target_is_fixed_safe_and_does_not_create_any_directory(self):
        targets = {"codex": ".agents/skills", "claude-code": ".claude/skills", "cursor": ".cursor/skills", "opencode": ".config/opencode/skills"}
        for identifier, relative in targets.items():
            with self.subTest(agent=identifier):
                expected = self.home / relative
                self.assertEqual(self.service.target(identifier), expected)
                self.assertFalse(expected.exists())
                installation = self.agent(identifier)["installation"]
                self.assertEqual(installation["targetPath"], str(expected))
                self.assertTrue(installation["available"])
                self.assertEqual(installation["shared"], identifier == "codex")
                self.assertEqual(installation["agentId"], identifier)
        for invalid in ("../claude", str(self.home), "", None, 1, {"path": "arbitrary"}):
            with self.subTest(invalid=invalid), self.assertRaises(EditorError):
                self.service.target(invalid)
        self.assertEqual(list(self.home.iterdir()), [])

    def test_target_rejects_symlink_ancestor_external_path_and_regular_file(self):
        destination = self.project / "outside"
        destination.mkdir()
        (self.home / ".claude").symlink_to(destination, target_is_directory=True)
        (self.home / ".cursor").write_text("not a directory", encoding="utf-8")
        for identifier in ("claude-code", "cursor"):
            with self.subTest(agent=identifier), self.assertRaises(EditorError) as caught:
                self.service.target(identifier)
            self.assertEqual(caught.exception.status, 403)
            self.assertFalse(self.agent(identifier)["installation"]["available"])
        external = AgentService(self.store, home=Path("/Volumes/fixture/home"))
        with self.assertRaises(EditorError):
            external.target("codex")

    def test_snapshot_is_json_serializable_and_does_not_claim_loading(self):
        result = self.snapshot()
        self.assertTrue(json.dumps(result, ensure_ascii=False))
        self.assertTrue(result["limits"]["directChildrenOnly"])
        self.assertFalse(result["limits"]["followsSymlinks"])
        self.assertIn("目录", result["notice"])
